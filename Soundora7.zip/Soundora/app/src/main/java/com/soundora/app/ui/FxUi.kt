package com.soundora.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.FX_DEFS
import com.soundora.app.audio.Track

/** Bir kanalın efekt zinciri: aç/kapat + ayarlar. Efektler gerçek zamanlı sese uygulanır. */
@Composable
fun FxPanel(tr: Track, onChange: () -> Unit) {
    var sel by remember(tr.id) { mutableIntStateOf(0) }
    var ver by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver
    val fx = tr.fx
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("Efektler (dokun: aç / seç, seçiliyken tekrar dokun: kapat)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FX_DEFS.forEachIndexed { i, d ->
                FilterChip(
                    selected = fx.on[i],
                    onClick = {
                        if (!fx.on[i]) { fx.on[i] = true; sel = i }
                        else if (sel != i) sel = i
                        else fx.on[i] = false
                        fx.refresh(); ver++; onChange()
                    },
                    label = { Text(d.name + if (sel == i) " •" else "") }
                )
            }
        }
        val d = FX_DEFS[sel]
        Text(d.name + if (fx.on[sel]) " ayarları" else " (kapalı — ayarlamak için dokunup aç)", fontSize = 12.sp)
        d.params.forEachIndexed { j, pd ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(pd.label, Modifier.width(118.dp), fontSize = 11.sp)
                Slider(
                    value = fx.p[sel][j].coerceIn(pd.min, pd.max),
                    onValueChange = { fx.p[sel][j] = it; ver++ },
                    valueRange = pd.min..pd.max, modifier = Modifier.weight(1f)
                )
                Text(String.format("%.1f", fx.p[sel][j]), Modifier.width(44.dp), fontSize = 11.sp)
            }
        }
    }
}
