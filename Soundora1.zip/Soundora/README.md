# Soundora (Aşama 2)
Yeni: görselli enstrümanlar (piyano, synth pad, bas, akustik/elektro gitar telleri, davul seti),
profesyonel Beat Maker (renkli satırlar, playhead, mikser + mute, 4 kalıp slotu A-D kayıt/yükle).
Henüz yok: çok kanallı stüdyo, efektler, proje kaydı, dışa aktarma, şablonlar, öğrenme bölümü.
