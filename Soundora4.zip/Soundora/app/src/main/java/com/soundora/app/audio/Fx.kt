package com.soundora.app.audio

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

class FxParam(val label: String, val min: Float, val max: Float, val def: Float)
class FxDef(val name: String, val params: List<FxParam>)

/** Sıra: 0 EQ, 1 Reverb, 2 Delay, 3 Compressor, 4 Distortion, 5 Filter, 6 Chorus, 7 Flanger, 8 Pitch Shifter */
val FX_DEFS = listOf(
    FxDef("EQ", listOf(FxParam("Bas dB", -12f, 12f, 0f), FxParam("Orta dB", -12f, 12f, 0f), FxParam("Tiz dB", -12f, 12f, 0f))),
    FxDef("Reverb", listOf(FxParam("Oda boyutu", 0f, 1f, 0.5f), FxParam("Karışım", 0f, 1f, 0.3f))),
    FxDef("Delay", listOf(FxParam("Süre (ms)", 50f, 800f, 300f), FxParam("Geri besleme", 0f, 0.9f, 0.4f), FxParam("Karışım", 0f, 1f, 0.3f))),
    FxDef("Compressor", listOf(FxParam("Eşik dB", -40f, 0f, -18f), FxParam("Oran", 1f, 20f, 4f), FxParam("Kazanç dB", 0f, 12f, 3f))),
    FxDef("Distortion", listOf(FxParam("Drive", 1f, 30f, 6f), FxParam("Karışım", 0f, 1f, 1f))),
    FxDef("Filter", listOf(FxParam("Kesim Hz", 100f, 12000f, 3000f), FxParam("Rezonans", 0.5f, 10f, 1f), FxParam("0 Alçak / 1 Yüksek", 0f, 1f, 0f))),
    FxDef("Chorus", listOf(FxParam("Hız Hz", 0.1f, 5f, 1.2f), FxParam("Derinlik ms", 0.5f, 10f, 4f), FxParam("Karışım", 0f, 1f, 0.5f))),
    FxDef("Flanger", listOf(FxParam("Hız Hz", 0.05f, 2f, 0.3f), FxParam("Derinlik ms", 0.2f, 3f, 1.5f), FxParam("Geri besleme", 0f, 0.9f, 0.5f), FxParam("Karışım", 0f, 1f, 0.5f))),
    FxDef("Pitch Shifter", listOf(FxParam("Yarım ses", -12f, 12f, 0f), FxParam("Karışım", 0f, 1f, 1f)))
)

class Biquad {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var z1 = 0.0
    private var z2 = 0.0

    fun proc(x: Double): Double {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    /** type: 0 LP, 1 HP, 2 Peak, 3 LowShelf, 4 HighShelf, 5 BandPass */
    fun set(type: Int, f0: Double, q: Double, gainDb: Double) {
        val sr = AudioEngine.SR.toDouble()
        val w0 = 2 * PI * min(f0, sr * 0.45) / sr
        val cw = cos(w0)
        val sw = sin(w0)
        val alpha = sw / (2 * q)
        val amp = 10.0.pow(gainDb / 40.0)
        val sa = 2 * sqrt(amp) * alpha
        val nb0: Double
        val nb1: Double
        val nb2: Double
        val a0: Double
        val na1: Double
        val na2: Double
        when (type) {
            0 -> { nb0 = (1 - cw) / 2; nb1 = 1 - cw; nb2 = (1 - cw) / 2; a0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha }
            1 -> { nb0 = (1 + cw) / 2; nb1 = -(1 + cw); nb2 = (1 + cw) / 2; a0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha }
            2 -> { nb0 = 1 + alpha * amp; nb1 = -2 * cw; nb2 = 1 - alpha * amp; a0 = 1 + alpha / amp; na1 = -2 * cw; na2 = 1 - alpha / amp }
            3 -> {
                nb0 = amp * ((amp + 1) - (amp - 1) * cw + sa)
                nb1 = 2 * amp * ((amp - 1) - (amp + 1) * cw)
                nb2 = amp * ((amp + 1) - (amp - 1) * cw - sa)
                a0 = (amp + 1) + (amp - 1) * cw + sa
                na1 = -2 * ((amp - 1) + (amp + 1) * cw)
                na2 = (amp + 1) + (amp - 1) * cw - sa
            }
            4 -> {
                nb0 = amp * ((amp + 1) + (amp - 1) * cw + sa)
                nb1 = -2 * amp * ((amp - 1) + (amp + 1) * cw)
                nb2 = amp * ((amp + 1) + (amp - 1) * cw - sa)
                a0 = (amp + 1) - (amp - 1) * cw + sa
                na1 = 2 * ((amp - 1) - (amp + 1) * cw)
                na2 = (amp + 1) - (amp - 1) * cw - sa
            }
            else -> { nb0 = alpha; nb1 = 0.0; nb2 = -alpha; a0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha }
        }
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }
}

class DelayLine(size: Int) {
    private val buf = FloatArray(size)
    private var w = 0

    fun write(x: Float) { buf[w] = x; w = (w + 1) % buf.size }

    /** delay: örnek cinsinden, en az 1 */
    fun read(delay: Double): Float {
        var d = delay
        if (d < 1.0) d = 1.0
        if (d > buf.size - 2) d = (buf.size - 2).toDouble()
        var p = (w - 1).toDouble() - d
        if (p < 0) p += buf.size
        val i0 = p.toInt()
        val fr = (p - i0).toFloat()
        val i1 = (i0 + 1) % buf.size
        return buf[i0] * (1 - fr) + buf[i1] * fr
    }
}

/** Bir kanalın efekt zinciri. Efektler gerçek zamanlı sese uygulanır. */
class FxChain {
    val on = BooleanArray(9)
    val p = Array(9) { i -> FloatArray(FX_DEFS[i].params.size) { j -> FX_DEFS[i].params[j].def } }
    @Volatile var active = false

    private val sr = AudioEngine.SR.toDouble()
    private val eqL = Biquad()
    private val eqM = Biquad()
    private val eqH = Biquad()
    private val filt = Biquad()
    private var tick = 0
    private val combLen = intArrayOf(1116, 1188, 1277, 1356)
    private val combBuf = Array(4) { FloatArray(combLen[it]) }
    private val combIdx = IntArray(4)
    private val combLp = FloatArray(4)
    private val apLen = intArrayOf(556, 441)
    private val apBuf = Array(2) { FloatArray(apLen[it]) }
    private val apIdx = IntArray(2)
    private val dl = DelayLine(44100)
    private val ch = DelayLine(4096)
    private var chPh = 0.0
    private val fl = DelayLine(2048)
    private var flPh = 0.0
    private val pt = DelayLine(4096)
    private var ptD = 0.0
    private var env = 0.0
    private val atk = 1 - exp(-1.0 / (0.005 * 44100))
    private val rel = 1 - exp(-1.0 / (0.12 * 44100))

    fun refresh() { active = on.any { b -> b } }

    private fun updateCoefs() {
        eqL.set(3, 200.0, 0.707, p[0][0].toDouble())
        eqM.set(2, 1000.0, 0.8, p[0][1].toDouble())
        eqH.set(4, 4000.0, 0.707, p[0][2].toDouble())
        filt.set(if (p[5][2] >= 0.5f) 1 else 0, p[5][0].toDouble(), p[5][1].toDouble(), 0.0)
    }

    fun process(xin: Float): Float {
        if ((tick++ and 63) == 0) updateCoefs()
        var x = xin.toDouble()
        if (on[8]) x = pitch(x)
        if (on[5]) x = filt.proc(x)
        if (on[0]) x = eqH.proc(eqM.proc(eqL.proc(x)))
        if (on[4]) x = dist(x)
        if (on[3]) x = comp(x)
        if (on[6]) x = chorus(x)
        if (on[7]) x = flanger(x)
        if (on[2]) x = delay(x)
        if (on[1]) x = reverb(x)
        return x.toFloat()
    }

    private fun pitch(x: Double): Double {
        val ratio = 2.0.pow(p[8][0] / 12.0)
        val mix = p[8][1].toDouble()
        val w = 1800.0
        pt.write(x.toFloat())
        ptD += 1.0 - ratio
        if (ptD >= w) ptD -= w
        if (ptD < 0) ptD += w
        val d2 = (ptD + w / 2) % w
        val g1 = 1.0 - abs(2 * ptD / w - 1.0)
        val g2 = 1.0 - abs(2 * d2 / w - 1.0)
        val y = pt.read(ptD + 1.0) * g1 + pt.read(d2 + 1.0) * g2
        return x * (1 - mix) + y * mix
    }

    private fun dist(x: Double): Double {
        val d = p[4][0].toDouble()
        val m = p[4][1].toDouble()
        return x * (1 - m) + tanh(x * d) * 0.7 * m
    }

    private fun comp(x: Double): Double {
        val lvl = abs(x)
        env += (if (lvl > env) atk else rel) * (lvl - env)
        val db = 20 * log10(env + 1e-9)
        val over = db - p[3][0]
        var g = if (over > 0) -over * (1 - 1.0 / p[3][1]) else 0.0
        g += p[3][2]
        return x * 10.0.pow(g / 20.0)
    }

    private fun chorus(x: Double): Double {
        val mix = p[6][2].toDouble()
        ch.write(x.toFloat())
        chPh += 2 * PI * p[6][0] / sr
        if (chPh > 2 * PI) chPh -= 2 * PI
        val wet = ch.read((18.0 + p[6][1] * sin(chPh)) * sr / 1000.0)
        return x * (1 - mix * 0.5) + wet * mix * 0.7
    }

    private fun flanger(x: Double): Double {
        val mix = p[7][3].toDouble()
        flPh += 2 * PI * p[7][0] / sr
        if (flPh > 2 * PI) flPh -= 2 * PI
        val wet = fl.read((0.5 + p[7][1] * (0.5 + 0.5 * sin(flPh))) * sr / 1000.0)
        fl.write((x + wet * p[7][2]).toFloat())
        return x * (1 - mix * 0.5) + wet * mix * 0.7
    }

    private fun delay(x: Double): Double {
        val wet = dl.read(p[2][0] * sr / 1000.0)
        dl.write((x + wet * p[2][1]).toFloat())
        return x + wet * p[2][2]
    }

    private fun reverb(x: Double): Double {
        val mix = p[1][1].toDouble()
        val fb = 0.7 + 0.25 * p[1][0]
        val damp = 0.25
        val input = x * 0.2
        var sum = 0.0
        for (i in 0 until 4) {
            val buf = combBuf[i]
            val idx = combIdx[i]
            val o = buf[idx].toDouble()
            combLp[i] = (o * (1 - damp) + combLp[i] * damp).toFloat()
            buf[idx] = (input + combLp[i] * fb).toFloat()
            combIdx[i] = (idx + 1) % buf.size
            sum += o
        }
        var y = sum
        for (i in 0 until 2) {
            val buf = apBuf[i]
            val idx = apIdx[i]
            val bo = buf[idx].toDouble()
            val out = -y + bo
            buf[idx] = (y + bo * 0.5).toFloat()
            apIdx[i] = (idx + 1) % buf.size
            y = out
        }
        return x * (1 - mix * 0.3) + y * mix
    }

    fun toJson(): JSONArray {
        val a = JSONArray()
        for (i in 0 until 9) a.put(JSONObject().put("on", on[i]).put("p", JSONArray(p[i].map { it.toDouble() })))
        return a
    }

    fun fromJson(a: JSONArray) {
        for (i in 0 until minOf(9, a.length())) {
            val o = a.getJSONObject(i)
            on[i] = o.optBoolean("on")
            val pa = o.optJSONArray("p")
            if (pa != null) for (j in 0 until minOf(pa.length(), p[i].size)) p[i][j] = pa.optDouble(j, p[i][j].toDouble()).toFloat()
        }
        refresh()
    }
}
