package com.soundora.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import kotlinx.coroutines.delay

private const val EM = "................"
private val presets: Map<String, Pair<Int, List<String>>> = mapOf(
    "Pop" to (110 to listOf("x...x...x...x...", "....x.......x...", EM, "x.x.x.x.x.x.x.x.", EM, EM, EM)),
    "Hip-hop" to (90 to listOf("x.....x...x.....", "....x.......x...", EM, "x.x.x.x.x.x.x.x.", EM, EM, EM)),
    "Trap" to (140 to listOf("x.......x.x.....", "........x.......", "........x.......", "x.xxx.x.xxx.x.xx", "......x.......x.", EM, EM)),
    "Lo-fi" to (75 to listOf("x.....x...x..x..", "....x.......x...", EM, "x.x.x.x.x.x.x.x.", EM, EM, ".......x.......x")),
    "House" to (124 to listOf("x...x...x...x...", EM, "....x.......x...", "..x...x...x...x.", "..x...x...x...x.", EM, EM))
)

@Composable
fun BeatScreen() {
    val e = AudioEngine
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE) }
    var playing by remember { mutableStateOf(e.playing) }
    var bpm by remember { mutableIntStateOf(e.bpm) }
    var step by remember { mutableIntStateOf(-1) }
    var slot by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf("") }
    val rows = AudioEngine.ROWS
    val steps = AudioEngine.STEPS
    val grid = remember {
        mutableStateListOf<Boolean>().apply { for (r in 0 until rows) for (s in 0 until steps) add(e.pattern[r][s]) }
    }
    val vols = remember { mutableStateListOf<Float>().apply { e.rowVol.forEach { add(it) } } }
    val mutes = remember { mutableStateListOf<Boolean>().apply { e.rowMute.forEach { add(it) } } }

    LaunchedEffect(Unit) { while (true) { step = e.currentStep; delay(30) } }

    fun setCell(r: Int, s: Int, v: Boolean) { grid[r * steps + s] = v; e.pattern[r][s] = v }
    fun applyRows(list: List<String>) {
        for (r in 0 until rows) for (s in 0 until steps) setCell(r, s, list[r][s] == 'x')
    }
    fun encode(): String = (0 until rows).joinToString("|") { r ->
        (0 until steps).joinToString("") { s -> if (grid[r * steps + s]) "x" else "." }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Beat Maker", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        // ---- Transport
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(68.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable { playing = !playing; e.playing = playing },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 28.sp, color = Color.White) }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$bpm", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Text(" BPM", color = Color(0xFF9CA3AF), modifier = Modifier.padding(bottom = 8.dp))
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Adım ${if (step < 0) "-" else (step + 1).toString()} / $steps",
                        color = Color(0xFF9CA3AF), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                Slider(
                    value = bpm.toFloat(), valueRange = 40f..220f,
                    onValueChange = { bpm = it.toInt(); e.bpm = bpm }
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { (name, p) ->
                AssistChip(onClick = { bpm = p.first; e.bpm = p.first; applyRows(p.second) }, label = { Text(name) })
            }
            AssistChip(onClick = { applyRows(List(rows) { EM }) }, label = { Text("Temizle") })
        }

        // ---- Pad'ler
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (r in 0 until rows) MiniPad(r, Modifier.weight(1f))
        }

        // ---- Sequencer
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(10.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.width(58.dp))
                for (g in 0 until 4) {
                    Row(Modifier.weight(1f)) {
                        for (k in 0 until 4) {
                            val s = g * 4 + k
                            Text(
                                "${s + 1}", modifier = Modifier.weight(1f),
                                color = if (s == step) Color.White else Color(0xFF6B7280),
                                fontSize = 9.sp, fontWeight = if (k == 0) FontWeight.Bold else FontWeight.Normal,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                    if (g < 3) Spacer(Modifier.width(4.dp))
                }
            }
            for (r in 0 until rows) {
                val c = RowColors[r]
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.width(54.dp).height(34.dp).clip(RoundedCornerShape(8.dp))
                            .background(c.copy(alpha = if (mutes[r]) 0.1f else 0.25f))
                            .clickable { e.hitDrum(r) },
                        contentAlignment = Alignment.Center
                    ) { Text(AudioEngine.rowNames[r], color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(4.dp))
                    for (g in 0 until 4) {
                        Row(Modifier.weight(1f)) {
                            for (k in 0 until 4) {
                                val s = g * 4 + k
                                val on = grid[r * steps + s]
                                val off = if (g % 2 == 0) Color(0xFF232C52) else Color(0xFF1B2342)
                                Box(
                                    Modifier.weight(1f).height(34.dp).padding(1.5.dp)
                                        .background(if (on) c else off, RoundedCornerShape(6.dp))
                                        .then(
                                            if (s == step) Modifier.border(1.5.dp, Color.White, RoundedCornerShape(6.dp))
                                            else Modifier
                                        )
                                        .clickable { setCell(r, s, !on) }
                                )
                            }
                        }
                        if (g < 3) Spacer(Modifier.width(4.dp))
                    }
                }
            }
        }

        // ---- Mikser
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(12.dp)) {
            Text("Mikser", fontWeight = FontWeight.Bold)
            for (r in 0 until rows) {
                val c = RowColors[r]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(c))
                    Text(AudioEngine.rowNames[r], Modifier.width(70.dp).padding(start = 8.dp), fontSize = 12.sp)
                    Slider(
                        value = vols[r], onValueChange = { vols[r] = it; e.rowVol[r] = it },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = c, activeTrackColor = c)
                    )
                    Box(
                        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (mutes[r]) Color(0xFFEF4444) else Color(0xFF232C52))
                            .clickable { mutes[r] = !mutes[r]; e.rowMute[r] = mutes[r] },
                        contentAlignment = Alignment.Center
                    ) { Text("M", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }

        // ---- Kalıplar
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(12.dp)) {
            Text("Kalıplarım", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("A", "B", "C", "D").forEachIndexed { i, n ->
                    FilterChip(selected = slot == i, onClick = { slot = i; info = "" }, label = { Text(n) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    prefs.edit().putString("slot$slot", "$bpm#${encode()}").apply()
                    info = "Kalıp ${"ABCD"[slot]} kaydedildi."
                }) { Text("Kaydet") }
                OutlinedButton(onClick = {
                    val raw = prefs.getString("slot$slot", null)
                    if (raw == null) info = "Bu kalıp boş."
                    else {
                        val parts = raw.split("#")
                        bpm = parts[0].toInt(); e.bpm = bpm
                        applyRows(parts[1].split("|"))
                        info = "Kalıp ${"ABCD"[slot]} yüklendi."
                    }
                }) { Text("Yükle") }
            }
            if (info.isNotEmpty()) Text(info, color = Color(0xFF9CA3AF), fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun MiniPad(row: Int, modifier: Modifier) {
    var down by remember { mutableStateOf(false) }
    val c = RowColors[row]
    Box(
        modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp))
            .background(c.copy(alpha = if (down) 1f else 0.35f))
            .pointerInput(row) {
                detectTapGestures(onPress = {
                    down = true
                    AudioEngine.hitDrum(row)
                    try { tryAwaitRelease() } finally { down = false }
                })
            },
        contentAlignment = Alignment.Center
    ) { Text(AudioEngine.rowNames[row], fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White) }
}
