package com.soundora.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ProjectStore
import com.soundora.app.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences("soundora", Context.MODE_PRIVATE)
        ThemeState.dark = sp.getBoolean("dark", true)
        AppPrefs.load(this)
        AudioEngine.bufferMode = sp.getInt("buffer", 1)
        AudioEngine.baseDir = filesDir
        ProjectStore.init(this)
        AudioEngine.start()
        setContent { SoundoraTheme { SoundoraApp() } }
    }

    override fun onStop() {
        super.onStop()
        AudioEngine.playing = false
        ProjectStore.save(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) AudioEngine.stop()
    }
}

@Composable
private fun StudioHub() {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    val names = listOf("Ritim", "Melodi", "Zaman Çizelgesi", "Otomasyon", "Kayıt", "Mikser", "Ölçüm", "Araçlar")
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            names.forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(n) }) }
        }
        Box(Modifier.weight(1f)) {
            when (sub) {
                0 -> BeatScreen()
                1 -> PianoRollScreen()
                2 -> StudioScreen()
                3 -> AutomationScreen()
                4 -> RecordScreen()
                5 -> MixerScreen()
                6 -> MeterScreen()
                else -> ToolsScreen()
            }
        }
    }
}

@Composable
private fun SubPage(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Ana sayfa") }
            Spacer(Modifier.weight(1f))
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.padding(end = 12.dp))
        }
        Box(Modifier.weight(1f)) { content() }
    }
}

@Composable
fun SoundoraApp() {
    val ctx = LocalContext.current
    var page by rememberSaveable { mutableStateOf("home") }
    var pv by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val sp = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)
        while (true) {
            delay(sp.getInt("autosave_sec", 15) * 1000L)
            if (sp.getBoolean("autosave", true)) ProjectStore.save(ctx)
        }
    }
    BackHandler(enabled = page != "home") { page = "home" }
    if (!AppPrefs.advanced && (page == "studio" || page == "library")) page = "home"

    val tabs = if (AppPrefs.advanced) listOf("home", "make", "studio", "tuner", "projects", "learn")
    else listOf("home", "make", "tuner", "projects", "learn")
    fun meta(r: String): Pair<String, String> = when (r) {
        "home" -> "🏠" to "Ana Sayfa"
        "make" -> "🎵" to "Müzik Yap"
        "studio" -> "🎚" to "Stüdyo"
        "tuner" -> "🎯" to "Akort"
        "projects" -> "📁" to "Projelerim"
        else -> "🎓" to "Öğren"
    }
    val back = { page = "home" }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                tabs.forEach { r ->
                    val (icon, label) = meta(r)
                    NavigationBarItem(
                        selected = page == r, onClick = { page = r },
                        icon = { Text(icon) }, label = { Text(label, fontSize = 9.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            key(pv) {
                when (page) {
                    "home" -> HomeScreen { page = it }
                    "make" -> EasyMakeScreen()
                    "tuner" -> TunerScreen()
                    "studio" -> StudioHub()
                    "learn" -> LearnScreen()
                    "projects" -> ProjectsScreen { pv++ }
                    "instr" -> SubPage("Enstrümanlar", back) { InstrumentScreen() }
                    "record" -> SubPage("Ses Kaydet", back) { RecordScreen() }
                    "library" -> SubPage("Ses Kütüphanesi", back) { LibraryScreen() }
                    else -> SubPage("Ayarlar", back) { SettingsScreen() }
                }
            }
        }
    }
    if (!AppPrefs.introDone) IntroDialog() else FirstTip(page)
}
