package com.soundora.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import com.soundora.app.audio.AudioEngine

private class Inst(val name: String, val kind: Int, val view: Int)
private val insts = listOf(
    Inst("Piyano", 0, 0), Inst("E.Piyano", 5, 0), Inst("Org", 6, 0), Inst("Strings", 7, 0),
    Inst("Pad", 8, 0), Inst("Pluck", 9, 0), Inst("Lead Synth", 1, 1), Inst("Synth Bas", 10, 0),
    Inst("Bas Gitar", 2, 2), Inst("Akustik", 3, 3), Inst("Elektro", 4, 4), Inst("Davul", -1, 5)
)

@Composable
fun InstrumentScreen() {
    var idx by remember { mutableIntStateOf(0) }
    var octave by remember { mutableIntStateOf(4) }
    val inst = insts[idx]

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Enstrümanlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            insts.forEachIndexed { i, n -> FilterChip(selected = idx == i, onClick = { idx = i }, label = { Text(n.name) }) }
        }
        if (inst.view == 0 || inst.view == 1) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { if (octave > 1) octave-- }) { Text("Oktav −") }
                Text("   Oktav $octave   ")
                OutlinedButton(onClick = { if (octave < 7) octave++ }) { Text("Oktav +") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            when (inst.view) {
                0 -> PianoView(inst.kind, octave, inst.name.uppercase())
                1 -> SynthView(inst.kind, octave)
                2 -> FretView(2, "BAS GİTAR", listOf(28, 33, 38, 43), Color(0xFF2B1B14), Blue, 190.dp)
                3 -> FretView(3, "AKUSTİK GİTAR", listOf(40, 45, 50, 55, 59, 64), Color(0xFF7A4B25), Color(0xFFFBBF24), 250.dp)
                4 -> FretView(4, "ELEKTRO GİTAR", listOf(40, 45, 50, 55, 59, 64), Color(0xFF1F1B2E), Color(0xFFEC4899), 250.dp)
                else -> DrumKit()
            }
            if (inst.kind >= 0) {
                Spacer(Modifier.height(12.dp))
                SoundPanel(inst.kind)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(112.dp), fontSize = 12.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text(String.format("%.2f", value), Modifier.width(44.dp), fontSize = 11.sp)
    }
}

@Composable
private fun SoundPanel(kind: Int) {
    val e = AudioEngine
    val ad = remember(kind) { mutableStateListOf(*e.adsr[kind].toTypedArray()) }
    var vol by remember(kind) { mutableFloatStateOf(e.instVol[kind]) }
    var pitch by remember { mutableFloatStateOf(e.pitchSemi) }
    fun setAd(i: Int, v: Float) { ad[i] = v; e.adsr[kind][i] = v }
    fun preset(v: FloatArray) { for (i in 0..3) setAd(i, v[i]) }

    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text("Ses Ayarı", fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = { preset(e.defaultAdsr(kind)) }, label = { Text("Varsayılan") })
            AssistChip(onClick = { preset(floatArrayOf(0.25f, 0.4f, 0.8f, 0.8f)) }, label = { Text("Yumuşak") })
            AssistChip(onClick = { preset(floatArrayOf(0.001f, 0.1f, 0.5f, 0.08f)) }, label = { Text("Keskin") })
            AssistChip(onClick = { preset(floatArrayOf(0.01f, 0.6f, 1f, 1.8f)) }, label = { Text("Uzun") })
        }
        LabeledSlider("Ses seviyesi", vol, 0f..1f) { vol = it; e.instVol[kind] = it }
        LabeledSlider("Pitch (yarım ses)", pitch, -12f..12f) { pitch = it.roundToInt().toFloat(); e.pitchSemi = pitch }
        LabeledSlider("Attack", ad[0], 0.001f..2f) { setAd(0, it) }
        LabeledSlider("Decay", ad[1], 0.01f..2f) { setAd(1, it) }
        LabeledSlider("Sustain", ad[2], 0f..1f) { setAd(2, it) }
        LabeledSlider("Release", ad[3], 0.02f..3f) { setAd(3, it) }
    }
}

@Composable
private fun Header(title: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("SOUNDORA", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Spacer(Modifier.weight(1f))
        Text(title, color = Color(0xFF9CA3AF), fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

// ---------- Tuş (piyano / synth ortak) ----------
@Composable
private fun KeyBox(
    semi: Int, kind: Int, oct: State<Int>, modifier: Modifier,
    up: Color, down: Color, shape: Shape, content: @Composable () -> Unit = {}
) {
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier.background(if (pressed) down else up, shape).pointerInput(semi, kind) {
            detectTapGestures(onPress = {
                pressed = true
                val v = AudioEngine.noteOn(kind, 12 * (oct.value + 1) + semi)
                try { tryAwaitRelease() } finally { v.release(); pressed = false }
            })
        },
        contentAlignment = Alignment.Center
    ) { content() }
}

// ---------- PİYANO ----------
@Composable
private fun PianoView(kind: Int, octave: Int, title: String) {
    val whiteSemis = listOf(0, 2, 4, 5, 7, 9, 11)
    val blackAfter = mapOf(0 to 1, 1 to 3, 3 to 6, 4 to 8, 5 to 10)
    val oct = rememberUpdatedState(octave)
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1B33), Color(0xFF0C0A18))), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF2E2A4D), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Header(title)
        BoxWithConstraints(Modifier.fillMaxWidth().height(250.dp)) {
            val ww = maxWidth / 14
            val bw = ww * 0.62f
            Row(Modifier.fillMaxSize()) {
                for (i in 0 until 14) {
                    val semi = whiteSemis[i % 7] + 12 * (i / 7)
                    KeyBox(
                        semi, kind, oct, Modifier.width(ww).fillMaxHeight().padding(1.dp),
                        Color(0xFFF8FAFC), Color(0xFFC4B5FD),
                        RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
                    )
                }
            }
            for (i in 0 until 14) {
                val b = blackAfter[i % 7] ?: continue
                KeyBox(
                    b + 12 * (i / 7), kind, oct,
                    Modifier.offset(x = ww * (i + 1) - bw / 2).width(bw).fillMaxHeight(0.6f),
                    Color(0xFF0B0B12), Purple,
                    RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)
                )
            }
        }
    }
}

// ---------- SYNTH (pad paneli) ----------
@Composable
private fun SynthView(kind: Int, octave: Int) {
    val scale = listOf(0, 3, 5, 7, 10)
    val oct = rememberUpdatedState(octave)
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF16213E), Color(0xFF0A0F24))), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF263463), RoundedCornerShape(18.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Header("SYNTH PAD")
        for (row in 0 until 4) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (col in 0 until 4) {
                    val idx = (3 - row) * 4 + col
                    val semi = scale[idx % 5] + 12 * (idx / 5)
                    KeyBox(
                        semi, kind, oct, Modifier.weight(1f).aspectRatio(1f),
                        Color.hsv(220f + idx * 8f, 0.55f, 0.55f), Color.hsv(220f + idx * 8f, 0.45f, 1f),
                        RoundedCornerShape(14.dp)
                    )
                }
            }
        }
    }
}

// ---------- GİTAR / BAS (tel ve perde) ----------
@Composable
private fun FretView(kind: Int, title: String, opens: List<Int>, wood: Color, accent: Color, height: androidx.compose.ui.unit.Dp) {
    val frets = 12
    val strings = opens.size
    var pressed by remember(kind) { mutableStateOf(setOf<Int>()) }
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF0C0A18), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF2E2A4D), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Header(title)
        Box(
            Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(12.dp))
                .pointerInput(kind, strings) {
                    detectTapGestures(onPress = { off ->
                        val cw = size.width / (frets + 1f)
                        val rh = size.height / strings
                        val r = (off.y / rh).toInt().coerceIn(0, strings - 1)
                        val f = (off.x / cw).toInt().coerceIn(0, frets)
                        val key = r * 100 + f
                        pressed = pressed + key
                        AudioEngine.noteOn(kind, opens[strings - 1 - r] + f)
                        try { tryAwaitRelease() } finally { pressed = pressed - key }
                    })
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val cw = size.width / (frets + 1f)
                val rh = size.height / strings
                drawRect(Brush.verticalGradient(listOf(wood, wood.copy(red = wood.red * 0.6f, green = wood.green * 0.6f, blue = wood.blue * 0.6f))))
                drawRect(Color.Black.copy(alpha = 0.3f), Offset.Zero, Size(cw, size.height))
                for (f in listOf(3, 5, 7, 9)) drawCircle(Color.White.copy(alpha = 0.25f), cw * 0.12f, Offset((f + 0.5f) * cw, size.height / 2))
                drawCircle(Color.White.copy(alpha = 0.25f), cw * 0.12f, Offset(12.5f * cw, size.height * 0.3f))
                drawCircle(Color.White.copy(alpha = 0.25f), cw * 0.12f, Offset(12.5f * cw, size.height * 0.7f))
                for (k in 1..frets) {
                    drawLine(
                        if (k == 1) Color(0xFFE5E7EB) else Color(0xFF9CA3AF),
                        Offset(k * cw, 0f), Offset(k * cw, size.height), if (k == 1) 7f else 3f
                    )
                }
                for (r in 0 until strings) {
                    val y = (r + 0.5f) * rh
                    val thick = if (strings == 6) 1.5f + r * 1.3f else 3f + r * 2.5f
                    val active = pressed.any { it / 100 == r }
                    drawLine(if (active) accent else Color(0xFFD1D5DB), Offset(0f, y), Offset(size.width, y), thick)
                }
                pressed.forEach { key ->
                    drawCircle(accent.copy(alpha = 0.85f), rh * 0.32f, Offset((key % 100 + 0.5f) * cw, (key / 100 + 0.5f) * rh))
                }
            }
        }
        Text("Tele / perdeye dokunarak çal", color = Color(0xFF6B7280), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------- DAVUL SETİ ----------
@Composable
private fun DrumKit() {
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF1F1B2E), Color(0xFF0C0A18))), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF2E2A4D), RoundedCornerShape(18.dp)).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Header("DRUM KIT")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DrumPad(3, Modifier.weight(1f)); DrumPad(4, Modifier.weight(1f)); DrumPad(5, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DrumPad(1, Modifier.weight(1f)); DrumPad(2, Modifier.weight(1f)); DrumPad(6, Modifier.weight(1f))
        }
        DrumPad(0, Modifier.fillMaxWidth(0.6f))
    }
}

@Composable
private fun DrumPad(row: Int, modifier: Modifier) {
    var down by remember { mutableStateOf(false) }
    val c = RowColors[row]
    Box(
        modifier.aspectRatio(1f).clip(CircleShape)
            .background(Brush.radialGradient(listOf(if (down) c else c.copy(alpha = 0.55f), Color(0xFF111827))))
            .border(4.dp, c, CircleShape)
            .pointerInput(row) {
                detectTapGestures(onPress = {
                    down = true
                    AudioEngine.hitDrum(row)
                    try { tryAwaitRelease() } finally { down = false }
                })
            },
        contentAlignment = Alignment.Center
    ) { Text(AudioEngine.rowNames[row], color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
}
