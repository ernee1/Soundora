package com.soundora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.ceil
import kotlin.math.max

class Note(var start: Int, var len: Int, var pitch: Int)

/** type: 0 Davul (Beat Maker), 1 Melodi (Piano Roll), 2 Ses (kayıt / dosya) */
class Track(
    val id: Int, var name: String, val type: Int,
    var vol: Float = 0.9f, var mute: Boolean = false, var solo: Boolean = false, var hidden: Boolean = false
)

/** Davul/Melodi parçası: start, lenSteps, phase. Ses parçası: start, file, offS, lenS (örnek sayısı). */
class Clip(
    var track: Int, var start: Int, var lenSteps: Int, var phase: Int = 0,
    var file: String? = null, var offS: Int = 0, var lenS: Int = 0
)

private class Held(val v: Voice, var left: Int)

object AudioEngine {
    const val SR = 44100
    const val ROWS = 7
    const val MAX_STEPS = 64
    const val KINDS = 11
    val rowNames = listOf("Kick", "Snare", "Clap", "Hi-Hat", "Açık Hat", "Tom", "Rim")
    val kitNames = listOf("Standart", "808 Trap", "Lo-fi", "Elektronik")
    val kindNames = listOf("Piyano", "Lead Synth", "Bas Gitar", "Akustik", "Elektro", "E.Piyano", "Org", "Strings", "Pad", "Pluck", "Synth Bas")

    val pattern = Array(ROWS) { BooleanArray(MAX_STEPS) }
    val rowVol = FloatArray(ROWS) { 0.8f }
    val rowMute = BooleanArray(ROWS)
    val rowSolo = BooleanArray(ROWS)
    val melody = CopyOnWriteArrayList<Note>()
    val instVol = FloatArray(KINDS) { 0.8f }
    val adsr = Array(KINDS) { defaultAdsr(it) }
    val tracks = CopyOnWriteArrayList<Track>()
    val clips = CopyOnWriteArrayList<Clip>()

    @Volatile var baseDir: File? = null
    @Volatile var bpm = 100
    @Volatile var playing = false
    @Volatile var songMode = false
    @Volatile var currentStep = -1
    @Volatile var songStep = 0
    @Volatile var seekRequest = -1
    @Volatile var masterVol = 0.8f
    @Volatile var steps = 16
    @Volatile var swing = 0f
    @Volatile var kit = 0
    @Volatile var melodyKind = 0
    @Volatile var pitchSemi = 0f
    @Volatile var metronome = false
    @Volatile var loopOn = false
    @Volatile var loopStart = 0
    @Volatile var loopEnd = 16
    @Volatile var nextTrackId = 3
    @Volatile var soloActive = false

    private val voices = CopyOnWriteArrayList<Voice>()
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    init { resetProject() }

    fun defaultAdsr(kind: Int): FloatArray = when (kind) {
        0 -> floatArrayOf(0.005f, 0.3f, 1f, 0.18f)
        1 -> floatArrayOf(0.01f, 0.2f, 0.7f, 0.2f)
        2 -> floatArrayOf(0.005f, 0.3f, 1f, 0.2f)
        3, 4 -> floatArrayOf(0.002f, 0.5f, 1f, 0.3f)
        5 -> floatArrayOf(0.005f, 0.3f, 1f, 0.25f)
        6 -> floatArrayOf(0.01f, 0.05f, 1f, 0.08f)
        7 -> floatArrayOf(0.35f, 0.3f, 0.9f, 0.6f)
        8 -> floatArrayOf(0.6f, 0.5f, 0.9f, 0.9f)
        9 -> floatArrayOf(0.002f, 0.3f, 1f, 0.2f)
        else -> floatArrayOf(0.005f, 0.2f, 0.8f, 0.12f)
    }

    /** Yeni boş proje durumu */
    fun resetProject() {
        playing = false
        for (r in 0 until ROWS) {
            for (s in 0 until MAX_STEPS) pattern[r][s] = false
            rowVol[r] = 0.8f; rowMute[r] = false; rowSolo[r] = false
        }
        melody.clear()
        for (k in 0 until KINDS) { instVol[k] = 0.8f; adsr[k] = defaultAdsr(k) }
        bpm = 100; steps = 16; swing = 0f; kit = 0; melodyKind = 0
        metronome = false; loopOn = false; loopStart = 0; loopEnd = 16; songStep = 0; seekRequest = -1
        tracks.clear(); clips.clear()
        tracks.add(Track(1, "Davul", 0))
        tracks.add(Track(2, "Melodi", 1))
        clips.add(Clip(1, 0, 64))
        clips.add(Clip(2, 0, 64))
        nextTrackId = 3
        refreshSolo()
    }

    fun refreshSolo() { soloActive = tracks.any { it.solo } }

    fun gainOf(t: Track?): Float {
        if (t == null) return 1f
        if (t.mute) return 0f
        if (soloActive && !t.solo) return 0f
        return t.vol
    }

    fun trackById(id: Int): Track? = tracks.firstOrNull { it.id == id }

    fun clipSteps(c: Clip): Int =
        if (c.file != null) max(1, ceil(c.lenS / (SR * 60.0 / bpm / 4.0)).toInt()) else c.lenSteps

    fun start() {
        if (running) return
        val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SR)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(max(min, 2048))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        thread = Thread({ loop(t) }, "soundora-audio").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun stop() {
        running = false
        thread?.join()
        track?.let { it.stop(); it.release() }
        track = null
        voices.clear()
        playing = false
        currentStep = -1
    }

    private fun loop(t: AudioTrack) {
        val chunk = ShortArray(256)
        t.play()
        var acc = 0.0
        var step = 0
        var wasPlaying = false
        var lastSong = false
        val held = ArrayList<Held>()
        val clipVoices = ArrayList<ClipVoice>()

        fun cleanup() {
            for (h in held) h.v.release()
            held.clear()
            for (c in clipVoices) c.finished = true
            clipVoices.clear()
        }

        while (running) {
            val p = playing
            val song = songMode
            if (!p && wasPlaying) { currentStep = -1; cleanup() }
            if (p && wasPlaying && song != lastSong) cleanup()
            if (p && (!wasPlaying || song != lastSong)) {
                acc = 0.0
                step = if (song) max(0, songStep) else 0
                if (song) startOverlapping(step, clipVoices)
            }
            if (p && song && seekRequest >= 0) {
                step = seekRequest
                seekRequest = -1
                acc = 0.0
                cleanup()
                startOverlapping(step, clipVoices)
            }
            wasPlaying = p
            lastSong = song

            val sps = SR * 60.0 / bpm / 4.0
            val snap = voices.toTypedArray()
            for (i in chunk.indices) {
                if (p) {
                    if (acc <= 0.0) {
                        if (song) {
                            if (loopOn && loopEnd > loopStart && step >= loopEnd) {
                                step = loopStart
                                cleanup()
                                startOverlapping(step, clipVoices)
                            }
                            triggerSong(step, held, clipVoices)
                            songStep = step
                            currentStep = step % max(1, steps)
                        } else {
                            if (step >= steps) step = 0
                            triggerPattern(step, held)
                            currentStep = step
                        }
                        val sw = swing.toDouble()
                        val gap = if (step % 2 == 0) sps * (1.0 + sw) else sps * (1.0 - sw)
                        step = if (song) step + 1 else (step + 1) % max(1, steps)
                        acc += gap
                    }
                    acc -= 1.0
                }
                var mix = 0f
                for (v in snap) if (!v.finished) mix += v.render()
                mix *= masterVol
                chunk[i] = (mix.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            }
            t.write(chunk, 0, chunk.size)
            voices.removeIf { it.finished }
            clipVoices.removeIf { it.finished }
        }
    }

    private fun advanceHeld(held: ArrayList<Held>) {
        val it = held.iterator()
        while (it.hasNext()) {
            val h = it.next()
            h.left--
            if (h.left <= 0) { h.v.release(); it.remove() }
        }
    }

    private fun click(step: Int) {
        if (metronome && step % 4 == 0) addVoice(ClickVoice(step % 16 == 0))
    }

    private fun playDrums(ps: Int, g: Float) {
        if (g <= 0f) return
        val anySolo = rowSolo.any { s -> s }
        for (r in 0 until ROWS) {
            if (pattern[r][ps] && !rowMute[r] && (!anySolo || rowSolo[r])) addVoice(DrumVoice(r, rowVol[r] * g, kit))
        }
    }

    private fun playMelody(ps: Int, g: Float, held: ArrayList<Held>) {
        if (g <= 0f) return
        for (n in melody) {
            if (n.start == ps) {
                val v = NoteVoice(melodyKind, n.pitch, pitchSemi.toDouble(), g.toDouble())
                addVoice(v)
                held.add(Held(v, n.len))
            }
        }
    }

    private fun triggerPattern(step: Int, held: ArrayList<Held>) {
        advanceHeld(held)
        click(step)
        playDrums(step, gainOf(tracks.firstOrNull { it.type == 0 }))
        playMelody(step, gainOf(tracks.firstOrNull { it.type == 1 }), held)
    }

    private fun triggerSong(step: Int, held: ArrayList<Held>, cv: ArrayList<ClipVoice>) {
        advanceHeld(held)
        click(step)
        val n = max(1, steps)
        for (c in clips) {
            val tr = trackById(c.track) ?: continue
            val f = c.file
            if (f != null) {
                if (c.start == step) startClip(c, 0, cv)
            } else if (step >= c.start && step < c.start + c.lenSteps) {
                val ps = (((step - c.start + c.phase) % n) + n) % n
                if (tr.type == 0) playDrums(ps, gainOf(tr))
                else if (tr.type == 1) playMelody(ps, gainOf(tr), held)
            }
        }
    }

    private fun startClip(c: Clip, offset: Int, cv: ArrayList<ClipVoice>) {
        val f = c.file ?: return
        val tr = trackById(c.track) ?: return
        val s = SampleStore.get(f) ?: return
        val startPos = c.offS + offset
        val end = c.offS + c.lenS
        if (startPos >= end) return
        val v = ClipVoice(s.data, startPos, end, tr)
        addVoice(v)
        cv.add(v)
    }

    private fun startOverlapping(pos: Int, cv: ArrayList<ClipVoice>) {
        val sps = SR * 60.0 / bpm / 4.0
        for (c in clips) {
            if (c.file == null) continue
            val len = clipSteps(c)
            if (c.start < pos && pos < c.start + len) startClip(c, ((pos - c.start) * sps).toInt(), cv)
        }
    }

    private fun addVoice(v: Voice) {
        if (voices.size > 64) voices.firstOrNull { it !is ClipVoice }?.finished = true
        voices.add(v)
    }

    fun hitDrum(row: Int) = addVoice(DrumVoice(row, rowVol[row], kit))

    fun noteOn(kind: Int, midi: Int): Voice {
        val v = NoteVoice(kind, midi, pitchSemi.toDouble())
        addVoice(v)
        return v
    }

    fun preview(kind: Int, midi: Int) {
        val v = noteOn(kind, midi)
        main.postDelayed({ v.release() }, 300)
    }
}
