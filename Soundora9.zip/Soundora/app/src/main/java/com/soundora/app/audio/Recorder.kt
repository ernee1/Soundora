package com.soundora.app.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/** kind: 0 Vokal, 1 Enstrüman, 2 Normal ses. Kolay modda uygun ayarlar kind'a göre otomatik seçilir. */
data class RecConfig(
    val kind: Int = 2,
    val sr: Int = 44100,
    val stereo: Boolean = false,
    val gain: Float = 1f,
    val source: Int = MediaRecorder.AudioSource.MIC,
    val agc: Boolean = false,
    val ns: Boolean = false,
    val aec: Boolean = false,
    val deviceId: Int = -1,
    val monitor: Boolean = false
) {
    companion object {
        val kindNames = listOf("Vokal", "Enstrüman", "Normal ses")
        val prefixes = listOf("Vokal", "Enstruman", "Kayit")
        fun forKind(k: Int): RecConfig = when (k) {
            0 -> RecConfig(0, ns = true)
            1 -> RecConfig(1, source = MediaRecorder.AudioSource.UNPROCESSED)
            else -> RecConfig(2, agc = true, ns = true)
        }
    }
}

object Recorder {
    @Volatile var running = false
    @Volatile var paused = false
    @Volatile var peak = 0f
    @Volatile var frames = 0L
    @Volatile var rate = 44100
    @Volatile var startNanos = 0L
    @Volatile var currentFile: File? = null

    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    private val effects = ArrayList<AudioEffect>()

    val elapsedMs: Long get() = frames * 1000L / max(1, rate)

    fun dir(ctx: Context): File = File(ctx.filesDir, "recordings").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.extension == "wav" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)

    /** Eski çağrılar için: normal ses kaydı. */
    fun start(ctx: Context, onAmp: (Float) -> Unit) {
        start(ctx, RecConfig.forKind(2), "Kayit", onAmp)
    }

    @SuppressLint("MissingPermission")
    fun start(ctx: Context, cfg: RecConfig, prefix: String, onAmp: (Float) -> Unit): Boolean {
        if (running) return false
        val ch = if (cfg.stereo) 2 else 1
        val chMask = if (cfg.stereo) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
        val minB = AudioRecord.getMinBufferSize(cfg.sr, chMask, AudioFormat.ENCODING_PCM_16BIT)
        if (minB <= 0) return false
        fun make(src: Int): AudioRecord? = try {
            AudioRecord(src, cfg.sr, chMask, AudioFormat.ENCODING_PCM_16BIT, max(minB * 2, 16384))
        } catch (ex: Exception) { null }
        var r = make(cfg.source)
        if (r == null || r.state != AudioRecord.STATE_INITIALIZED) {
            r?.release()
            r = make(MediaRecorder.AudioSource.MIC)
        }
        val rec = r ?: return false
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }

        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val pref = if (cfg.deviceId >= 0) ins.firstOrNull { it.id == cfg.deviceId }
        else ins.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
        if (pref != null) rec.setPreferredDevice(pref)

        effects.clear()
        val sid = rec.audioSessionId
        if (cfg.agc && AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.let { it.setEnabled(true); effects.add(it) }
        if (cfg.ns && NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.let { it.setEnabled(true); effects.add(it) }
        if (cfg.aec && AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.let { it.setEnabled(true); effects.add(it) }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        var file = File(dir(ctx), "${prefix}_$stamp.wav")
        var n = 1
        while (file.exists()) { file = File(dir(ctx), "${prefix}_${stamp}_$n.wav"); n++ }
        currentFile = file
        prefs(ctx).edit().putString("active_rec", file.name).putInt("active_sr", cfg.sr).putInt("active_ch", ch).apply()

        val monitor = cfg.monitor && Headphones.usable
        AudioEngine.monitorOn = monitor
        running = true
        paused = false
        frames = 0L
        rate = cfg.sr
        peak = 0f
        rec.startRecording()
        startNanos = System.nanoTime()
        val sr = cfg.sr
        val gain = cfg.gain
        thread = Thread {
            val raf = RandomAccessFile(file, "rw")
            raf.write(ByteArray(44))
            val buf = ShortArray(1024 * ch)
            val bytes = ByteArray(buf.size * 2)
            var total = 0L
            var sinceHdr = 0L
            while (running) {
                val cnt = rec.read(buf, 0, buf.size)
                if (cnt <= 0) continue
                var pk = 0
                for (i in 0 until cnt) {
                    var s = (buf[i] * gain).toInt()
                    if (s > 32767) s = 32767 else if (s < -32768) s = -32768
                    buf[i] = s.toShort()
                    if (abs(s) > pk) pk = abs(s)
                }
                if (!paused) {
                    for (i in 0 until cnt) {
                        val s = buf[i].toInt()
                        bytes[2 * i] = (s and 0xff).toByte()
                        bytes[2 * i + 1] = ((s shr 8) and 0xff).toByte()
                    }
                    raf.write(bytes, 0, cnt * 2)
                    total += cnt * 2L
                    sinceHdr += cnt * 2L
                    frames += (cnt / ch).toLong()
                    if (monitor) {
                        var k = 0
                        while (k < cnt) {
                            var m = buf[k].toFloat()
                            if (ch == 2) m = (m + buf[k + 1]) * 0.5f
                            AudioEngine.monitorPush(m / 32768f)
                            k += ch
                        }
                    }
                    // Çökme durumunda kayıt çalınabilir kalsın: başlığı düzenli güncelle
                    if (sinceHdr >= sr * ch * 2L) {
                        raf.seek(0); raf.write(header(total, sr, ch)); raf.seek(44 + total)
                        sinceHdr = 0L
                    }
                }
                peak = pk / 32768f
                val a = peak
                main.post { onAmp(a) }
            }
            raf.seek(0); raf.write(header(total, sr, ch)); raf.close()
            rec.stop()
            rec.release()
            for (ef in effects) ef.release()
            effects.clear()
            AudioEngine.monitorOn = false
        }.also { it.start() }
        return true
    }

    fun pause() { paused = true }
    fun resume() { paused = false }

    /** Kaydı bitirir; dosya zaten kaydedilmiştir. */
    fun finish(ctx: Context? = null): File? {
        if (!running) return null
        running = false
        thread?.join()
        thread = null
        paused = false
        ctx?.let { prefs(it).edit().remove("active_rec").apply() }
        return currentFile
    }

    fun stop() { finish(null) }

    /** Önceki oturumda kayıt beklenmedik şekilde kesildiyse dosyayı onarır, adını döner. */
    fun recoverIfNeeded(ctx: Context): String? {
        val sp = prefs(ctx)
        val name = sp.getString("active_rec", null) ?: return null
        sp.edit().remove("active_rec").apply()
        val f = File(dir(ctx), name)
        if (!f.exists() || f.length() <= 48) { f.delete(); return null }
        val sr = sp.getInt("active_sr", 44100)
        val ch = sp.getInt("active_ch", 1)
        val data = (f.length() - 44) / (2L * ch) * (2L * ch)
        return try {
            RandomAccessFile(f, "rw").use { it.seek(0); it.write(header(data, sr, ch)) }
            name
        } catch (ex: Exception) { null }
    }

    fun header(dataLen: Long, sr: Int, ch: Int): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
        b.putInt(16); b.putShort(1); b.putShort(ch.toShort())
        b.putInt(sr); b.putInt(sr * ch * 2); b.putShort((ch * 2).toShort()); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen.toInt())
        return b.array()
    }
}
