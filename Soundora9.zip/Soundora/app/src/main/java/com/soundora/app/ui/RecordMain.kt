package com.soundora.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.soundora.app.audio.Arranger
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Headphones
import com.soundora.app.audio.ProjectStore
import com.soundora.app.audio.RecConfig
import com.soundora.app.audio.RecFiles
import com.soundora.app.audio.Recorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.log10

private fun inputName(type: Int): String = when (type) {
    15 -> "Telefon mikrofonu"
    3 -> "Kulaklık mikrofonu"
    7 -> "Bluetooth mikrofon"
    11, 22 -> "USB mikrofon"
    else -> "Mikrofon"
}

@Composable
fun RecordMainPanel(onEdit: (File) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val adv = AppPrefs.advanced
    var kind by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0f) }
    var clipUntil by remember { mutableLongStateOf(0L) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var tick by remember { mutableIntStateOf(0) }
    val wave = remember { FloatArray(160) }
    var last by remember { mutableStateOf<File?>(null) }
    var msg by remember { mutableStateOf("") }
    var sr by remember { mutableIntStateOf(44100) }
    var stereo by remember { mutableStateOf(false) }
    var gain by remember { mutableFloatStateOf(1f) }
    var source by remember { mutableIntStateOf(MediaRecorder.AudioSource.MIC) }
    var agc by remember { mutableStateOf(false) }
    var ns by remember { mutableStateOf(true) }
    var aec by remember { mutableStateOf(false) }
    var deviceId by remember { mutableIntStateOf(-1) }
    var monitor by remember { mutableStateOf(false) }
    val recState = rememberUpdatedState(recording)
    @Suppress("UNUSED_VARIABLE") val subscribe = tick

    LaunchedEffect(kind) {
        val d = RecConfig.forKind(kind)
        source = d.source; agc = d.agc; ns = d.ns; aec = d.aec
    }
    LaunchedEffect(recording) { while (recording) { elapsed = Recorder.elapsedMs; delay(100) } }
    SideEffect { view.keepScreenOn = recording }
    DisposableEffect(Unit) { onDispose { if (recState.value) Recorder.finish(ctx); view.keepScreenOn = false } }

    fun config(): RecConfig {
        val d = RecConfig.forKind(kind)
        return if (!adv) d else d.copy(sr = sr, stereo = stereo, gain = gain, source = source, agc = agc, ns = ns, aec = aec, deviceId = deviceId, monitor = monitor)
    }
    fun begin() {
        val ok = Recorder.start(ctx, config(), RecConfig.prefixes[kind]) { a ->
            level = a
            if (a >= 0.98f) clipUntil = SystemClock.uptimeMillis() + 1500
            System.arraycopy(wave, 1, wave, 0, wave.size - 1)
            wave[wave.size - 1] = a
            tick++
        }
        if (ok) { recording = true; paused = false; msg = ""; last = null; elapsed = 0L }
        else msg = "Kayıt başlatılamadı. Mikrofon başka bir uygulamada kullanılıyor olabilir."
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else msg = "Kayıt için mikrofon izni gerekli. Ayarlardan izin verebilirsin."
    }
    fun toggleStart() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
        else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun finish() {
        val f = Recorder.finish(ctx)
        recording = false; paused = false; level = 0f
        last = f
        msg = if (f != null) "Kayıt otomatik kaydedildi ✓" else ""
    }

    val clipping = SystemClock.uptimeMillis() < clipUntil
    val db = if (level <= 0.0005f) -60f else 20f * log10(level)
    val frac = ((db + 60f) / 60f).coerceIn(0f, 1f)
    val barCol = if (db > -3f) Color(0xFFEF4444) else if (db > -12f) Color(0xFFF59E0B) else Color(0xFF22C55E)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Ses Kaydet", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ne kaydedeceksin? Ayarlar otomatik seçilir.", fontSize = 12.sp, color = Color(0xFF9CA3AF))
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("🎤 Vokal" to "Şarkı söyle veya konuş", "🎸 Enstrüman" to "Gitar, piyano ve diğerleri", "🔉 Normal ses" to "Genel ses kaydı").forEachIndexed { i, (n, _) ->
                FilterChip(selected = kind == i, enabled = !recording, onClick = { kind = i }, label = { Text(n) })
            }
        }
        Text(listOf("Şarkı söylemek ve konuşmak için.", "Gitar, piyano ve diğer enstrümanlar için (ses işlenmeden kaydedilir).", "Genel ses kayıtları için (ses seviyesi otomatik dengelenir).")[kind],
            fontSize = 12.sp, color = Color(0xFF9CA3AF), textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))

        // ---- Dalga biçimi + süre
        RecCard {
            Text(RecFiles.fmt(elapsed), fontSize = 40.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            if (paused) Text("⏸ Duraklatıldı", color = Color(0xFFF59E0B), modifier = Modifier.align(Alignment.CenterHorizontally))
            PeaksView(wave, Modifier.fillMaxWidth().height(100.dp), if (clipping) Color(0xFFEF4444) else Purple)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF232C52))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(barCol))
            }
            Text(String.format("Mikrofon seviyesi: %.0f dB", db), fontSize = 11.sp, color = Color(0xFF9CA3AF))
            if (clipping) Text("⚠ Ses çok yüksek (bozulma olabilir)! Mikrofondan uzaklaş veya giriş seviyesini düşür.", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        // ---- Kontroller
        Spacer(Modifier.height(8.dp))
        if (!recording) {
            Box(
                Modifier.size(120.dp).clip(CircleShape).background(Color(0xFFEF4444)).clickable { toggleStart() },
                contentAlignment = Alignment.Center
            ) { Text("●", fontSize = 56.sp, color = Color.White) }
            Text("Kayda başlamak için dokun", fontSize = 13.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 6.dp))
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(84.dp).clip(CircleShape).background(Color(0xFF232C52))
                        .clickable { if (paused) Recorder.resume() else Recorder.pause(); paused = !paused },
                    contentAlignment = Alignment.Center
                ) { Text(if (paused) "▶" else "⏸", fontSize = 34.sp, color = Color.White) }
                Box(
                    Modifier.size(110.dp).clip(CircleShape).background(Color(0xFFEF4444)).clickable { finish() },
                    contentAlignment = Alignment.Center
                ) { Text("■", fontSize = 50.sp, color = Color.White) }
            }
            Text(if (paused) "Devam etmek için ▶, bitirmek için ■" else "Duraklatmak için ⏸, bitirmek için ■", fontSize = 12.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 6.dp))
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = if (msg.startsWith("Kayıt otomatik")) Color(0xFF22C55E) else Color(0xFFF59E0B), modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)

        // ---- Kayıt sonrası
        val lf = last
        if (lf != null && !recording) {
            RecCard("Son kayıt: ${lf.nameWithoutExtension}", "Kayıt cihazına kaydedildi. Şimdi ne yapmak istersin?") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            val d = withContext(Dispatchers.IO) { RecFiles.readMono(lf) }
                            if (d != null) AudioEngine.previewPcmData(d, AudioEngine.SR)
                        }
                    }) { Text("▶ Dinle") }
                    OutlinedButton(onClick = { onEdit(lf) }) { Text("✂ Düzenle") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            val id = withContext(Dispatchers.IO) { Arranger.addRecording("recordings/${lf.name}", null, false, 0) }
                            if (id >= 0) { ProjectStore.save(ctx); msg = "Projene eklendi ✓ (Müzik Yap'ta çalar)" } else msg = "Projeye eklenemedi."
                        }
                    }) { Text("➕ Projeye ekle") }
                }
            }
        }

        // ---- Gelişmiş kayıt ayarları (yalnızca Gelişmiş mod)
        if (adv) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            RecCard("Gelişmiş kayıt ayarları", "Kolay modda bunlar otomatik seçilir.") {
                Text("Biçim: WAV (kayıpsız)  •  Bit derinliği: 16 bit (şimdilik tek seçenek)", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                Text("Örnekleme hızı", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(44100, 48000).forEach { r -> FilterChip(selected = sr == r, enabled = !recording, onClick = { sr = r }, label = { Text("$r Hz") }) }
                }
                Text("Kanal", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !stereo, enabled = !recording, onClick = { stereo = false }, label = { Text("Mono") })
                    FilterChip(selected = stereo, enabled = !recording, onClick = { stereo = true }, label = { Text("Stereo") })
                }
                Text("Giriş seviyesi ×${String.format("%.1f", gain)}", fontSize = 12.sp)
                Slider(value = gain, onValueChange = { gain = it }, valueRange = 0.2f..3f)
                Text("Mikrofon kaynağı", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(MediaRecorder.AudioSource.MIC to "Mikrofon", MediaRecorder.AudioSource.VOICE_RECOGNITION to "Konuşma", MediaRecorder.AudioSource.UNPROCESSED to "İşlenmemiş", MediaRecorder.AudioSource.CAMCORDER to "Kamera").forEach { (v, n) ->
                        FilterChip(selected = source == v, enabled = !recording, onClick = { source = v }, label = { Text(n) })
                    }
                }
                Text("Mikrofon girişi", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = deviceId < 0, enabled = !recording, onClick = { deviceId = -1 }, label = { Text("Otomatik") })
                    inputs.forEach { d ->
                        FilterChip(selected = deviceId == d.id, enabled = !recording, onClick = { deviceId = d.id }, label = { Text(inputName(d.type)) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Otomatik kazanç kontrolü (AGC)", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Switch(checked = agc, enabled = !recording, onCheckedChange = { agc = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Gürültü azaltma", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Switch(checked = ns, enabled = !recording, onCheckedChange = { ns = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Yankı engelleme", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Switch(checked = aec, enabled = !recording, onCheckedChange = { aec = it })
                }
                Text("Cihazın desteklemediği işlemler (AGC, gürültü azaltma, yankı) sessizce atlanır.", fontSize = 10.sp, color = Color(0xFF6B7280))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kendi sesimi kulaklıkta duy", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Switch(checked = monitor && Headphones.usable, enabled = Headphones.usable && !recording, onCheckedChange = { monitor = it })
                }
                Text(
                    if (Headphones.usable) "Kulaklık algılandı (${Headphones.label}). İzleme sesinde küçük bir gecikme olabilir."
                    else "Bu seçenek için kulaklık bağlı ve ses ona yönlendirilmiş olmalı (hoparlörden geri besleme olmasın diye).",
                    fontSize = 10.sp, color = Color(0xFF6B7280)
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
