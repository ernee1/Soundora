package com.soundora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max

class Note(var start: Int, var len: Int, var pitch: Int)
private class Held(val v: Voice, var left: Int)

object AudioEngine {
    const val SR = 44100
    const val ROWS = 7
    const val MAX_STEPS = 64
    const val KINDS = 11
    val rowNames = listOf("Kick", "Snare", "Clap", "Hi-Hat", "Açık Hat", "Tom", "Rim")
    val kitNames = listOf("Standart", "808 Trap", "Lo-fi", "Elektronik")
    /** kind numarasına göre enstrüman adı */
    val kindNames = listOf("Piyano", "Lead Synth", "Bas Gitar", "Akustik", "Elektro", "E.Piyano", "Org", "Strings", "Pad", "Pluck", "Synth Bas")

    val pattern = Array(ROWS) { BooleanArray(MAX_STEPS) }
    val rowVol = FloatArray(ROWS) { 0.8f }
    val rowMute = BooleanArray(ROWS)
    val rowSolo = BooleanArray(ROWS)
    val melody = CopyOnWriteArrayList<Note>()
    val instVol = FloatArray(KINDS) { 0.8f }
    val adsr = Array(KINDS) { defaultAdsr(it) }

    @Volatile var bpm = 100
    @Volatile var playing = false
    @Volatile var currentStep = -1
    @Volatile var masterVol = 0.8f
    @Volatile var steps = 16
    @Volatile var swing = 0f
    @Volatile var kit = 0
    @Volatile var melodyKind = 0
    @Volatile var pitchSemi = 0f

    private val voices = CopyOnWriteArrayList<Voice>()
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    fun defaultAdsr(kind: Int): FloatArray = when (kind) {
        0 -> floatArrayOf(0.005f, 0.3f, 1f, 0.18f)
        1 -> floatArrayOf(0.01f, 0.2f, 0.7f, 0.2f)
        2 -> floatArrayOf(0.005f, 0.3f, 1f, 0.2f)
        3, 4 -> floatArrayOf(0.002f, 0.5f, 1f, 0.3f)
        5 -> floatArrayOf(0.005f, 0.3f, 1f, 0.25f)
        6 -> floatArrayOf(0.01f, 0.05f, 1f, 0.08f)
        7 -> floatArrayOf(0.35f, 0.3f, 0.9f, 0.6f)
        8 -> floatArrayOf(0.6f, 0.5f, 0.9f, 0.9f)
        9 -> floatArrayOf(0.002f, 0.3f, 1f, 0.2f)
        else -> floatArrayOf(0.005f, 0.2f, 0.8f, 0.12f)
    }

    fun start() {
        if (running) return
        val min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SR)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(max(min, 2048))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        thread = Thread({ loop(t) }, "soundora-audio").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun stop() {
        running = false
        thread?.join()
        track?.let { it.stop(); it.release() }
        track = null
        voices.clear()
        playing = false
        currentStep = -1
    }

    private fun loop(t: AudioTrack) {
        val chunk = ShortArray(256)
        t.play()
        var acc = 0.0
        var step = 0
        var wasPlaying = false
        val held = ArrayList<Held>()
        while (running) {
            val p = playing
            if (p && !wasPlaying) { step = 0; acc = 0.0 }
            if (!p && wasPlaying) {
                currentStep = -1
                for (h in held) h.v.release()
                held.clear()
            }
            wasPlaying = p
            val sps = SR * 60.0 / bpm / 4.0
            val snap = voices.toTypedArray()
            for (i in chunk.indices) {
                if (p) {
                    if (acc <= 0.0) {
                        val n = steps
                        if (step >= n) step = 0
                        triggerStep(step, held)
                        currentStep = step
                        val sw = swing.toDouble()
                        val gap = if (step % 2 == 0) sps * (1.0 + sw) else sps * (1.0 - sw)
                        step = (step + 1) % n
                        acc += gap
                    }
                    acc -= 1.0
                }
                var mix = 0f
                for (v in snap) if (!v.finished) mix += v.render()
                mix *= masterVol
                chunk[i] = (mix.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            }
            t.write(chunk, 0, chunk.size)
            voices.removeIf { it.finished }
        }
    }

    private fun triggerStep(step: Int, held: ArrayList<Held>) {
        val it = held.iterator()
        while (it.hasNext()) {
            val h = it.next()
            h.left--
            if (h.left <= 0) { h.v.release(); it.remove() }
        }
        val anySolo = rowSolo.any { s -> s }
        for (r in 0 until ROWS) {
            if (pattern[r][step] && !rowMute[r] && (!anySolo || rowSolo[r])) addVoice(DrumVoice(r, rowVol[r], kit))
        }
        for (n in melody) {
            if (n.start == step) {
                val v = NoteVoice(melodyKind, n.pitch, pitchSemi.toDouble())
                addVoice(v)
                held.add(Held(v, n.len))
            }
        }
    }

    private fun addVoice(v: Voice) {
        if (voices.size > 48) voices.firstOrNull()?.finished = true
        voices.add(v)
    }

    fun hitDrum(row: Int) = addVoice(DrumVoice(row, rowVol[row], kit))

    fun noteOn(kind: Int, midi: Int): Voice {
        val v = NoteVoice(kind, midi, pitchSemi.toDouble())
        addVoice(v)
        return v
    }

    fun preview(kind: Int, midi: Int) {
        val v = noteOn(kind, midi)
        main.postDelayed({ v.release() }, 300)
    }
}
