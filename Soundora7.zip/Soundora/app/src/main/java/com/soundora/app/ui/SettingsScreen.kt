package com.soundora.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ProjectStore
import java.io.File

private fun dirSize(f: File): Long = f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

private fun fmtSize(b: Long): String =
    if (b >= 1_000_000L) String.format("%.1f MB", b / 1e6) else String.format("%d KB", b / 1000)

private fun storageInfo(ctx: Context): List<Pair<String, Long>> = listOf(
    "Projeler" to dirSize(File(ctx.filesDir, "projects")),
    "Kayıtlar" to dirSize(File(ctx.filesDir, "recordings")),
    "İçe aktarılan sesler" to dirSize(File(ctx.filesDir, "audio"))
)

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text(title, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE) }
    val e = AudioEngine
    var dark by remember { mutableStateOf(ThemeState.dark) }
    var buffer by remember { mutableIntStateOf(e.bufferMode) }
    var auto by remember { mutableStateOf(sp.getBoolean("autosave", true)) }
    var autoSec by remember { mutableIntStateOf(sp.getInt("autosave_sec", 15)) }
    var defBpm by remember { mutableIntStateOf(sp.getInt("default_bpm", 100)) }
    var rate by remember { mutableIntStateOf(sp.getInt("export_rate", 44100)) }
    var msg by remember { mutableStateOf("") }
    var storage by remember { mutableStateOf(storageInfo(ctx)) }
    var confirmClean by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Purple)

        Group("Tema") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = dark, onClick = { dark = true; ThemeState.dark = true; sp.edit().putBoolean("dark", true).apply() }, label = { Text("Koyu") })
                FilterChip(selected = !dark, onClick = { dark = false; ThemeState.dark = false; sp.edit().putBoolean("dark", false).apply() }, label = { Text("Açık") })
            }
            Text("Açık tema temeldir; bazı çizim alanları koyu kalabilir.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Group("Ses kalitesi") {
            Text("Dışa aktarma örnekleme hızı (varsayılan)", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(22050, 44100, 48000).forEach { r ->
                    FilterChip(selected = rate == r, onClick = { rate = r; sp.edit().putInt("export_rate", r).apply() }, label = { Text("$r Hz") })
                }
            }
            Text("Ses motoru 44.1 kHz mono 16-bit çalışır; dışa aktarırken seçtiğin hıza çevrilir.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Group("Ses gecikmesi (tampon)") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Düşük gecikme", "Dengeli", "Kararlı").forEachIndexed { i, n ->
                    FilterChip(selected = buffer == i, onClick = {
                        buffer = i; e.bufferMode = i
                        sp.edit().putInt("buffer", i).apply()
                        e.restart()
                        msg = "Ses motoru yeniden başlatıldı."
                    }, label = { Text(n) })
                }
            }
            Text("Telefonda ses takılıyorsa 'Kararlı', basınca geç duyuyorsan 'Düşük gecikme' seç.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Group("Varsayılan BPM (yeni projeler)") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$defBpm", Modifier.width(48.dp), fontWeight = FontWeight.Bold)
                Slider(
                    value = defBpm.toFloat(), valueRange = 60f..180f,
                    onValueChange = { defBpm = it.toInt() },
                    onValueChangeFinished = { sp.edit().putInt("default_bpm", defBpm).apply() },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Group("Otomatik kayıt") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Projeyi otomatik kaydet", Modifier.weight(1f))
                Switch(checked = auto, onCheckedChange = { auto = it; sp.edit().putBoolean("autosave", it).apply() })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 15, 30, 60).forEach { s ->
                    FilterChip(selected = autoSec == s, onClick = { autoSec = s; sp.edit().putInt("autosave_sec", s).apply() }, label = { Text("$s sn") })
                }
            }
            Text("Değişiklik sonraki döngüde geçerli olur. Uygulamadan çıkarken her zaman kaydedilir.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Group("Dil") {
            Text("Türkçe (şimdilik tek dil)")
        }

        Group("Depolama") {
            storage.forEach { (n, b) -> Text("$n: ${fmtSize(b)}", fontSize = 13.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { storage = storageInfo(ctx) }) { Text("Yenile") }
                OutlinedButton(onClick = { confirmClean = true }) { Text("Kullanılmayanları temizle") }
            }
            Text("Hiçbir projede kullanılmayan kayıt ve içe aktarılan dosyaları siler.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Group("Hakkında") {
            Text("Soundora 0.5", fontWeight = FontWeight.Bold)
            Text("Beat Maker, Piano Roll, çok kanallı Studio, kanal efektleri, ses kütüphanesi, öğrenme bölümü, akıllı araçlar ve dışa aktarma (WAV, M4A, MIDI). İnternet gerektirmez.", fontSize = 12.sp)
            Text("Not: Android'de MP3 kodlayıcısı olmadığı için dışa aktarmada MP3 yerine M4A (AAC) sunulur. MP3 dosyalarını içe aktarabilirsin.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }
        Spacer(Modifier.height(16.dp))
    }

    if (confirmClean) {
        AlertDialog(
            onDismissRequest = { confirmClean = false },
            title = { Text("Temizlensin mi?") },
            text = { Text("Hiçbir projede kullanılmayan ses dosyaları silinir. Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(onClick = {
                    ProjectStore.save(ctx)
                    val text = StringBuilder()
                    File(ctx.filesDir, "projects").listFiles()?.forEach { f -> if (f.extension == "json") text.append(f.readText()) }
                    val all = text.toString()
                    var freed = 0L
                    var count = 0
                    for (sub in listOf("recordings", "audio")) {
                        File(ctx.filesDir, sub).listFiles()?.forEach { f ->
                            if (f.isFile && !all.contains("$sub/${f.name}")) { freed += f.length(); count++; f.delete() }
                        }
                    }
                    msg = "$count dosya silindi (${fmtSize(freed)})."
                    storage = storageInfo(ctx)
                    confirmClean = false
                }) { Text("Temizle") }
            },
            dismissButton = { TextButton(onClick = { confirmClean = false }) { Text("İptal") } }
        )
    }
}
