package com.soundora.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

@Composable
fun RecCard(title: String? = null, hint: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        if (title != null) Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (hint != null) Text(hint, fontSize = 11.sp, color = Color(0xFF9CA3AF))
        content()
    }
}

/** Tepe değerlerinden (0..1) dalga biçimi çizer; sel0/sel1 (0..1) seçili aralığı gösterir. */
@Composable
fun PeaksView(peaks: FloatArray, modifier: Modifier, color: Color = Purple, sel0: Float = -1f, sel1: Float = -1f) {
    Canvas(modifier) {
        val n = peaks.size
        if (n == 0) return@Canvas
        val w = size.width
        val h = size.height
        val bw = w / n
        for (i in 0 until n) {
            val a = (peaks[i].coerceIn(0f, 1f) * h).coerceAtLeast(2f)
            drawLine(color, Offset(i * bw + bw / 2, (h - a) / 2), Offset(i * bw + bw / 2, (h + a) / 2), max(1f, bw * 0.7f))
        }
        if (sel0 >= 0f && sel1 > sel0) {
            drawRect(Color.White.copy(alpha = 0.14f), Offset(sel0 * w, 0f), Size((sel1 - sel0) * w, h))
            drawLine(Color.White, Offset(sel0 * w, 0f), Offset(sel0 * w, h), 3f)
            drawLine(Color.White, Offset(sel1 * w, 0f), Offset(sel1 * w, h), 3f)
        }
    }
}
