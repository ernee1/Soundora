package com.soundora.app.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Kulaklık durumu. "usable" = kulaklık bağlı VE uygulamanın ses çıkışı gerçekten ona yönlendirilmiş
 * (AudioTrack.getRoutedDevice ile doğrulanır; sadece bağlı görünmesi yetmez).
 */
object Headphones {
    // 3 kablolu headset, 4 kablolu kulaklık, 7 BT SCO, 8 BT A2DP, 11 USB cihaz, 22 USB headset, 26 BLE headset
    private val ids = setOf(3, 4, 7, 8, 11, 22, 26)

    var connected by mutableStateOf(false)
    var routed by mutableStateOf(false)
    var bluetooth by mutableStateOf(false)
    var label by mutableStateOf("Bağlı değil")
    val usable: Boolean get() = connected && routed

    var onRemoved: (() -> Unit)? = null
    private var registered = false

    fun refresh(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val h = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in ids }
        connected = h.isNotEmpty()
        bluetooth = h.any { it.type == 7 || it.type == 8 || it.type == 26 }
        val wired = h.any { it.type == 3 || it.type == 4 || it.type == 22 || it.type == 11 }
        label = if (!connected) "Bağlı değil" else if (wired) "Kablolu kulaklık" else "Bluetooth kulaklık"
        routed = connected && AudioEngine.routedType() in ids
    }

    fun register(ctx: Context) {
        if (registered) { refresh(ctx); return }
        registered = true
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { refresh(ctx) }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                val had = usable
                refresh(ctx)
                if (had && !usable) onRemoved?.invoke()
            }
        }
        am.registerAudioDeviceCallback(cb, Handler(Looper.getMainLooper()))
        refresh(ctx)
    }
}
