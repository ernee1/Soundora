package com.soundora.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ProjectStore
import com.soundora.app.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.baseDir = filesDir
        ProjectStore.init(this)
        AudioEngine.start()
        setContent { SoundoraTheme { SoundoraApp() } }
    }

    override fun onStop() {
        super.onStop()
        AudioEngine.playing = false
        ProjectStore.save(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) AudioEngine.stop()
    }
}

@Composable
fun SoundoraApp() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pv by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(15000); ProjectStore.save(ctx) } }
    val items = listOf("🥁" to "Beat", "🎼" to "Roll", "🎚" to "Studio", "🎹" to "Enst.", "🎤" to "Kayıt", "📁" to "Proje")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                items.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon) }, label = { Text(label, fontSize = 10.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            key(pv) {
                when (tab) {
                    0 -> BeatScreen()
                    1 -> PianoRollScreen()
                    2 -> StudioScreen()
                    3 -> InstrumentScreen()
                    4 -> RecordScreen()
                    else -> ProjectsScreen { pv++ }
                }
            }
        }
    }
}
