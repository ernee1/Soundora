package com.soundora.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** YIN algoritmasıyla temel frekans (Hz) bulur. Sinyal yoksa/belirsizse -1 döner. */
object PitchDetector {
    fun detect(buf: FloatArray, sr: Int, fMin: Double, fMax: Double): Double {
        val w = 2048
        val minTau = max(2, (sr / fMax).toInt())
        val maxTau = min(buf.size - w - 2, (sr / fMin).toInt() + 1)
        if (maxTau <= minTau + 2) return -1.0
        val c = FloatArray(maxTau + 2)
        var run = 0f
        c[0] = 1f
        for (tau in 1..maxTau) {
            var s = 0f
            for (j in 0 until w) {
                val x = buf[j] - buf[j + tau]
                s += x * x
            }
            run += s
            c[tau] = if (run <= 1e-12f) 1f else s * tau / run
        }
        var tau = -1
        var t = minTau
        while (t < maxTau) {
            if (c[t] < 0.15f) {
                while (t + 1 < maxTau && c[t + 1] < c[t]) t++
                tau = t
                break
            }
            t++
        }
        if (tau < 0) return -1.0
        val a = c[tau - 1]
        val b = c[tau]
        val d = c[tau + 1]
        val den = a - 2 * b + d
        val shift = if (den != 0f) (0.5f * (a - d) / den).toDouble().coerceIn(-1.0, 1.0) else 0.0
        return sr / (tau + shift)
    }
}

/** Mikrofonu dinler, her ~46 ms'de bir frekans ölçümü verir (ana iş parçacığına). */
class TunerEngine {
    @Volatile private var running = false
    @Volatile var fMin = 30.0
    @Volatile var fMax = 1200.0
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    @SuppressLint("MissingPermission")
    fun start(onResult: (Double, Float) -> Unit): Boolean {
        if (running) return true
        val sr = 44100
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 16384)
            )
        } catch (ex: Exception) { return false }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }
        running = true
        rec.startRecording()
        thread = Thread {
            val hop = 2048
            val n = 4096
            val frame = FloatArray(n)
            val tmp = ShortArray(hop)
            var filled = 0
            while (running) {
                val r = rec.read(tmp, 0, hop)
                if (r <= 0) continue
                System.arraycopy(frame, r, frame, 0, n - r)
                for (i in 0 until r) frame[n - r + i] = tmp[i] / 32768f
                filled = min(n, filled + r)
                if (filled < n) continue
                var sum = 0.0
                for (v in frame) sum += v * v
                val rms = sqrt(sum / n).toFloat()
                val f = if (rms > 0.01f) PitchDetector.detect(frame, sr, fMin, fMax) else -1.0
                main.post { onResult(f, rms) }
            }
            rec.stop()
            rec.release()
        }.also { it.start() }
        return true
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
    }
}
