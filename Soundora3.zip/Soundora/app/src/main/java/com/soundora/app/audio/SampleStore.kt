package com.soundora.app.audio

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** 16-bit PCM WAV dosyalarını belleğe (mono, 44.1 kHz) yükler. */
object SampleStore {
    class Sample(val data: ShortArray, val peaks: FloatArray)

    private val cache = HashMap<String, Sample>()
    private val failed = HashSet<String>()

    fun file(rel: String): File = File(AudioEngine.baseDir, rel)

    @Synchronized fun peek(rel: String): Sample? = cache[rel]
    @Synchronized fun isFailed(rel: String): Boolean = failed.contains(rel)

    @Synchronized fun get(rel: String): Sample? {
        cache[rel]?.let { return it }
        if (failed.contains(rel)) return null
        val f = file(rel)
        val s = try { if (f.exists()) loadWav(f) else null } catch (ex: Throwable) { null }
        if (s == null) failed.add(rel) else cache[rel] = s
        return s
    }

    @Synchronized fun forget(rel: String) { cache.remove(rel); failed.remove(rel) }

    fun importFrom(ctx: Context, uri: Uri): String? {
        try {
            var name = "ses_${System.currentTimeMillis()}"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) name = n.substringBeforeLast('.')
                }
            }
            name = name.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_")
            val dir = File(ctx.filesDir, "audio").apply { mkdirs() }
            var f = File(dir, "$name.wav")
            var i = 1
            while (f.exists()) { f = File(dir, "${name}_$i.wav"); i++ }
            val ins = ctx.contentResolver.openInputStream(uri) ?: return null
            ins.use { input -> f.outputStream().use { out -> input.copyTo(out) } }
            val rel = "audio/${f.name}"
            if (get(rel) == null) { f.delete(); forget(rel); return null }
            return rel
        } catch (ex: Exception) {
            return null
        }
    }

    private fun loadWav(f: File): Sample? {
        if (f.length() > 150_000_000L) return null
        val b = f.readBytes()
        if (b.size < 44) return null
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        if (String(b, 0, 4) != "RIFF" || String(b, 8, 4) != "WAVE") return null
        var pos = 12
        var ch = 1
        var sr = 44100
        var bits = 16
        var fmt = 1
        var dataOff = -1
        var dataLen = 0
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4)
            val sz = bb.getInt(pos + 4)
            if (id == "fmt ") {
                fmt = bb.getShort(pos + 8).toInt()
                ch = bb.getShort(pos + 10).toInt()
                sr = bb.getInt(pos + 12)
                bits = bb.getShort(pos + 22).toInt()
            } else if (id == "data") {
                dataOff = pos + 8
                dataLen = if (sz < 0 || dataOff + sz > b.size) b.size - dataOff else sz
                break
            }
            if (sz < 0) break
            pos += 8 + sz + (sz and 1)
        }
        if (dataOff < 0 || fmt != 1 || bits != 16 || ch < 1 || ch > 2) return null
        val frames = dataLen / (2 * ch)
        if (frames <= 0) return null
        var mono = ShortArray(frames) { i ->
            var sum = 0
            for (c in 0 until ch) sum += bb.getShort(dataOff + (i * ch + c) * 2).toInt()
            (sum / ch).toShort()
        }
        if (sr != 44100 && sr > 0) {
            val ratio = sr / 44100.0
            val src = mono
            val newLen = (src.size / ratio).toInt()
            if (newLen <= 0) return null
            mono = ShortArray(newLen) { i ->
                val x = i * ratio
                val i0 = x.toInt()
                val i1 = min(i0 + 1, src.size - 1)
                val fr = x - i0
                (src[i0] * (1 - fr) + src[i1] * fr).toInt().toShort()
            }
        }
        val maxLen = 44100 * 300
        if (mono.size > maxLen) mono = mono.copyOf(maxLen)
        val data = mono
        val n = data.size
        val peaks = FloatArray((n + 511) / 512) { k ->
            var m = 0
            val s0 = k * 512
            val e0 = min(n, s0 + 512)
            for (i in s0 until e0) m = max(m, abs(data[i].toInt()))
            m / 32768f
        }
        return Sample(data, peaks)
    }
}
