package com.soundora.app.audio

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** WAV / MP3 / M4A dosyalarını belleğe (mono, 44.1 kHz) yükler. */
object SampleStore {
    class Sample(val data: ShortArray, val peaks: FloatArray)

    private val cache = HashMap<String, Sample>()
    private val failed = HashSet<String>()

    fun file(rel: String): File = File(AudioEngine.baseDir, rel)

    @Synchronized fun peek(rel: String): Sample? = cache[rel]
    @Synchronized fun isFailed(rel: String): Boolean = failed.contains(rel)

    @Synchronized fun get(rel: String): Sample? {
        cache[rel]?.let { return it }
        if (failed.contains(rel)) return null
        val f = file(rel)
        val s = try { if (f.exists()) load(f) else null } catch (ex: Throwable) { null }
        if (s == null) failed.add(rel) else cache[rel] = s
        return s
    }

    @Synchronized fun forget(rel: String) { cache.remove(rel); failed.remove(rel) }

    fun importFrom(ctx: Context, uri: Uri): String? {
        try {
            var name = "ses_${System.currentTimeMillis()}"
            var ext = "wav"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) {
                        name = n.substringBeforeLast('.')
                        if (n.contains('.')) ext = n.substringAfterLast('.').lowercase()
                    }
                }
            }
            name = name.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_")
            ext = ext.replace(Regex("[^a-z0-9]"), "")
            if (ext.isEmpty()) ext = "wav"
            val dir = File(ctx.filesDir, "audio").apply { mkdirs() }
            var f = File(dir, "$name.$ext")
            var i = 1
            while (f.exists()) { f = File(dir, "${name}_$i.$ext"); i++ }
            val ins = ctx.contentResolver.openInputStream(uri) ?: return null
            ins.use { input -> f.outputStream().use { out -> input.copyTo(out) } }
            val rel = "audio/${f.name}"
            if (get(rel) == null) { f.delete(); forget(rel); return null }
            return rel
        } catch (ex: Exception) {
            return null
        }
    }

    private fun load(f: File): Sample? {
        if (f.length() > 150_000_000L) return null
        val raw = AudioDecoder.decode(f) ?: return null
        var mono = raw.data
        val sr = raw.sr
        if (sr != 44100 && sr > 0) {
            val ratio = sr / 44100.0
            val src = mono
            val newLen = (src.size / ratio).toInt()
            if (newLen <= 0) return null
            mono = ShortArray(newLen) { i ->
                val x = i * ratio
                val i0 = x.toInt()
                val i1 = min(i0 + 1, src.size - 1)
                val fr = x - i0
                (src[i0] * (1 - fr) + src[i1] * fr).toInt().toShort()
            }
        }
        val maxLen = 44100 * 300
        if (mono.size > maxLen) mono = mono.copyOf(maxLen)
        val data = mono
        val n = data.size
        if (n <= 0) return null
        val peaks = FloatArray((n + 511) / 512) { k ->
            var m = 0
            val s0 = k * 512
            val e0 = min(n, s0 + 512)
            for (i in s0 until e0) m = max(m, abs(data[i].toInt()))
            m / 32768f
        }
        return Sample(data, peaks)
    }
}
