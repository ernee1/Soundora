# Soundora (Aşama 3)
Beat Maker: 16/32/64 adım, swing, solo/mute, 4 davul kiti, kalıp A-D (ritim+melodi).
Piano Roll: nota ekle/sil/taşı/uzat, quantize, ızgara, zoom, kaydırma, gam + Scale Lock.
Enstrümanlar: 11 ses (piyano, e.piyano, org, strings, pad, pluck, lead, synth bas, bas, akustik, elektro) + davul;
her biri için ADSR, pitch, ses seviyesi, preset.
Henüz yok: multitrack, efektler, proje kaydı, dışa aktarma, ses kütüphanesi, öğrenme, ayarlar.
