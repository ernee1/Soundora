package com.soundora.app.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ClipVoice
import com.soundora.app.audio.Clip
import com.soundora.app.audio.DrumVoice
import com.soundora.app.audio.FxVoice
import com.soundora.app.audio.History
import com.soundora.app.audio.NoteVoice
import com.soundora.app.audio.Render
import com.soundora.app.audio.SampleStore
import com.soundora.app.audio.Track
import com.soundora.app.audio.Voice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class LibItem(val cat: String, val name: String, val make: () -> Voice, val rel: Double, val maxSec: Double)

private val cats = listOf("Drums", "Bass", "Piano", "Synth", "Percussion", "FX", "Ambient", "Vocals")

private val libItems: List<LibItem> by lazy {
    val l = ArrayList<LibItem>()
    val kits = AudioEngine.kitNames
    val rows = AudioEngine.rowNames
    for (k in 0 until 4) {
        for (r in listOf(0, 1, 2, 3)) l.add(LibItem("Drums", "${kits[k]} ${rows[r]}", { DrumVoice(r, 0.9f, k) }, -1.0, 1.0))
        for (r in listOf(4, 5, 6)) l.add(LibItem("Percussion", "${kits[k]} ${rows[r]}", { DrumVoice(r, 0.9f, k) }, -1.0, 1.0))
    }
    fun note(cat: String, kind: Int, midi: Int, hold: Double, max: Double) {
        l.add(LibItem(cat, AudioEngine.kindNames[kind] + " " + com.soundora.app.audio.MusicTheory.noteName(midi), { NoteVoice(kind, midi, 0.0) }, hold, max))
    }
    for (m in listOf(28, 33, 36)) note("Bass", 10, m, 1.0, 2.5)
    for (m in listOf(28, 33)) note("Bass", 2, m, 1.0, 2.5)
    for (m in listOf(48, 60, 72)) note("Piano", 0, m, 1.2, 4.0)
    note("Piano", 5, 60, 1.2, 3.0); note("Piano", 6, 60, 1.5, 3.0)
    for (m in listOf(60, 72)) { note("Synth", 1, m, 0.8, 2.0); note("Synth", 9, m, 0.5, 2.0) }
    for (m in listOf(48, 60)) note("Synth", 7, m, 2.0, 4.0)
    note("Ambient", 8, 48, 4.0, 7.0); note("Ambient", 8, 60, 4.0, 7.0); note("Ambient", 7, 36, 4.0, 7.0)
    val fxNames = listOf("Riser", "Impact", "Laser", "Düşen süpürme")
    for (i in 0 until 4) l.add(LibItem("FX", fxNames[i], { FxVoice(i) }, -1.0, 3.5))
    l
}

private val previewTrack = Track(-5, "onizleme", 2, solo = true)

private fun addClipToProject(rel: String): String {
    val e = AudioEngine
    val s = SampleStore.get(rel) ?: return "Dosya okunamadı."
    History.push()
    var tr = e.tracks.firstOrNull { it.type == 2 && it.name == "Kütüphane" }
    if (tr == null) {
        tr = Track(e.nextTrackId++, "Kütüphane", 2)
        e.tracks.add(tr)
    }
    e.clips.add(Clip(tr.id, (e.songStep / 4) * 4, 0, 0, rel, 0, s.data.size))
    return "Studio > Timeline'da 'Kütüphane' kanalına eklendi."
}

@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Tümü") }
    var favs by remember { mutableStateOf(HashSet(sp.getStringSet("fav", emptySet()) ?: emptySet())) }
    var msg by remember { mutableStateOf("") }
    var userVer by remember { mutableIntStateOf(0) }

    @Suppress("UNUSED_VARIABLE") val sub = userVer
    val userFiles = ArrayList<Pair<String, String>>()
    File(ctx.filesDir, "recordings").listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach {
        userFiles.add(Pair("recordings/${it.name}", "🎤 " + it.nameWithoutExtension))
    }
    File(ctx.filesDir, "audio").listFiles()?.filter { it.isFile && !it.name.startsWith("lib_") }?.sortedBy { it.name }?.forEach {
        userFiles.add(Pair("audio/${it.name}", "📁 " + it.nameWithoutExtension))
    }

    fun toggleFav(key: String) {
        val n = HashSet(favs)
        if (!n.add(key)) n.remove(key)
        favs = n
        sp.edit().putStringSet("fav", HashSet(n)).apply()
    }
    fun preview(it: LibItem) {
        val v = it.make()
        AudioEngine.playVoice(v)
        if (it.rel >= 0) handler.postDelayed({ v.release() }, (it.rel * 1000).toLong())
    }
    fun previewUser(rel: String) {
        scope.launch {
            val s = withContext(Dispatchers.IO) { SampleStore.get(rel) }
            if (s == null) msg = "Dosya okunamadı." else AudioEngine.playVoice(ClipVoice(s.data, 0, s.data.size, previewTrack))
        }
    }
    fun addItem(it: LibItem) {
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    val pcm = Render.voiceToPcm(it.make, it.rel, it.maxSec)
                    val dir = File(ctx.filesDir, "audio").apply { mkdirs() }
                    val fname = "lib_" + it.name.replace(Regex("[^\\p{L}\\p{N}]"), "_") + ".wav"
                    Render.writeWav(File(dir, fname), pcm, 44100, 16)
                    SampleStore.forget("audio/$fname")
                    addClipToProject("audio/$fname")
                } catch (ex: Throwable) {
                    "Eklenemedi."
                }
            }
            msg = r
        }
    }
    fun addUser(rel: String) {
        scope.launch { msg = withContext(Dispatchers.IO) { addClipToProject(rel) } }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val rel = withContext(Dispatchers.IO) { SampleStore.importFrom(ctx, uri) }
                msg = if (rel != null) "İçe aktarıldı." else "İçe aktarılamadı (WAV/MP3/M4A seç)."
                userVer++
            }
        }
    }

    val q = query.trim().lowercase()
    val shown = libItems.filter { i ->
        (cat == "Tümü" || cat == "Favoriler" || i.cat == cat) &&
            (cat != "Favoriler" || favs.contains(i.name)) &&
            (q.isEmpty() || i.name.lowercase().contains(q))
    }.sortedWith(compareBy({ cats.indexOf(it.cat) }, { it.name }))
    val showUser = (cat == "Tümü" || cat == "Vocals" || cat == "Favoriler") &&
        userFiles.filter { (r, n) -> (cat != "Favoriler" || favs.contains(r)) && (q.isEmpty() || n.lowercase().contains(q)) }.isNotEmpty()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Ses Kütüphanesi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Sesler uygulamanın kendi sentezleyicisinden üretilir (telif sorunu yok). Kendi ses dosyalarını da ekleyebilirsin.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Ara") }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (listOf("Tümü", "Favoriler") + cats).forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { importLauncher.launch(arrayOf("audio/*", "application/octet-stream")) }) { Text("+ Kendi sesimi ekle") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Purple)

        var lastCat = ""
        shown.forEach { it ->
            if (it.cat != lastCat) {
                lastCat = it.cat
                Text(it.cat, fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.padding(top = 8.dp))
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(it.name, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                TextButton(onClick = { preview(it) }) { Text("▶") }
                TextButton(onClick = { toggleFav(it.name) }) { Text(if (favs.contains(it.name)) "★" else "☆") }
                TextButton(onClick = { addItem(it) }) { Text("+ Projeye") }
            }
        }
        if (showUser) {
            Text("Vocals / Kendi seslerim", fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.padding(top = 8.dp))
            userFiles.filter { (r, n) -> (cat != "Favoriler" || favs.contains(r)) && (q.isEmpty() || n.lowercase().contains(q)) }.forEach { (rel, label) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                    TextButton(onClick = { previewUser(rel) }) { Text("▶") }
                    TextButton(onClick = { toggleFav(rel) }) { Text(if (favs.contains(rel)) "★" else "☆") }
                    TextButton(onClick = { addUser(rel) }) { Text("+ Projeye") }
                }
            }
        }
        if (shown.isEmpty() && !showUser) Text("Sonuç yok.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
    }
}
