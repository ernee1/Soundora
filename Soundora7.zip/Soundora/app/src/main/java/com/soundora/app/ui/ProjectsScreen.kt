package com.soundora.app.ui

import android.content.Context
import android.content.Intent
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Generator
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.soundora.app.audio.ProjectStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectsScreen(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(ProjectStore.list(ctx)) }
    var msg by remember { mutableStateOf("") }
    var newOpen by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var tpl by remember { mutableIntStateOf(0) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }
    var deleteId by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")) }

    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            msg = try {
                val n = ProjectStore.restoreZip(ctx, uri)
                list = ProjectStore.list(ctx)
                "$n dosya geri yüklendi."
            } catch (ex: Exception) { "Yedek okunamadı." }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Projeler", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
            Text("Açık proje", fontSize = 12.sp, color = Color(0xFF9CA3AF))
            Text(ProjectStore.currentName, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Otomatik kaydedilir (15 sn'de bir ve uygulamadan çıkınca).", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    ProjectStore.save(ctx); list = ProjectStore.list(ctx); msg = "Kaydedildi."
                }) { Text("Şimdi kaydet") }
                OutlinedButton(onClick = { renameId = ProjectStore.currentId; renameText = ProjectStore.currentName }) { Text("Adı değiştir") }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { newName = "Proje ${list.size + 1}"; tpl = 0; newOpen = true }) { Text("+ Yeni proje") }
            OutlinedButton(onClick = {
                msg = try {
                    val f = ProjectStore.backupZip(ctx)
                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "application/zip"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(i, "Yedeği paylaş / kaydet"))
                    ""
                } catch (ex: Exception) { "Yedek oluşturulamadı." }
            }) { Text("Yedekle") }
            OutlinedButton(onClick = { restore.launch(arrayOf("application/zip", "application/octet-stream")) }) { Text("Yedekten yükle") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Color(0xFF9CA3AF))
        Spacer(Modifier.height(8.dp))
        ExportCard()
        Spacer(Modifier.height(8.dp))
        Text("Tüm projeler", fontWeight = FontWeight.Bold)
        list.forEach { p ->
            val isCur = p.id == ProjectStore.currentId
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(14.dp)).padding(10.dp)) {
                Text(p.name + if (isCur) "  • açık" else "", fontWeight = FontWeight.Bold)
                Text(fmt.format(Date(p.modified)), fontSize = 11.sp, color = Color(0xFF9CA3AF))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!isCur) TextButton(onClick = {
                        ProjectStore.save(ctx)
                        if (ProjectStore.openId(ctx, p.id)) onChanged() else msg = "Proje açılamadı."
                    }) { Text("Aç") }
                    TextButton(onClick = { renameId = p.id; renameText = p.name }) { Text("Ad") }
                    TextButton(onClick = {
                        try {
                            if (isCur) ProjectStore.save(ctx)
                            ProjectStore.duplicate(ctx, p.id, p.name + " kopya")
                            list = ProjectStore.list(ctx)
                        } catch (ex: Exception) { msg = "Kopyalanamadı." }
                    }) { Text("Kopya") }
                    TextButton(onClick = { deleteId = p.id }) { Text("Sil") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (newOpen) {
        AlertDialog(
            onDismissRequest = { newOpen = false },
            title = { Text("Yeni proje") },
            text = {
                Column {
                    OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Proje adı") })
                    Text("Başlangıç şablonu", fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (listOf("Boş") + Generator.genres.map { it.name }).forEachIndexed { i, n ->
                            FilterChip(selected = tpl == i, onClick = { tpl = i }, label = { Text(n) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    ProjectStore.save(ctx)
                    ProjectStore.create(ctx, newName.trim().ifEmpty { "Adsız proje" })
                    AudioEngine.bpm = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE).getInt("default_bpm", 100)
                    if (tpl > 0) Generator.applyTemplate(Generator.genres[tpl - 1])
                    ProjectStore.save(ctx)
                    newOpen = false; onChanged()
                }) { Text("Oluştur") }
            },
            dismissButton = { TextButton(onClick = { newOpen = false }) { Text("İptal") } }
        )
    }
    renameId?.let { id ->
        AlertDialog(
            onDismissRequest = { renameId = null },
            title = { Text("Proje adı") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    try { ProjectStore.rename(ctx, id, renameText.trim().ifEmpty { "Adsız proje" }) } catch (ex: Exception) { msg = "Ad değiştirilemedi." }
                    renameId = null; list = ProjectStore.list(ctx); onChanged()
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { renameId = null }) { Text("İptal") } }
        )
    }
    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            title = { Text("Proje silinsin mi?") },
            text = { Text("Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(onClick = {
                    val wasCurrent = id == ProjectStore.currentId
                    ProjectStore.delete(ctx, id)
                    deleteId = null
                    if (wasCurrent) {
                        val rest = ProjectStore.list(ctx)
                        if (rest.isEmpty() || !ProjectStore.openId(ctx, rest[0].id)) ProjectStore.create(ctx, "Proje 1")
                        onChanged()
                    }
                    list = ProjectStore.list(ctx)
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("İptal") } }
        )
    }
}
