package com.soundora.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.ProjectStore

private class HCard(val route: String, val icon: String, val title: String, val desc: String, val color: Color)

@Composable
private fun HomeCardView(c: HCard, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(Panel)
            .border(1.5.dp, c.color.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
            .clickable { onClick() }.padding(14.dp).heightIn(min = 156.dp)
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(c.color.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Text(c.icon, fontSize = 26.sp)
        }
        Spacer(Modifier.height(10.dp))
        Text(c.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(c.desc, fontSize = 12.sp, color = Color(0xFF9CA3AF))
    }
}

@Composable
fun HomeScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var showGlossary by remember { mutableStateOf(false) }
    val cards = buildList {
        add(HCard("make", "🎵", "Müzik Yap", "Kendi ritmini ve melodini oluştur.", Color(0xFF8B5CF6)))
        add(HCard("tuner", "🎯", "Akort Cihazı", "Enstrümanını kolayca akort et.", Color(0xFF22C55E)))
        add(HCard("instr", "🎹", "Enstrümanlar", "Piyano, gitar ve davul çal.", Color(0xFF3B82F6)))
        add(HCard("record", "🎤", "Ses Kaydet", "Mikrofonunla sesini kaydet.", Color(0xFFEF4444)))
        add(HCard("projects", "📁", "Projelerim", "Müziklerini aç, sakla ve paylaş.", Color(0xFFF59E0B)))
        add(HCard("learn", "🎓", "Öğren", "Müzik yapmayı adım adım öğren.", Color(0xFF22D3EE)))
        if (AppPrefs.advanced) {
            add(HCard("studio", "🎚", "Stüdyo", "Melodi çizici, mikser, otomasyon ve efektler.", Color(0xFFEC4899)))
            add(HCard("library", "🔊", "Ses Kütüphanesi", "Hazır sesleri dinle ve projene ekle.", Color(0xFF10B981)))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Soundora", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Purple)
                Text("Merhaba! Bugün ne yapmak istersin?", fontSize = 14.sp, color = Color(0xFF9CA3AF))
            }
            TextButton(onClick = { go("settings") }) { Text("⚙ Ayarlar") }
        }
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Devam et", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                Text(ProjectStore.currentName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Button(onClick = { go("make") }) { Text("▶ Aç") }
        }
        Spacer(Modifier.height(12.dp))

        cards.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { c -> HomeCardView(c, Modifier.weight(1f)) { go(c.route) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp)) {
            Text("Kullanım modu", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !AppPrefs.advanced, onClick = { AppPrefs.setAdvanced(ctx, false) }, label = { Text("Kolay mod") })
                FilterChip(selected = AppPrefs.advanced, onClick = { AppPrefs.setAdvanced(ctx, true) }, label = { Text("Gelişmiş mod") })
            }
            Text(
                if (AppPrefs.advanced) "Gelişmiş mod açık: Stüdyo (melodi çizici, mikser, otomasyon, efektler, ölçüm) ve Ses Kütüphanesi görünür."
                else "Kolay mod açık: sadece temel araçlar görünür. Profesyonel özellikler için Gelişmiş moda geç.",
                fontSize = 12.sp, color = Color(0xFF9CA3AF)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { AppPrefs.resetGuide(ctx) }) { Text("Rehberi tekrar göster") }
                TextButton(onClick = { showGlossary = true }) { Text("Müzik sözlüğü") }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    if (showGlossary) GlossaryDialog { showGlossary = false }
}
