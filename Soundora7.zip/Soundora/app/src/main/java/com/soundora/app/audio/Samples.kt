package com.soundora.app.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max

/** Mono 16-bit ses verisi. */
class Sample(val data: ShortArray, val sr: Int) {
    val durationSec: Double = data.size.toDouble() / sr
    val peaks: FloatArray = FloatArray((data.size.toLong() * PEAK_RATE / sr).toInt() + 2).also { pk ->
        val per = sr.toDouble() / PEAK_RATE
        for (i in pk.indices) {
            val a = (i * per).toInt()
            val b = minOf(data.size, ((i + 1) * per).toInt() + 1)
            var m = 0
            var j = a
            while (j < b) { m = max(m, abs(data[j].toInt())); j++ }
            pk[i] = m / 32768f
        }
    }

    companion object { const val PEAK_RATE = 50 }
}

object AudioCache {
    private val map = ConcurrentHashMap<String, Sample>()
    private var root: File? = null

    fun init(ctx: Context) { root = ctx.filesDir }
    fun fileOf(rel: String): File = File(root, rel)
    fun peek(rel: String): Sample? = map[rel]

    /** Arka plan iş parçacığında çağır (diskten okur ve çözer). */
    fun load(rel: String): Sample? {
        map[rel]?.let { return it }
        val f = fileOf(rel)
        if (!f.exists()) return null
        val s = AudioDecoder.decode(f)
        if (s != null) map[rel] = s
        return s
    }
}

object AudioDecoder {
    fun decode(f: File): Sample? = try {
        if (isWav(f)) readWav(f) else readCodec(f)
    } catch (e: Exception) {
        null
    }

    private fun isWav(f: File): Boolean {
        val h = ByteArray(12)
        f.inputStream().use { if (it.read(h) < 12) return false }
        return String(h, 0, 4) == "RIFF" && String(h, 8, 4) == "WAVE"
    }

    private fun readWav(f: File): Sample? {
        val bytes = f.readBytes()
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12
        var ch = 1
        var sr = 44100
        var bits = 16
        var fmtOk = false
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4)
            var size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                val format = bb.getShort(body).toInt()
                ch = bb.getShort(body + 2).toInt()
                sr = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
                fmtOk = format == 1 && bits == 16 && ch in 1..2
            } else if (id == "data") {
                if (!fmtOk) return null
                if (size <= 0 || body + size > bytes.size) size = bytes.size - body
                val frames = size / (2 * ch)
                if (frames <= 0 || frames > sr * 600) return null
                val out = ShortArray(frames)
                for (i in 0 until frames) {
                    if (ch == 1) out[i] = bb.getShort(body + i * 2)
                    else {
                        val l = bb.getShort(body + i * 4).toInt()
                        val r = bb.getShort(body + i * 4 + 2).toInt()
                        out[i] = ((l + r) / 2).toShort()
                    }
                }
                return Sample(out, sr)
            }
            pos = body + size + (size and 1)
        }
        return null
    }

    private fun readCodec(f: File): Sample? {
        val ex = MediaExtractor()
        ex.setDataSource(f.absolutePath)
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val tf = ex.getTrackFormat(i)
            val mime = tf.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) { idx = i; fmt = tf; break }
        }
        val format = fmt
        if (idx < 0 || format == null) { ex.release(); return null }
        ex.selectTrack(idx)
        val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(format, null, null, 0)
        codec.start()
        var sr = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var buf = ShortArray(sr * 10)
        var total = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        var tooLong = false
        while (!outDone) {
            if (!inDone) {
                val ii = codec.dequeueInputBuffer(10000)
                if (ii >= 0) {
                    val ib = codec.getInputBuffer(ii)!!
                    val n = ex.readSampleData(ib, 0)
                    if (n < 0) {
                        codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val oi = codec.dequeueOutputBuffer(info, 10000)
            if (oi >= 0) {
                val ob = codec.getOutputBuffer(oi)!!
                ob.position(info.offset)
                ob.limit(info.offset + info.size)
                val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                val arr = ShortArray(sb.remaining())
                sb.get(arr)
                val frames = arr.size / max(1, ch)
                if (total + frames > buf.size) buf = buf.copyOf(max(buf.size * 2, total + frames))
                for (i in 0 until frames) {
                    var sum = 0
                    for (c in 0 until ch) sum += arr[i * ch + c].toInt()
                    buf[total + i] = (sum / ch).toShort()
                }
                total += frames
                codec.releaseOutputBuffer(oi, false)
                if (total > sr * 600) { tooLong = true; outDone = true }
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val nf = codec.outputFormat
                sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
        }
        codec.stop(); codec.release(); ex.release()
        if (tooLong || total == 0) return null
        return Sample(buf.copyOf(total), sr)
    }
}
