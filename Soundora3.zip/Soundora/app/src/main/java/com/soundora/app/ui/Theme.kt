package com.soundora.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)
val Navy = Color(0xFF0B1020)
val Panel = Color(0xFF141B33)
val RowColors = listOf(
    Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF22D3EE),
    Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFF8B5CF6)
)

@Composable
fun SoundoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Blue,
            background = Navy, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
