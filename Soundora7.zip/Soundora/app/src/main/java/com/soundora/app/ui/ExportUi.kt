package com.soundora.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Exporter
import com.soundora.app.audio.ProjectStore
import com.soundora.app.audio.Render
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun shareFile(ctx: Context, f: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Müziği paylaş / kaydet"))
}

private fun saveToMusic(ctx: Context, f: File, mime: String): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    val v = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/Soundora")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val r = ctx.contentResolver
    val uri = r.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return false
    val out = r.openOutputStream(uri) ?: return false
    out.use { o -> f.inputStream().use { it.copyTo(o) } }
    v.clear()
    v.put(MediaStore.MediaColumns.IS_PENDING, 0)
    r.update(uri, v, null, null)
    return true
}

@Composable
fun ExportCard() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(ProjectStore.currentName) }
    var fmt by remember { mutableIntStateOf(0) }
    var rate by remember { mutableIntStateOf(sp.getInt("export_rate", 44100)) }
    var kbps by remember { mutableIntStateOf(192) }
    var norm by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf("") }

    val exts = listOf("wav", "wav", "m4a", "mid")
    val mimes = listOf("audio/wav", "audio/wav", "audio/mp4", "audio/midi")

    fun run(save: Boolean) {
        if (busy) return
        busy = true; progress = 0f; msg = "Hazırlanıyor…"
        val clean = name.trim().replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").ifEmpty { "Soundora" }
        val f = fmt
        val sr = rate
        val kb = kbps
        val nm = norm
        scope.launch {
            val out = File(ctx.cacheDir, "$clean.${exts[f]}")
            val ok = withContext(Dispatchers.IO) {
                try {
                    if (f == 3) {
                        Exporter.midi(out)
                        true
                    } else {
                        var pcm = AudioEngine.renderSong { p -> progress = p * 0.8f }
                        if (pcm == null) {
                            false
                        } else {
                            if (nm) pcm = Exporter.normalize(pcm)
                            pcm = Exporter.resample(pcm, 44100, sr)
                            progress = 0.9f
                            if (f == 2) {
                                Exporter.m4a(pcm, sr, kb, out)
                            } else {
                                Render.writeWav(out, pcm, sr, if (f == 1) 8 else 16)
                                true
                            }
                        }
                    }
                } catch (ex: Throwable) {
                    false
                }
            }
            busy = false
            if (!ok) {
                msg = "Dışa aktarma başarısız (proje çok uzun veya boş olabilir)."
            } else {
                progress = 1f
                if (save) {
                    val saved = try { saveToMusic(ctx, out, mimes[f]) } catch (ex: Throwable) { false }
                    msg = if (saved) "Kaydedildi: Müzik/Soundora/${out.name}"
                    else "Bu telefonda doğrudan kayıt desteklenmiyor; Paylaş menüsünden 'Dosyalara kaydet'i seç."
                    if (!saved) shareFile(ctx, out, mimes[f])
                } else {
                    msg = "Hazır: ${out.name}"
                    shareFile(ctx, out, mimes[f])
                }
            }
        }
    }

    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text("Dışa aktar", fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Dosya adı") }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("WAV 16-bit", "WAV 8-bit", "M4A (AAC)", "MIDI").forEachIndexed { i, n ->
                FilterChip(selected = fmt == i, onClick = { fmt = i }, label = { Text(n) })
            }
        }
        if (fmt != 3) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(22050, 44100, 48000).forEach { r -> FilterChip(selected = rate == r, onClick = { rate = r }, label = { Text("$r Hz") }) }
            }
            if (fmt == 2) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(96, 128, 192, 256).forEach { k -> FilterChip(selected = kbps == k, onClick = { kbps = k }, label = { Text("$k kbps") }) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ses seviyesini normalize et", fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = norm, onCheckedChange = { norm = it })
            }
        }
        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { run(false) }) { Text("Paylaş") }
            OutlinedButton(enabled = !busy, onClick = { run(true) }) { Text("Telefona kaydet") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Purple)
        Text(
            "Tüm kanallar (efektler dahil) tek dosyada birleşir. MP3 kodlayıcısı Android'de olmadığı için M4A (AAC) sunulur. MIDI: davul + melodi notaları.",
            fontSize = 11.sp, color = Color(0xFF9CA3AF)
        )
    }
}
