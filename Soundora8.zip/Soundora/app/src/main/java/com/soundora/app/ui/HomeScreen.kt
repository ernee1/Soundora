package com.soundora.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.ProjectStore

private class HCard(val route: String, val icon: String, val title: String, val desc: String, val color: Color)

@Composable
private fun HomeRowView(c: HCard, num: Int?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp)).background(Panel)
            .border(1.5.dp, c.color.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
            .clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (num != null) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(c.color), contentAlignment = Alignment.Center) {
                Text("$num", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
            }
            Spacer(Modifier.width(10.dp))
        }
        Box(Modifier.size(52.dp).clip(CircleShape).background(c.color.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Text(c.icon, fontSize = 26.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(c.desc, fontSize = 12.sp, color = Color(0xFF9CA3AF))
        }
        Text("›", fontSize = 26.sp, color = c.color)
    }
}

@Composable
fun HomeScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var showGlossary by remember { mutableStateOf(false) }
    val main = listOf(
        HCard("record", "🎤", "Ses Kaydet", "Mikrofonunla sesini kaydet.", Color(0xFFEF4444)),
        HCard("tuner", "🎯", "Akort Cihazı", "Enstrümanını kolayca akort et.", Color(0xFF22C55E)),
        HCard("projects", "📁", "Projelerim", "Müziklerini aç, sakla ve paylaş.", Color(0xFFF59E0B)),
        HCard("learn", "🎓", "Öğren", "Müzik yapmayı adım adım öğren.", Color(0xFF22D3EE))
    )
    val others = buildList {
        add(HCard("make", "🎵", "Müzik Yap", "Kendi ritmini ve melodini oluştur.", Color(0xFF8B5CF6)))
        add(HCard("instr", "🎹", "Enstrümanlar", "Piyano, gitar ve davul çal.", Color(0xFF3B82F6)))
        if (AppPrefs.advanced) {
            add(HCard("studio", "🎚", "Stüdyo", "Melodi çizici, mikser, otomasyon ve efektler.", Color(0xFFEC4899)))
            add(HCard("library", "🔊", "Ses Kütüphanesi", "Hazır sesleri dinle ve projene ekle.", Color(0xFF10B981)))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Soundora", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Purple)
                Text("Merhaba! Bugün ne yapmak istersin?", fontSize = 14.sp, color = Color(0xFF9CA3AF))
            }
            TextButton(onClick = { go("settings") }) { Text("⚙ Ayarlar") }
        }
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Devam et", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                Text(ProjectStore.currentName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Button(onClick = { go("make") }) { Text("▶ Aç") }
        }
        Spacer(Modifier.height(12.dp))

        main.forEachIndexed { i, c -> HomeRowView(c, i + 1) { go(c.route) } }
        Spacer(Modifier.height(4.dp))
        Text("Diğer", fontSize = 13.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(bottom = 6.dp))
        others.forEach { c -> HomeRowView(c, null) { go(c.route) } }
        Spacer(Modifier.height(4.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp)) {
            Text("Kullanım modu", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !AppPrefs.advanced, onClick = { AppPrefs.setAdvanced(ctx, false) }, label = { Text("Kolay mod") })
                FilterChip(selected = AppPrefs.advanced, onClick = { AppPrefs.setAdvanced(ctx, true) }, label = { Text("Gelişmiş mod") })
            }
            Text(
                if (AppPrefs.advanced) "Gelişmiş mod açık: Stüdyo (melodi çizici, mikser, otomasyon, efektler, ölçüm) ve Ses Kütüphanesi görünür."
                else "Kolay mod açık: sadece temel araçlar görünür. Profesyonel özellikler için Gelişmiş moda geç.",
                fontSize = 12.sp, color = Color(0xFF9CA3AF)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { AppPrefs.resetGuide(ctx) }) { Text("Rehberi tekrar göster") }
                TextButton(onClick = { showGlossary = true }) { Text("Müzik sözlüğü") }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    if (showGlossary) GlossaryDialog { showGlossary = false }
}
