package com.soundora.app.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** 2048 noktalık FFT (Hann pencereli). Çıkış: 1024 genlik değeri; tam ölçekli sinüs ≈ N/4. */
object Fft {
    const val N = 2048
    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }
    private val cosT = FloatArray(N / 2) { cos(2 * PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { (-sin(2 * PI * it / N)).toFloat() }
    private val rev = IntArray(N) { i ->
        var x = i
        var r = 0
        for (b in 0 until 11) { r = (r shl 1) or (x and 1); x = x shr 1 }
        r
    }
    private val re = FloatArray(N)
    private val im = FloatArray(N)

    @Synchronized
    fun magnitudes(input: FloatArray, out: FloatArray) {
        for (i in 0 until N) { re[rev[i]] = input[i] * win[i]; im[rev[i]] = 0f }
        var len = 2
        while (len <= N) {
            val half = len / 2
            val step = N / len
            var i = 0
            while (i < N) {
                for (j in 0 until half) {
                    val wr = cosT[j * step]
                    val wi = sinT[j * step]
                    val a = i + j
                    val b = a + half
                    val tr = re[b] * wr - im[b] * wi
                    val ti = re[b] * wi + im[b] * wr
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += len
            }
            len *= 2
        }
        for (i in 0 until N / 2) out[i] = sqrt(re[i] * re[i] + im[i] * im[i])
    }
}
