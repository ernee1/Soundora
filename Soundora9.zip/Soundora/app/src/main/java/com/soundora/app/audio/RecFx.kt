package com.soundora.app.audio

import kotlin.math.abs

/** Kayıt düzenleyicide ses verisine gerçekten uygulanan efektler. */
object RecFx {
    val profileNames = listOf("Temiz Vokal", "Stüdyo Vokali", "Yankılı Vokal", "Doğal Ses", "Telefon Sesi")

    fun profile(i: Int): FxChain {
        val c = FxChain()
        fun on(k: Int, vararg v: Float) {
            c.on[k] = true
            for (j in v.indices) c.p[k][j] = v[j]
        }
        when (i) {
            0 -> { on(5, 100f, 0.7f, 1f); on(0, 0f, 0f, 2f); on(3, -20f, 2.5f, 2f) }
            1 -> { on(5, 90f, 0.7f, 1f); on(0, 1f, 0f, 3f); on(3, -22f, 4f, 4f); on(1, 0.35f, 0.18f) }
            2 -> { on(1, 0.8f, 0.45f); on(2, 280f, 0.35f, 0.22f); on(3, -20f, 3f, 2f) }
            3 -> { }
            else -> { on(5, 400f, 1f, 1f); on(0, -12f, 4f, -12f); on(4, 3f, 0.3f) }
        }
        c.refresh()
        return c
    }

    /** Zinciri tüm örneklere uygular (yankı/gecikme varsa sona kuyruk ekler). */
    fun apply(data: ShortArray, c: FxChain, tailSec: Float): ShortArray {
        c.refresh()
        val tail = if (c.on[1] || c.on[2]) (tailSec * AudioEngine.SR).toInt() else 0
        val out = ShortArray(data.size + tail)
        for (i in out.indices) {
            val x = if (i < data.size) data[i] / 32768f else 0f
            val y = c.process(x).coerceIn(-1f, 1f)
            out[i] = (y * 32767f).toInt().toShort()
        }
        return out
    }

    /** Basit gürültü azaltma: kayıttaki en sessiz bölümlerden gürültü seviyesini kestirir, altını kısar. */
    fun noiseGate(data: ShortArray, strength: Float): ShortArray {
        val blk = 441
        val nb = data.size / blk
        if (nb < 4) return data
        val lv = FloatArray(nb) { b ->
            var m = 0f
            for (i in b * blk until (b + 1) * blk) m += abs(data[i].toInt())
            m / blk / 32768f
        }
        val noise = lv.sorted()[(nb * 0.1f).toInt()]
        val thr = noise * (1.5f + 3f * strength) + 0.002f
        val floor = 0.15f * (1f - strength)
        val out = ShortArray(data.size)
        var g = 1f
        for (b in 0 until nb) {
            val target = if (lv[b] > thr) 1f else floor
            for (i in b * blk until (b + 1) * blk) {
                g += (target - g) * 0.01f
                out[i] = (data[i] * g).toInt().toShort()
            }
        }
        for (i in nb * blk until data.size) out[i] = (data[i] * g).toInt().toShort()
        return out
    }
}
