package com.soundora.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Meter
import com.soundora.app.audio.dbOf
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.log10

private val mxColors = listOf(Color(0xFFF59E0B), Purple, Color(0xFF22D3EE))
private val mxRoutes = listOf("Master", "Grup A", "Grup B", "Grup C", "Grup D")

@Composable
private fun MxBar(db: Float) {
    val frac = ((db + 60f) / 60f).coerceIn(0f, 1f)
    val col = if (db > -1f) Color(0xFFEF4444) else if (db > -9f) Color(0xFFF59E0B) else Color(0xFF22C55E)
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF232C52))) {
        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(col))
    }
}

@Composable
private fun MxLive(read: () -> Float) {
    var db by remember { mutableFloatStateOf(-100f) }
    LaunchedEffect(Unit) { while (true) { db = dbOf(read()); delay(50) } }
    MxBar(db)
}

@Composable
private fun MxClip() {
    var clip by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { clip = Meter.isClipping(); delay(100) } }
    if (clip) Text("⚠ KIRPILMA (clipping)! Ses seviyesini düşür.", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 12.sp)
}

private fun panText(p: Float): String =
    if (abs(p) < 0.02f) "C" else if (p < 0) "L${(-p * 100).toInt()}" else "R${(p * 100).toInt()}"

@Composable
fun MixerScreen() {
    val e = AudioEngine
    var ver by remember { mutableIntStateOf(0) }
    var fxOpen by remember { mutableIntStateOf(-1) }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Mikser (Mixer)", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Kanal sesi, stereo pan, solo/mute, efekt zinciri ve yönlendirme. Değişiklikler çalarken anında duyulur.",
            fontSize = 11.sp, color = Color(0xFF9CA3AF)
        )
        Spacer(Modifier.height(8.dp))

        // ---- Kanallar
        for (tr in e.tracks.toList()) {
            val col = mxColors[tr.type]
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr.name, color = col, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (tr.mute) Color(0xFFEF4444) else Color(0xFF232C52))
                            .clickable { tr.mute = !tr.mute; e.refreshSolo(); ver++ },
                        contentAlignment = Alignment.Center
                    ) { Text("M", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    Box(
                        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (tr.solo) Color(0xFFF59E0B) else Color(0xFF232C52))
                            .clickable { tr.solo = !tr.solo; e.refreshSolo(); ver++ },
                        contentAlignment = Alignment.Center
                    ) { Text("S", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    Box(
                        Modifier.height(30.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (fxOpen == tr.id) Purple else Color(0xFF232C52))
                            .clickable { fxOpen = if (fxOpen == tr.id) -1 else tr.id }
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("FX", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                }
                MxLive { tr.level }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ses", fontSize = 12.sp, modifier = Modifier.width(44.dp))
                    Slider(value = tr.vol, onValueChange = { tr.vol = it; ver++ }, modifier = Modifier.weight(1f))
                    Text(String.format("%.0f dB", 20 * log10(tr.vol.coerceAtLeast(0.001f))), fontSize = 11.sp, modifier = Modifier.width(52.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pan", fontSize = 12.sp, modifier = Modifier.width(44.dp))
                    Slider(value = tr.pan, valueRange = -1f..1f, onValueChange = { tr.pan = it; ver++ }, modifier = Modifier.weight(1f))
                    Text(panText(tr.pan), fontSize = 11.sp, modifier = Modifier.width(52.dp))
                }
                Text("Çıkış (yönlendirme)", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    mxRoutes.forEachIndexed { i, n ->
                        FilterChip(selected = tr.route == i, onClick = { tr.route = i; ver++ }, label = { Text(n) })
                    }
                }
                if (fxOpen == tr.id) FxPanel(tr) { ver++ }
            }
        }

        // ---- Gruplar
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
            Text("Kanal grupları", fontWeight = FontWeight.Bold)
            Text("Bir kanalın çıkışını Grup A-D'ye yönlendir; grubun sesi ve mute'u hepsini birden yönetir.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            for (g in 0 until 4) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Grup ${"ABCD"[g]}", fontSize = 12.sp, modifier = Modifier.width(56.dp))
                    Slider(value = e.grpVol[g], onValueChange = { e.grpVol[g] = it; ver++ }, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (e.grpMute[g]) Color(0xFFEF4444) else Color(0xFF232C52))
                            .clickable { e.grpMute[g] = !e.grpMute[g]; ver++ },
                        contentAlignment = Alignment.Center
                    ) { Text("M", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                }
            }
        }

        // ---- Master
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
            Text("Master", fontWeight = FontWeight.Bold, color = Purple)
            Text("L", fontSize = 10.sp)
            MxLive { Meter.peakL }
            Text("R", fontSize = 10.sp)
            MxLive { Meter.peakR }
            MxClip()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ses", fontSize = 12.sp, modifier = Modifier.width(44.dp))
                Slider(value = e.masterVol, onValueChange = { e.masterVol = it; ver++ }, modifier = Modifier.weight(1f))
                Text(String.format("%.0f dB", 20 * log10(e.masterVol.coerceAtLeast(0.001f))), fontSize = 11.sp, modifier = Modifier.width(52.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto Mastering (EQ + kompresör + limiter)", fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = e.autoMaster, onCheckedChange = { e.autoMaster = it; ver++ })
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
