package com.soundora.app.audio

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max

/** Master çıkış ölçümü: Peak, RMS, LUFS (K-ağırlıklı, yaklaşık BS.1770) ve spektrum için halka tampon. */
object Meter {
    @Volatile var peakL = 0f
    @Volatile var peakR = 0f
    @Volatile var rmsDb = -90f
    @Volatile var momentary = -70.0
    @Volatile var shortTerm = -70.0
    @Volatile var clipUntil = 0L
    @Volatile var maxPeak = 0f

    val ring = FloatArray(4096)
    @Volatile var ringW = 0

    private val k1L = Biquad()
    private val k2L = Biquad()
    private val k1R = Biquad()
    private val k2R = Biquad()
    private var blockSum = 0.0
    private var rmsSum = 0.0
    private var blockN = 0
    private val blockPow = DoubleArray(30)
    private var blockIdx = 0
    private var filled = 0
    private val windows = ArrayList<Double>()
    private val lock = Any()

    init {
        for (b in arrayOf(k1L, k1R)) b.set(4, 1681.97, 0.7072, 4.0)
        for (b in arrayOf(k2L, k2R)) b.set(1, 38.135, 0.5003, 0.0)
    }

    fun reset() {
        synchronized(lock) { windows.clear() }
        blockSum = 0.0; rmsSum = 0.0; blockN = 0; blockIdx = 0; filled = 0
        momentary = -70.0; shortTerm = -70.0; maxPeak = 0f
    }

    private fun lufs(p: Double): Double = if (p <= 1e-10) -70.0 else -0.691 + 10.0 * log10(p)

    /** Ses iş parçacığından her örnekte çağrılır. l/r: ana çıkış (kırpma öncesi). */
    fun feed(l: Float, r: Float) {
        val al = abs(l)
        val ar = abs(r)
        peakL = max(al, peakL * 0.99996f)
        peakR = max(ar, peakR * 0.99996f)
        if (al > maxPeak) maxPeak = al
        if (ar > maxPeak) maxPeak = ar
        if (al >= 1f || ar >= 1f) clipUntil = System.currentTimeMillis() + 2000
        val kl = k2L.proc(k1L.proc(l.toDouble()))
        val kr = k2R.proc(k1R.proc(r.toDouble()))
        blockSum += kl * kl + kr * kr
        rmsSum += (l * l + r * r) * 0.5
        ring[ringW and 4095] = (l + r) * 0.5f
        ringW++
        blockN++
        if (blockN >= 4410) endBlock()
    }

    private fun mean(n: Int): Double {
        val c = if (filled < n) filled else n
        if (c <= 0) return 0.0
        var s = 0.0
        for (i in 0 until c) s += blockPow[((blockIdx - 1 - i) % 30 + 30) % 30]
        return s / c
    }

    private fun endBlock() {
        val pow = blockSum / blockN
        rmsDb = if (rmsSum <= 1e-12) -90f else (10.0 * log10(rmsSum / blockN)).toFloat()
        blockPow[blockIdx % 30] = pow
        blockIdx++
        if (filled < 30) filled++
        val m = mean(4)
        momentary = lufs(m)
        shortTerm = lufs(mean(30))
        if (filled >= 4 && m > 1e-9) synchronized(lock) {
            if (windows.size < 36000) windows.add(m)
        }
        blockSum = 0.0; rmsSum = 0.0; blockN = 0
    }

    /** Bütünleşik (gated) LUFS; ölçüm yoksa -70. */
    fun integrated(): Double {
        val w: List<Double> = synchronized(lock) { ArrayList(windows) }
        val abs1 = w.filter { lufs(it) > -70.0 }
        if (abs1.isEmpty()) return -70.0
        val rel = lufs(abs1.average()) - 10.0
        val g = abs1.filter { lufs(it) > rel }
        return if (g.isEmpty()) -70.0 else lufs(g.average())
    }

    fun isClipping(): Boolean = System.currentTimeMillis() < clipUntil

    fun copyRing(dst: FloatArray) {
        val w = ringW
        for (i in dst.indices) dst[i] = ring[(w - dst.size + i) and 4095]
    }
}

fun dbOf(x: Float): Float = if (x <= 1e-5f) -100f else 20f * log10(x)
