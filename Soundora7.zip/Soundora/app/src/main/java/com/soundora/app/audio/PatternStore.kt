package com.soundora.app.audio

/** Ritim + melodi kalıbını metne çevirir / metinden yükler. */
object PatternStore {
    fun encode(): String {
        val e = AudioEngine
        val rows = (0 until AudioEngine.ROWS).joinToString("|") { r ->
            (0 until AudioEngine.MAX_STEPS).joinToString("") { s -> if (e.pattern[r][s]) "x" else "." }
        }
        val notes = e.melody.joinToString(";") { "${it.start},${it.len},${it.pitch}" }
        return "${e.bpm}#${e.steps}#${e.swing}#${e.kit}#$rows#$notes"
    }

    fun decode(raw: String): Boolean = try {
        val p = raw.split("#")
        val e = AudioEngine
        e.bpm = p[0].toInt()
        e.steps = p[1].toInt()
        e.swing = p[2].toFloat()
        e.kit = p[3].toInt()
        val rows = p[4].split("|")
        for (r in 0 until AudioEngine.ROWS) for (s in 0 until AudioEngine.MAX_STEPS) {
            e.pattern[r][s] = s < rows[r].length && rows[r][s] == 'x'
        }
        e.melody.clear()
        if (p.size > 5 && p[5].isNotEmpty()) {
            p[5].split(";").forEach { q ->
                val v = q.split(",")
                e.melody.add(Note(v[0].toInt(), v[1].toInt(), v[2].toInt()))
            }
        }
        true
    } catch (ex: Exception) {
        false
    }
}
