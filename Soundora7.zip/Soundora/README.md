# Soundora 0.5
Studio (Beat, Roll, Timeline, Kayıt, Araçlar) • Enstrüman • Kütüphane • Öğren • Projeler (+ Dışa aktar) • Ayarlar
- Kanal başına efektler: EQ, Reverb, Delay, Compressor, Distortion, Filter, Chorus, Flanger, Pitch Shifter
- Dışa aktarma: WAV 16/8-bit, M4A (AAC), MIDI; paylaş veya Müzik/Soundora'ya kaydet
- Akıllı araçlar (kural tabanlı): Random Beat, Beat Generator, Chord/Scale Assistant, Auto Mastering, Visualizer
- Ses kütüphanesi (sentezlenmiş sesler + kendi dosyaların), favori/arama, projeye ekleme
- MP3/M4A/WAV içe aktarma
