package com.soundora.app.ui

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Kolay/Gelişmiş mod ve rehber (ilk açılış, ilk kullanım ipuçları) durumu. */
object AppPrefs {
    var advanced by mutableStateOf(false)
    var introDone by mutableStateOf(true)
    private var seen by mutableStateOf(setOf<String>())

    private fun sp(ctx: Context) = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val s = sp(ctx)
        advanced = s.getBoolean("advanced", false)
        introDone = s.getBoolean("intro_done", false)
        seen = s.getStringSet("tips_seen", emptySet())?.toSet() ?: emptySet()
    }

    fun setAdvanced(ctx: Context, v: Boolean) {
        advanced = v
        sp(ctx).edit().putBoolean("advanced", v).apply()
    }

    fun finishIntro(ctx: Context) {
        introDone = true
        sp(ctx).edit().putBoolean("intro_done", true).apply()
    }

    fun tipSeen(k: String): Boolean = seen.contains(k)

    fun markTip(ctx: Context, k: String) {
        seen = seen + k
        sp(ctx).edit().putStringSet("tips_seen", seen).apply()
    }

    fun resetGuide(ctx: Context) {
        seen = emptySet()
        introDone = false
        sp(ctx).edit().remove("tips_seen").putBoolean("intro_done", false).apply()
    }
}

@Composable
fun IntroDialog() {
    val ctx = LocalContext.current
    var page by remember { mutableIntStateOf(0) }
    val pages = listOf(
        Triple("🎵", "Soundora'ya hoş geldin!", "Burada telefonunla kolayca müzik yapabilirsin. Müzik bilmen gerekmez, adım adım yardım edeceğiz."),
        Triple("▶", "Müzik Yap", "Bir hazır şablon seç ve ▶ düğmesine bas. Sonra ritmi, melodiyi ve sesi istediğin gibi değiştir."),
        Triple("🎯", "Akort Cihazı", "Gitarını, bas gitarını, ukuleleni veya kemanını telefonun mikrofonuyla akort et."),
        Triple("💾", "Kaydet ve paylaş", "Müziğini tek dokunuşla kaydet. İstediğin zaman telefonuna ses dosyası (WAV) olarak aktar veya paylaş.")
    )
    AlertDialog(
        onDismissRequest = {},
        title = { Text(pages[page].first + " " + pages[page].second) },
        text = { Text(pages[page].third + "\n\n" + (page + 1) + " / " + pages.size) },
        confirmButton = {
            TextButton(onClick = { if (page < pages.size - 1) page++ else AppPrefs.finishIntro(ctx) }) {
                Text(if (page < pages.size - 1) "İleri" else "Başla")
            }
        },
        dismissButton = { TextButton(onClick = { AppPrefs.finishIntro(ctx) }) { Text("Atla") } }
    )
}

private fun tipText(page: String): Pair<String, String>? = when (page) {
    "make" -> "Müzik Yap" to "1) Bir şablon seç. 2) ▶ düğmesine bas. 3) İstersen ritmi, melodiyi ve sesi değiştir.\n\nBPM müziğin hızıdır: büyük sayı = hızlı müzik."
    "tuner" -> "Akort Cihazı" to "Enstrümanını seç, mikrofon iznini ver ve bir tel çal. Ekran sana teli sıkman mı yoksa gevşetmen mi gerektiğini söyler. Yeşil renk: akort doğru."
    "instr" -> "Enstrümanlar" to "Ekrandaki piyano, gitar veya davula dokunarak çal. Piyanoda tuşa basılı tutarsan ses devam eder."
    "record" -> "Ses Kaydet" to "Kırmızı düğmeye basıp konuş veya şarkı söyle. Kaydı durdurunca listede görürsün; dinleyebilir, adını değiştirebilir veya müziğine ekleyebilirsin."
    "projects" -> "Projelerim" to "Yaptığın bütün müzikler burada saklanır. Uygulama kapansa bile kaybolmaz. Yeni proje başlatabilir, kopyalayabilir ve paylaşabilirsin."
    "learn" -> "Öğren" to "Müziğin temel kavramlarını (BPM, nota, akor) kısa açıklamalarla ve dinleyerek öğren."
    "studio" -> "Stüdyo (Gelişmiş mod)" to "Burada melodi çizici, mikser, otomasyon, efektler ve ölçüm araçları var. Sadece başlamak istiyorsan 'Müzik Yap' sayfası yeterli."
    "library" -> "Ses Kütüphanesi" to "Hazır sesleri dinle, beğendiklerini favorilere ekle ve müziğine ekle."
    "settings" -> "Ayarlar" to "Tema, varsayılan hız, ses gecikmesi ve depolama ayarları burada. Çoğu zaman değiştirmen gerekmez."
    else -> null
}

/** Bir sayfa ilk kez açıldığında kısa açıklama gösterir. */
@Composable
fun FirstTip(page: String) {
    val ctx = LocalContext.current
    val t = tipText(page) ?: return
    if (AppPrefs.introDone && !AppPrefs.tipSeen(page)) {
        AlertDialog(
            onDismissRequest = { AppPrefs.markTip(ctx, page) },
            title = { Text(t.first) },
            text = { Text(t.second) },
            confirmButton = { TextButton(onClick = { AppPrefs.markTip(ctx, page) }) { Text("Anladım") } }
        )
    }
}

private val glossary = listOf(
    "BPM" to "Müziğin hızı. Bir dakikada kaç vuruş olduğunu gösterir. Büyük sayı = hızlı müzik.",
    "Ritim" to "Müziğin vuruş düzeni; davulun çaldığı tempo kalıbı.",
    "Melodi" to "Şarkıda mırıldanabildiğin, notalardan oluşan ana ezgi.",
    "Nota" to "Bir sesin adı (Do, Re, Mi, Fa, Sol, La, Si). Piyanoda her tuş bir notadır.",
    "Akor" to "Aynı anda çalınan birkaç nota. Şarkıya fon oluşturur.",
    "Oktav" to "Aynı notanın daha ince veya daha kalın hali. Piyanoda 8 beyaz tuş ileri gitmek.",
    "Cent" to "Akortta yarım sesin yüzde biri. 0'a yakınsa akort doğrudur.",
    "WAV" to "Kayıpsız, yüksek kaliteli ses dosyası.",
    "MIDI" to "Notaları ses yerine bilgi olarak saklayan dosya. Başka müzik programlarında açılır.",
    "LUFS" to "Müziğin ortalama ne kadar yüksek duyulduğunu gösteren ölçü.",
    "Mikser" to "Her sesin (davul, melodi, kayıt) seviyesini ayrı ayarladığın panel.",
    "Efekt" to "Sesin rengini değiştiren işlemler (yankı, bozulma gibi)."
)

@Composable
fun GlossaryDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Müzik Sözlüğü") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                glossary.forEach { (k, v) ->
                    Text(k, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(v, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Kapat") } }
    )
}
