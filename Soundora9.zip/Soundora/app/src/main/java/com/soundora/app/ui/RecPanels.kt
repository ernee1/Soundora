package com.soundora.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Arranger
import com.soundora.app.audio.Clip
import com.soundora.app.audio.Exporter
import com.soundora.app.audio.Headphones
import com.soundora.app.audio.History
import com.soundora.app.audio.RecConfig
import com.soundora.app.audio.RecFiles
import com.soundora.app.audio.RecFx
import com.soundora.app.audio.Recorder
import com.soundora.app.audio.Render
import com.soundora.app.audio.SampleStore
import com.soundora.app.audio.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val LOCK_MSG = "Yeni kayıt alırken diğer kanalları dinlemek için kulaklık bağlamalısın."

private fun recPrefs(ctx: Context) = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)
private fun recName(ctx: Context, f: File): String = recPrefs(ctx).getString("recname_" + f.name, null) ?: f.nameWithoutExtension
private fun recFavs(ctx: Context): Set<String> = recPrefs(ctx).getStringSet("rec_fav", emptySet())?.toSet() ?: emptySet()

private fun peaksOf(d: ShortArray, n: Int): FloatArray {
    if (d.isEmpty()) return FloatArray(n)
    val blk = max(1, d.size / n)
    return FloatArray(n) { i ->
        var m = 0
        val a = i * blk
        val b = min(d.size, a + blk)
        for (k in a until b) m = max(m, abs(d[k].toInt()))
        m / 32768f
    }
}

private fun shareFiles(ctx: Context, files: List<File>) {
    val uris = ArrayList<android.net.Uri>()
    for (f in files) uris.add(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f))
    val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
    else Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
    i.type = "audio/wav"
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Dışa aktar / paylaş"))
}

@Composable
private fun RdBar(level: Float) {
    val db = if (level <= 0.0005f) -60f else 20f * kotlin.math.log10(level)
    val frac = ((db + 60f) / 60f).coerceIn(0f, 1f)
    val col = if (db > -3f) Color(0xFFEF4444) else if (db > -12f) Color(0xFFF59E0B) else Color(0xFF22C55E)
    Box(Modifier.fillMaxWidth().height(10.dp).background(Color(0xFF232C52), RoundedCornerShape(5.dp))) {
        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(col, RoundedCornerShape(5.dp)))
    }
}

// =====================================================================
// KAYITLARIM
// =====================================================================
@Composable
fun MyRecordingsPanel(onEdit: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var onlyFav by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var renameF by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }
    var delF by remember { mutableStateOf<File?>(null) }
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")) }
    DisposableEffect(Unit) { onDispose { AudioEngine.stopPreviewPcm() } }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver

    val favs = recFavs(ctx)
    var list = Recorder.list(ctx)
    if (query.isNotBlank()) list = list.filter { recName(ctx, it).contains(query.trim(), ignoreCase = true) }
    if (onlyFav) list = list.filter { favs.contains(it.name) }
    list = if (sort == 1) list.sortedBy { recName(ctx, it).lowercase() } else list.sortedByDescending { it.lastModified() }

    fun play(f: File) {
        scope.launch {
            val pcm = withContext(Dispatchers.IO) { RecFiles.readMono(f) }
            if (pcm != null) AudioEngine.previewPcmData(pcm, AudioEngine.SR) else msg = "Kayıt okunamadı."
        }
    }
    fun addToProject(f: File) {
        val adv = AppPrefs.advanced
        scope.launch {
            val id = withContext(Dispatchers.IO) {
                Arranger.addRecording("recordings/${f.name}", recName(ctx, f), adv, if (adv) (AudioEngine.songStep / 4) * 4 else 0)
            }
            msg = if (id >= 0) "Projeye eklendi ✓" else "Projeye eklenemedi."
        }
    }
    fun copy(f: File) {
        try {
            var n = 2
            var t = File(f.parentFile, f.nameWithoutExtension + "_kopya.wav")
            while (t.exists()) { t = File(f.parentFile, f.nameWithoutExtension + "_kopya" + n + ".wav"); n++ }
            f.copyTo(t)
            recPrefs(ctx).edit().putString("recname_" + t.name, recName(ctx, f) + " kopya").apply()
            msg = "Kopyalandı ✓"
            ver++
        } catch (ex: Exception) { msg = "Kopyalanamadı." }
    }
    fun toggleFav(f: File) {
        val s = recFavs(ctx)
        recPrefs(ctx).edit().putStringSet("rec_fav", if (s.contains(f.name)) s - f.name else s + f.name).apply()
        ver++
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Kayıtlarım", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Kayıtlarda ara") }, modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sort == 0, onClick = { sort = 0 }, label = { Text("Yeniden eskiye") })
            FilterChip(selected = sort == 1, onClick = { sort = 1 }, label = { Text("Ada göre") })
            FilterChip(selected = onlyFav, onClick = { onlyFav = !onlyFav }, label = { Text("★ Favoriler") })
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Color(0xFF22C55E))
        if (list.isEmpty()) Text("Kayıt bulunamadı. 'Kaydet' sekmesinden ilk kaydını al.", color = Color(0xFF9CA3AF), modifier = Modifier.padding(8.dp))

        list.forEach { f ->
            val meta = RecFiles.meta(f)
            val isFav = favs.contains(f.name)
            RecCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(recName(ctx, f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                    TextButton(onClick = { toggleFav(f) }) { Text(if (isFav) "★" else "☆", fontSize = 20.sp) }
                }
                if (meta != null) {
                    Text(
                        fmt.format(Date(f.lastModified())) + " • " + RecFiles.fmt((meta.durSec * 1000).toLong()) +
                            " • WAV " + (meta.sr / 1000.0) + " kHz " + (if (meta.ch == 2) "stereo" else "mono"),
                        fontSize = 11.sp, color = Color(0xFF9CA3AF)
                    )
                    PeaksView(meta.peaks, Modifier.fillMaxWidth().height(46.dp))
                } else Text("(dosya okunamadı)", fontSize = 11.sp, color = Color(0xFFEF4444))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { play(f) }) { Text("▶ Çal") }
                    TextButton(onClick = { AudioEngine.stopPreviewPcm() }) { Text("■") }
                    TextButton(onClick = { onEdit(f) }) { Text("✂ Düzenle") }
                    TextButton(onClick = { addToProject(f) }) { Text("➕ Projeye ekle") }
                    TextButton(onClick = { renameF = f; renameText = recName(ctx, f) }) { Text("Ad") }
                    TextButton(onClick = { copy(f) }) { Text("Kopya") }
                    TextButton(onClick = { try { RecFiles.share(ctx, f, "audio/wav") } catch (ex: Exception) { msg = "Paylaşılamadı." } }) { Text("Paylaş") }
                    TextButton(onClick = { delF = f }) { Text("Sil") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    renameF?.let { f ->
        AlertDialog(
            onDismissRequest = { renameF = null },
            title = { Text("Kaydın adı") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    recPrefs(ctx).edit().putString("recname_" + f.name, renameText.trim().ifEmpty { f.nameWithoutExtension }).apply()
                    renameF = null; ver++
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { renameF = null }) { Text("İptal") } }
        )
    }
    delF?.let { f ->
        val rel = "recordings/${f.name}"
        val used = AudioEngine.clips.any { it.file == rel }
        AlertDialog(
            onDismissRequest = { delF = null },
            title = { Text("Kayıt silinsin mi?") },
            text = { Text(if (used) "Bu kayıt şu an projede kullanılıyor. Silersen projeden de çıkar. Bu işlem geri alınamaz." else "Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(onClick = {
                    if (used) { History.push(); AudioEngine.clips.removeIf { it.file == rel } }
                    f.delete()
                    SampleStore.forget(rel)
                    delF = null; ver++
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { delF = null }) { Text("İptal") } }
        )
    }
}

// =====================================================================
// KAYIT DÜZENLEYİCİ (orijinal korunur; her işlem geri alınabilir)
// =====================================================================
@Composable
fun RecEditorPanel(f: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val adv = AppPrefs.advanced
    val sr = AudioEngine.SR
    var cur by remember { mutableStateOf<ShortArray?>(null) }
    var loadFail by remember { mutableStateOf(false) }
    val undo = remember { ArrayList<ShortArray>() }
    val redo = remember { ArrayList<ShortArray>() }
    var ver by remember { mutableIntStateOf(0) }
    var s0 by remember { mutableFloatStateOf(0f) }
    var s1 by remember { mutableFloatStateOf(1f) }
    var vol by remember { mutableFloatStateOf(1f) }
    var fade by remember { mutableFloatStateOf(1f) }
    var strength by remember { mutableFloatStateOf(0.5f) }
    var busy by remember { mutableStateOf(false) }
    var before by remember { mutableStateOf<ShortArray?>(null) }
    var msg by remember { mutableStateOf("") }
    var savedFile by remember { mutableStateOf<File?>(null) }
    val fxTrack = remember { Track(-1, "Kayıt", 2) }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver

    LaunchedEffect(f) {
        val d = withContext(Dispatchers.IO) { RecFiles.readMono(f) }
        if (d == null) loadFail = true else cur = d
    }
    DisposableEffect(Unit) { onDispose { AudioEngine.stopPreviewPcm() } }

    val data = cur
    val peaks = remember(data) { if (data == null) FloatArray(0) else peaksOf(data, 200) }

    fun commit(nd: ShortArray) {
        val c = cur
        if (c != null) { undo.add(c); if (undo.size > 12) undo.removeAt(0); redo.clear() }
        cur = nd; s0 = 0f; s1 = 1f; savedFile = null; ver++
    }
    fun heavy(op: (ShortArray) -> ShortArray) {
        val c = cur ?: return
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.Default) { try { op(c) } catch (ex: Throwable) { null } }
            busy = false
            if (r != null) { before = c; commit(r); msg = "Uygulandı ✓ (geri alabilirsin)" } else msg = "İşlem başarısız."
        }
    }
    fun play(range: Boolean) {
        val c = cur ?: return
        val a = if (range) (s0 * c.size).toInt() else 0
        val b = if (range) (s1 * c.size).toInt() else c.size
        if (b - a > 100) AudioEngine.previewPcmData(c.copyOfRange(a, b), sr)
    }
    fun saveNew() {
        val c = cur ?: return
        val base = recName(ctx, f) + " (düzenlendi)"
        scope.launch {
            val file = withContext(Dispatchers.IO) { RecFiles.save(ctx, base, c) }
            recPrefs(ctx).edit().putString("recname_" + file.name, base).apply()
            savedFile = file
            msg = "Yeni kayıt olarak kaydedildi ✓ (orijinal korundu)"
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Kayıtlarım") }
            Spacer(Modifier.weight(1f))
            Text(recName(ctx, f), fontWeight = FontWeight.Bold, maxLines = 1)
        }
        if (loadFail) { Text("Dosya okunamadı.", color = Color(0xFFEF4444)); return@Column }
        if (data == null) { Text("Yükleniyor…", color = Color(0xFF9CA3AF)); return@Column }

        RecCard("Dalga biçimi", "Beyaz çizgiler arası: seçili bölüm. Kırpmak için başlangıç ve bitişi ayarla.") {
            PeaksView(peaks, Modifier.fillMaxWidth().height(110.dp), sel0 = s0, sel1 = s1)
            Text(
                String.format("Seçim: %.2f sn – %.2f sn  (toplam %.2f sn)", s0 * data.size / sr, s1 * data.size / sr, data.size.toFloat() / sr),
                fontSize = 11.sp, color = Color(0xFF9CA3AF)
            )
            Text("Başlangıç", fontSize = 11.sp)
            Slider(value = s0, onValueChange = { s0 = min(it, s1 - 0.01f).coerceAtLeast(0f) })
            Text("Bitiş", fontSize = 11.sp)
            Slider(value = s1, onValueChange = { s1 = max(it, s0 + 0.01f).coerceAtMost(1f) })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { play(true) }) { Text("▶ Seçimi dinle") }
                OutlinedButton(onClick = { play(false) }) { Text("▶ Hepsini dinle") }
                OutlinedButton(onClick = { AudioEngine.stopPreviewPcm() }) { Text("■") }
            }
        }
        RecCard("Kırp") {
            Button(onClick = {
                val a = (s0 * data.size).toInt()
                val b = (s1 * data.size).toInt()
                if (b - a < 1000) msg = "Seçim çok kısa." else { commit(data.copyOfRange(a, b)); msg = "Kırpıldı ✓" }
            }) { Text("✂ Seçili bölümü tut") }
        }
        RecCard("Ses seviyesi ve geçişler") {
            Text(String.format("Ses seviyesi: %.0f%%", vol * 100), fontSize = 12.sp)
            Slider(value = vol, valueRange = 0f..2f, onValueChange = { vol = it })
            Button(onClick = {
                commit(ShortArray(data.size) { (data[it] * vol).toInt().coerceIn(-32768, 32767).toShort() })
                vol = 1f
            }) { Text("Ses seviyesini uygula") }
            Text(String.format("Geçiş süresi: %.1f sn", fade), fontSize = 12.sp)
            Slider(value = fade, valueRange = 0.1f..3f, onValueChange = { fade = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val n = min(data.size, (fade * sr).toInt())
                    val o = data.copyOf()
                    for (i in 0 until n) o[i] = (o[i] * (i.toFloat() / n)).toInt().toShort()
                    commit(o)
                }) { Text("Fade In") }
                OutlinedButton(onClick = {
                    val n = min(data.size, (fade * sr).toInt())
                    val o = data.copyOf()
                    for (i in 0 until n) o[data.size - n + i] = (o[data.size - n + i] * (1f - i.toFloat() / n)).toInt().toShort()
                    commit(o)
                }) { Text("Fade Out") }
            }
        }
        RecCard("Hazır ses efektleri", "Dokun, uygulansın. Önce/Sonra düğmeleriyle karşılaştır.") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RecFx.profileNames.forEachIndexed { i, n ->
                    AssistChip(onClick = { if (!busy) heavy { RecFx.apply(it, RecFx.profile(i), 1.5f) } }, label = { Text(n) })
                }
            }
            val b = before
            if (b != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { AudioEngine.previewPcmData(b, sr) }) { Text("▶ Önce") }
                    OutlinedButton(onClick = { AudioEngine.previewPcmData(data, sr) }) { Text("▶ Sonra") }
                }
            }
            if (busy) Text("İşleniyor…", fontSize = 12.sp, color = Color(0xFFF59E0B))
        }
        RecCard("Geri al / yinele") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (undo.isNotEmpty()) { redo.add(data); cur = undo.removeAt(undo.size - 1); s0 = 0f; s1 = 1f; ver++ }
                }) { Text("↶ Geri al (${undo.size})") }
                OutlinedButton(onClick = {
                    if (redo.isNotEmpty()) { undo.add(data); cur = redo.removeAt(redo.size - 1); s0 = 0f; s1 = 1f; ver++ }
                }) { Text("↷ Yinele (${redo.size})") }
            }
        }

        if (adv) {
            RecCard("Gelişmiş düzenleme", "Sadece Gelişmiş modda görünür.") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { if (!busy) heavy { Exporter.normalize(it) } }, label = { Text("Normalize et") })
                    AssistChip(onClick = {
                        val cut = (s0 * data.size).toInt()
                        if (cut < 1000 || data.size - cut < 1000) msg = "Bölmek için başlangıç kaydırıcısını bir ortaya getir."
                        else {
                            val p1 = data.copyOfRange(0, cut)
                            val p2 = data.copyOfRange(cut, data.size)
                            val base = recName(ctx, f)
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    val a = RecFiles.save(ctx, "$base 1", p1)
                                    val b = RecFiles.save(ctx, "$base 2", p2)
                                    recPrefs(ctx).edit().putString("recname_" + a.name, "$base 1").putString("recname_" + b.name, "$base 2").apply()
                                }
                                msg = "Bölündü: iki yeni kayıt oluşturuldu ✓ (orijinal korundu)"
                            }
                        }
                    }, label = { Text("Başlangıç noktasından böl") })
                }
                Text("Birleştir (seçtiğin kaydı sona ekler):", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Recorder.list(ctx).filter { it.name != f.name }.forEach { o ->
                        AssistChip(onClick = {
                            scope.launch {
                                val od = withContext(Dispatchers.IO) { RecFiles.readMono(o) }
                                if (od == null) msg = "Kayıt okunamadı." else { commit(data + od); msg = "Birleştirildi ✓ (geri alabilirsin)" }
                            }
                        }, label = { Text(recName(ctx, o)) })
                    }
                }
                Text(String.format("Gürültü azaltma gücü: %.0f%%", strength * 100), fontSize = 12.sp)
                Slider(value = strength, onValueChange = { strength = it })
                OutlinedButton(onClick = { val st = strength; if (!busy) heavy { RecFx.noiseGate(it, st) } }) { Text("Gürültüyü azalt") }
                FxPanel(fxTrack) { }
                OutlinedButton(onClick = {
                    if (!busy) heavy {
                        RecFx.apply(ShortArray(sr * 3), fxTrack.fx, 0f)
                        RecFx.apply(it, fxTrack.fx, 2f)
                    }
                }) { Text("Seçili efektleri kayda uygula") }
            }
        }

        RecCard("Kaydet") {
            Button(onClick = { saveNew() }) { Text("💾 Yeni kayıt olarak kaydet") }
            Text("Orijinal kayıt her zaman korunur.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            val sf = savedFile
            if (sf != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            val id = withContext(Dispatchers.IO) {
                                Arranger.addRecording("recordings/${sf.name}", recName(ctx, sf), adv, 0)
                            }
                            msg = if (id >= 0) "Projeye eklendi ✓" else "Projeye eklenemedi."
                        }
                    }) { Text("➕ Projeye ekle") }
                    OutlinedButton(onClick = { try { RecFiles.share(ctx, sf, "audio/wav") } catch (ex: Exception) { msg = "Paylaşılamadı." } }) { Text("Paylaş") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Color(0xFF22C55E), modifier = Modifier.padding(4.dp))
        Spacer(Modifier.height(16.dp))
    }
}

// =====================================================================
// OVERDUB: seçili kayıtları dinlerken yeni kayıt (kulaklık zorunlu)
// =====================================================================
@Composable
fun OverdubPanel() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val e = AudioEngine
    var ver by remember { mutableIntStateOf(0) }
    val sel = remember { mutableStateListOf<String>() }
    var kind by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var hpLost by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0f) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var latAdj by remember { mutableFloatStateOf(-1f) }
    var msg by remember { mutableStateOf("") }
    var savedStep by remember { mutableIntStateOf(0) }
    val holder = remember { DoubleArray(1) }
    val recState = rememberUpdatedState(recording)
    val pausedState = rememberUpdatedState(paused)
    val latState = rememberUpdatedState(latAdj)
    @Suppress("UNUSED_VARIABLE") val subscribe = ver

    LaunchedEffect(Unit) { while (true) { Headphones.refresh(ctx); ver++; delay(700) } }
    LaunchedEffect(recording) { while (recording) { elapsed = Recorder.elapsedMs; delay(100) } }

    fun finishTake() {
        val f = Recorder.finish(ctx)
        e.playing = false
        e.overdubOnly = null
        recording = false; paused = false; hpLost = false; level = 0f
        if (f == null) { msg = "Kayıt alınamadı."; return }
        val lat = if (latState.value < 0f) (e.outputLatencyMs() + 25).toDouble() else latState.value.toDouble()
        val offSamples = ((holder[0] + lat) * AudioEngine.SR / 1000.0).toInt()
        val n = e.tracks.count { it.type == 2 } + 1
        Thread {
            val id = Arranger.addRecording("recordings/${f.name}", "Overdub $n", true, 0, offSamples)
            msg = if (id >= 0) "Yeni kayıt ayrı kanal olarak eklendi ✓ Önceki kayıtlara dokunulmadı." else "Kayıt dosyası saklandı ama projeye eklenemedi (çok kısa olabilir)."
        }.start()
    }

    DisposableEffect(Unit) {
        Headphones.onRemoved = {
            if (recState.value && !pausedState.value) {
                Recorder.pause()
                savedStep = e.songStep
                e.playing = false
                paused = true
                hpLost = true
                msg = "Kulaklık çıkarıldı. Kayıt duraklatıldı ve korundu. Kulaklığı tekrar bağlayınca devam edebilirsin."
            }
        }
        onDispose {
            Headphones.onRemoved = null
            if (recState.value) finishTake()
            e.overdubOnly = null
        }
    }

    fun startTake() {
        Headphones.refresh(ctx)
        if (!Headphones.usable) { msg = LOCK_MSG; return }
        if (sel.isEmpty()) { msg = "Dinlemek için en az bir kayıt seç."; return }
        scope.launch {
            val ids = withContext(Dispatchers.IO) {
                val out = HashSet<Int>()
                for (name in sel.toList()) {
                    val rel = "recordings/$name"
                    var cl = e.clips.filter { it.file == rel }
                    if (cl.isEmpty()) {
                        Arranger.addRecording(rel, recName(ctx, File(Recorder.dir(ctx), name)), true, 0)
                        cl = e.clips.filter { it.file == rel }
                    }
                    for (c in cl) out.add(c.track)
                }
                out
            }
            if (ids.isEmpty()) { msg = "Seçili kayıtlar okunamadı."; return@launch }
            e.overdubOnly = ids
            val ok = Recorder.start(ctx, RecConfig.forKind(if (kind == 0) 0 else 1), "Overdub") { a -> level = a }
            if (!ok) { e.overdubOnly = null; msg = "Kayıt başlatılamadı. Mikrofon başka bir uygulamada kullanılıyor olabilir."; return@launch }
            recording = true; paused = false; hpLost = false; msg = ""
            e.songMode = true
            e.loopOn = false
            e.songStep = 0
            val tPlay = System.nanoTime()
            e.playing = true
            holder[0] = (tPlay - Recorder.startNanos) / 1_000_000.0
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startTake() else msg = "Kayıt için mikrofon izni gerekli."
    }
    fun requestStart() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startTake()
        else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun pauseTake() { Recorder.pause(); savedStep = e.songStep; e.playing = false; paused = true }
    fun resumeTake() {
        Headphones.refresh(ctx)
        if (!Headphones.usable) { msg = LOCK_MSG; return }
        Recorder.resume(); e.songStep = savedStep; e.playing = true; paused = false; hpLost = false; msg = ""
    }

    val files = Recorder.list(ctx)
    val locked = !Headphones.usable
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Overdub", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Seçtiğin kayıtları dinlerken yeni bir kayıt al. Yeni kayıt ayrı bir kanal olur, eskilere dokunulmaz.",
            fontSize = 12.sp, color = Color(0xFF9CA3AF)
        )
        RecCard("Kulaklık durumu") {
            Text(
                if (Headphones.usable) "🎧 ${Headphones.label} — hazır" else if (Headphones.connected) "🎧 ${Headphones.label} bağlı, ses henüz ona yönlenmedi. Birkaç saniye bekle." else "🔒 Kulaklık bağlı değil",
                fontWeight = FontWeight.Bold, color = if (Headphones.usable) Color(0xFF22C55E) else Color(0xFFF59E0B)
            )
            if (locked) Text(LOCK_MSG, fontSize = 12.sp, color = Color(0xFFEF4444))
            Text("Kablolu kulaklık önerilir. Bluetooth kulaklıklarda gecikme yüksektir (tahmini çıkış gecikmesi: ${e.outputLatencyMs()} ms).", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            if (Headphones.bluetooth) Text("Bluetooth algılandı: kayıt zamanlaması için aşağıdaki gecikme düzeltmesini kullan.", fontSize = 11.sp, color = Color(0xFFF59E0B))
        }
        RecCard("1) Dinlemek istediğin kayıtları seç") {
            if (files.isEmpty()) Text("Henüz kayıt yok. Önce 'Kaydet' sekmesinden bir kayıt al.", color = Color(0xFF9CA3AF))
            files.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = sel.contains(f.name), enabled = !recording,
                        onCheckedChange = { if (it) sel.add(f.name) else sel.remove(f.name) }
                    )
                    Text(recName(ctx, f), modifier = Modifier.weight(1f), maxLines = 1)
                    val m = RecFiles.meta(f)
                    if (m != null) Text(RecFiles.fmt((m.durSec * 1000).toLong()), fontSize = 11.sp, color = Color(0xFF9CA3AF))
                }
            }
            Text("Sadece işaretlediklerin çalar. İşaretlemediklerin çalmaz.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }
        RecCard("2) Ne kaydedeceksin?") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = kind == 0, enabled = !recording, onClick = { kind = 0 }, label = { Text("🎤 Vokal") })
                FilterChip(selected = kind == 1, enabled = !recording, onClick = { kind = 1 }, label = { Text("🎸 Enstrüman") })
            }
            Text(
                if (latAdj < 0f) "Zaman düzeltmesi: otomatik (~${e.outputLatencyMs() + 25} ms)" else "Zaman düzeltmesi: ${latAdj.toInt()} ms",
                fontSize = 12.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(value = if (latAdj < 0f) (e.outputLatencyMs() + 25).toFloat().coerceAtMost(400f) else latAdj, valueRange = 0f..400f,
                    enabled = !recording, onValueChange = { latAdj = it }, modifier = Modifier.weight(1f))
                TextButton(onClick = { latAdj = -1f }, enabled = !recording) { Text("Otomatik") }
            }
            Text("Yeni kayıt geç gelirse (parça geride kalırsa) değeri artır.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }
        RecCard("3) Kaydet") {
            if (recording) {
                Text(RecFiles.fmt(elapsed) + if (paused) "  (duraklatıldı)" else "  ● kayıtta", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                RdBar(level)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (paused) {
                        Button(onClick = { resumeTake() }, enabled = Headphones.usable) { Text(if (hpLost) "▶ Kulaklık takıldı, devam et" else "▶ Devam") }
                    } else OutlinedButton(onClick = { pauseTake() }) { Text("⏸ Duraklat") }
                    Button(onClick = { finishTake() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))) { Text("■ Bitir") }
                }
            } else {
                Button(onClick = { requestStart() }, enabled = !locked && sel.isNotEmpty()) { Text("● Seçilileri dinlerken kaydet", fontSize = 16.sp) }
                if (locked) Text(LOCK_MSG, fontSize = 12.sp, color = Color(0xFFEF4444))
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Color(0xFF22C55E), modifier = Modifier.padding(4.dp))
        Spacer(Modifier.height(16.dp))
    }
}

// =====================================================================
// KANALLAR (çok kanallı kayıt yönetimi)
// =====================================================================
@Composable
fun ChannelsPanel() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val e = AudioEngine
    var ver by remember { mutableIntStateOf(0) }
    var fxOpen by remember { mutableIntStateOf(-1) }
    val chosen = remember { mutableStateListOf<Int>() }
    var renameT by remember { mutableStateOf<Track?>(null) }
    var renameText by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver
    val chans = e.tracks.filter { it.type == 2 }

    fun dup(tr: Track) {
        History.push()
        val nt = Track(e.nextTrackId++, tr.name + " kopya", 2)
        nt.vol = tr.vol; nt.pan = tr.pan; nt.route = tr.route
        e.tracks.add(nt)
        for (c in e.clips.filter { it.track == tr.id }) e.clips.add(Clip(nt.id, c.start, c.lenSteps, c.phase, c.file, c.offS, c.lenS))
        ver++
    }
    fun del(tr: Track) {
        History.push()
        e.clips.removeIf { it.track == tr.id }
        e.tracks.remove(tr)
        chosen.remove(tr.id)
        e.refreshSolo()
        ver++
    }
    fun export(separate: Boolean) {
        val ids = chosen.toList()
        if (ids.isEmpty()) { msg = "Önce dışa aktaracağın kanalları işaretle."; return }
        busy = true
        msg = "Hazırlanıyor…"
        scope.launch {
            val files = withContext(Dispatchers.IO) {
                val out = ArrayList<File>()
                try {
                    e.playing = false
                    val groups = if (separate) ids.map { setOf(it) } else listOf(ids.toSet())
                    for (g in groups) {
                        e.overdubOnly = g
                        val pcm = e.renderSong { }
                        if (pcm != null) {
                            val nm = if (separate) (e.trackById(g.first())?.name ?: "kanal") else "Secili_kanallar"
                            val f = File(ctx.cacheDir, nm.replace(Regex("[^\\p{L}\\p{N}_-]"), "_") + ".wav")
                            Render.writeWav(f, pcm, AudioEngine.SR, 16)
                            out.add(f)
                        }
                    }
                } finally { e.overdubOnly = null }
                out
            }
            busy = false
            if (files.isEmpty()) msg = "Dışa aktarılamadı." else {
                try { shareFiles(ctx, files); msg = "${files.size} dosya hazır ✓" } catch (ex: Exception) { msg = "Paylaşım menüsü açılamadı." }
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Kanallar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Her kayıt ayrı bir kanaldır; birinde yaptığın değişiklik diğerlerini bozmaz. Kanalları zaman çizelgesinde taşımak için Stüdyo > Zaman Çizelgesi'ne bak.",
            fontSize = 12.sp, color = Color(0xFF9CA3AF)
        )
        if (chans.isEmpty()) Text("Henüz kayıt kanalı yok. Kayıtlarım'dan 'Projeye ekle' diyerek veya Overdub ile oluştur.", modifier = Modifier.padding(8.dp))
        chans.forEach { tr ->
            RecCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = chosen.contains(tr.id), onCheckedChange = { if (it) chosen.add(tr.id) else chosen.remove(tr.id) })
                    Text(tr.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                    Text("${e.clips.count { it.track == tr.id }} parça", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                }
                RdBarLive { tr.level }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ses", fontSize = 12.sp, modifier = Modifier.width(36.dp))
                    Slider(value = tr.vol, onValueChange = { tr.vol = it; ver++ }, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = tr.mute, onClick = { tr.mute = !tr.mute; e.refreshSolo(); ver++ }, label = { Text("Mute") })
                    FilterChip(selected = tr.solo, onClick = { tr.solo = !tr.solo; e.refreshSolo(); ver++ }, label = { Text("Solo") })
                    FilterChip(selected = fxOpen == tr.id, onClick = { fxOpen = if (fxOpen == tr.id) -1 else tr.id }, label = { Text("Efekt") })
                    AssistChip(onClick = { renameT = tr; renameText = tr.name }, label = { Text("Ad") })
                    AssistChip(onClick = { dup(tr) }, label = { Text("Çoğalt") })
                    AssistChip(onClick = { del(tr) }, label = { Text("Sil") })
                }
                if (fxOpen == tr.id) FxPanel(tr) { ver++ }
            }
        }
        if (chans.isNotEmpty()) {
            RecCard("Dışa aktar", "İşaretlediğin kanalları dışa aktar. Efektler ve ses seviyeleri dahildir.") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { export(true) }, enabled = !busy) { Text("Ayrı ayrı") }
                    Button(onClick = { export(false) }, enabled = !busy) { Text("Tek dosyada") }
                }
            }
        }
        RecCard("Bütün projeyi dışa aktar") { ExportCard() }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Color(0xFF22C55E), modifier = Modifier.padding(4.dp))
        Spacer(Modifier.height(16.dp))
    }

    renameT?.let { tr ->
        AlertDialog(
            onDismissRequest = { renameT = null },
            title = { Text("Kanal adı") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { tr.name = renameText.trim().ifEmpty { tr.name }; renameT = null; ver++ }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { renameT = null }) { Text("İptal") } }
        )
    }
}

@Composable
private fun RdBarLive(read: () -> Float) {
    var v by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { v = read(); delay(60) } }
    RdBar(v)
}
