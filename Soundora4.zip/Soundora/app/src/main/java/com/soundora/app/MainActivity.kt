package com.soundora.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ProjectStore
import com.soundora.app.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences("soundora", Context.MODE_PRIVATE)
        ThemeState.dark = sp.getBoolean("dark", true)
        AudioEngine.bufferMode = sp.getInt("buffer", 1)
        AudioEngine.baseDir = filesDir
        ProjectStore.init(this)
        AudioEngine.start()
        setContent { SoundoraTheme { SoundoraApp() } }
    }

    override fun onStop() {
        super.onStop()
        AudioEngine.playing = false
        ProjectStore.save(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) AudioEngine.stop()
    }
}

@Composable
private fun StudioHub() {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    val names = listOf("Beat", "Roll", "Timeline", "Kayıt", "Araçlar")
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            names.forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(n) }) }
        }
        Box(Modifier.weight(1f)) {
            when (sub) {
                0 -> BeatScreen()
                1 -> PianoRollScreen()
                2 -> StudioScreen()
                3 -> RecordScreen()
                else -> ToolsScreen()
            }
        }
    }
}

@Composable
fun SoundoraApp() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pv by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val sp = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)
        while (true) {
            delay(sp.getInt("autosave_sec", 15) * 1000L)
            if (sp.getBoolean("autosave", true)) ProjectStore.save(ctx)
        }
    }
    val items = listOf(
        "🎚" to "Studio", "🎹" to "Enstrüman", "🔊" to "Kütüphane",
        "🎓" to "Öğren", "📁" to "Projeler", "⚙" to "Ayarlar"
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                items.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon) }, label = { Text(label, fontSize = 9.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            key(pv) {
                when (tab) {
                    0 -> StudioHub()
                    1 -> InstrumentScreen()
                    2 -> LibraryScreen()
                    3 -> LearnScreen()
                    4 -> ProjectsScreen { pv++ }
                    else -> SettingsScreen()
                }
            }
        }
    }
}
