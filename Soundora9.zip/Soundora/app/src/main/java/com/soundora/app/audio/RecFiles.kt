package com.soundora.app.audio

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class RecPcmVoice(private val data: ShortArray) : Voice() {
    private var pos = 0
    override fun render(): Float {
        if (pos >= data.size) { finished = true; return 0f }
        val v = data[pos] / 32768f
        pos++
        return v
    }
}

/** Soundora'nın kendi yazdığı (44 baytlık başlıklı, 16 bit) WAV kayıtları için yardımcılar. */
object RecFiles {
    class Meta(val sr: Int, val ch: Int, val frames: Long, val peaks: FloatArray) {
        val durSec: Double get() = frames.toDouble() / max(1, sr)
    }

    private val cache = HashMap<String, Meta>()

    @Synchronized
    fun meta(f: File): Meta? {
        val key = f.path + f.lastModified() + f.length()
        cache[key]?.let { return it }
        return try {
            RandomAccessFile(f, "r").use { raf ->
                if (raf.length() < 48) return null
                val h = ByteArray(44)
                raf.readFully(h)
                val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
                if (String(h, 0, 4) != "RIFF" || String(h, 36, 4) != "data") return null
                val ch = bb.getShort(22).toInt().coerceIn(1, 2)
                val sr = bb.getInt(24)
                val frames = (raf.length() - 44) / (2L * ch)
                if (frames <= 0 || sr <= 0) return null
                val peaks = FloatArray(64)
                val tmp = ByteArray(800 * ch)
                for (b in 0 until 64) {
                    val idx = frames * b / 64
                    raf.seek(44 + idx * 2L * ch)
                    val want = min(tmp.size.toLong(), raf.length() - raf.filePointer).toInt()
                    if (want <= 0) continue
                    raf.readFully(tmp, 0, want)
                    var m = 0
                    var i = 0
                    while (i + 1 < want) {
                        val s = ((tmp[i + 1].toInt() shl 8) or (tmp[i].toInt() and 0xff)).toShort().toInt()
                        m = max(m, abs(s))
                        i += 2 * ch
                    }
                    peaks[b] = m / 32768f
                }
                val m = Meta(sr, ch, frames, peaks)
                cache[key] = m
                m
            }
        } catch (ex: Exception) { null }
    }

    /** Dosyayı mono ve 44.1 kHz'e çevirerek okur. */
    fun readMono(f: File): ShortArray? {
        return try {
            val b = f.readBytes()
            if (b.size < 48 || String(b, 0, 4) != "RIFF" || String(b, 36, 4) != "data") return null
            val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            val ch = bb.getShort(22).toInt().coerceIn(1, 2)
            val sr = bb.getInt(24)
            val frames = (b.size - 44) / (2 * ch)
            val mono = ShortArray(frames) { i ->
                var sum = 0
                for (c in 0 until ch) sum += bb.getShort(44 + (i * ch + c) * 2).toInt()
                (sum / ch).toShort()
            }
            if (sr != AudioEngine.SR && sr > 0) Exporter.resample(mono, sr, AudioEngine.SR) else mono
        } catch (ex: Throwable) { null }
    }

    /** recordings klasörüne benzersiz adla 16 bit mono WAV yazar. */
    fun save(ctx: Context, base: String, data: ShortArray): File {
        val safe = base.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").trim().ifEmpty { "Kayit" }
        val dir = Recorder.dir(ctx)
        var f = File(dir, "$safe.wav")
        var n = 2
        while (f.exists()) { f = File(dir, "${safe}_$n.wav"); n++ }
        Render.writeWav(f, data, AudioEngine.SR, 16)
        return f
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%02d:%02d", s / 60, s % 60)
    }
}
