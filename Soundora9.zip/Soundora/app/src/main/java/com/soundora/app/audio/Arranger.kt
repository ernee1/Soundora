package com.soundora.app.audio

object Arranger {
    /**
     * Kaydı projeye ekler. trackId>=0: o kanala; newTrack: yeni ses kanalı; yoksa ilk ses kanalına.
     * Dönen değer: kanal kimliği, başarısızsa -1. Disk okuyabilir; ana iş parçacığında çağırma.
     */
    fun addRecording(rel: String, trackName: String?, newTrack: Boolean, startStep: Int, offSamples: Int = 0, trackId: Int = -1): Int {
        val s = SampleStore.get(rel) ?: return -1
        val len = s.data.size - offSamples
        if (len <= 1000) return -1
        val e = AudioEngine
        History.push()
        val tr = (if (trackId >= 0) e.trackById(trackId) else if (newTrack) null else e.tracks.firstOrNull { it.type == 2 })
            ?: Track(e.nextTrackId++, trackName ?: "Ses ${e.tracks.count { it.type == 2 } + 1}", 2).also { e.tracks.add(it) }
        e.clips.add(Clip(tr.id, startStep, 0, 0, rel, offSamples, len))
        return tr.id
    }
}
