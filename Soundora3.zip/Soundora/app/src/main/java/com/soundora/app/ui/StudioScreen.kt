package com.soundora.app.ui

import android.graphics.Paint
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Clip
import com.soundora.app.audio.History
import com.soundora.app.audio.Recorder
import com.soundora.app.audio.SampleStore
import com.soundora.app.audio.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val RULER = 24.dp
private val LANE = 56.dp
private val typeColors = listOf(Color(0xFFF59E0B), Purple, Color(0xFF22D3EE))

@Composable
fun StudioScreen() {
    val e = AudioEngine
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var pos by remember { mutableIntStateOf(e.songStep) }
    var playing by remember { mutableStateOf(e.playing && e.songMode) }
    var vis by remember { mutableIntStateOf(64) }
    var first by remember { mutableIntStateOf(0) }
    var selTrack by remember { mutableIntStateOf(e.tracks.firstOrNull()?.id ?: 0) }
    var selClip by remember { mutableStateOf<Clip?>(null) }
    var msg by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }

    @Suppress("UNUSED_VARIABLE") val subscribe = ver
    val endMax = e.clips.maxOfOrNull { it.start + e.clipSteps(it) } ?: 0
    val songLen = (((endMax + 15) / 16) * 16 + 64).coerceAtLeast(128)
    val maxFirst = (songLen - vis).coerceAtLeast(0)
    val f0 = first.coerceIn(0, maxFirst)
    val visTracks = e.tracks.filter { !it.hidden }
    val spsD = AudioEngine.SR * 60.0 / e.bpm / 4.0

    LaunchedEffect(Unit) {
        while (true) {
            playing = e.playing && e.songMode
            if (playing) {
                pos = e.songStep
                if (pos < first || pos >= first + vis) first = pos
            }
            delay(30)
        }
    }
    LaunchedEffect(ver) {
        val missing = e.clips.toList().mapNotNull { it.file }.filter { SampleStore.peek(it) == null && !SampleStore.isFailed(it) }
        if (missing.isNotEmpty()) {
            withContext(Dispatchers.IO) { missing.forEach { SampleStore.get(it) } }
            ver++
        }
    }

    fun trackOf(id: Int): Track? = e.tracks.firstOrNull { it.id == id }
    fun seekTo(step: Int) {
        val s = max(0, step)
        e.songStep = s
        pos = s
        if (e.playing && e.songMode) e.seekRequest = s
    }
    fun addPatternClip(tr: Track) {
        History.push()
        val c = Clip(tr.id, (e.songStep / 16) * 16, max(16, e.steps))
        e.clips.add(c); selClip = c; ver++
    }
    fun addAudio(rel: String) {
        val tr = trackOf(selTrack)?.takeIf { it.type == 2 } ?: e.tracks.firstOrNull { it.type == 2 }
        if (tr == null) { msg = "Önce bir Vokal/Ses kanalı ekle."; return }
        scope.launch {
            val s = withContext(Dispatchers.IO) { SampleStore.get(rel) }
            if (s == null) { msg = "Dosya okunamadı (16-bit WAV gerekli)."; return@launch }
            History.push()
            val c = Clip(tr.id, (e.songStep / 4) * 4, 0, 0, rel, 0, s.data.size)
            e.clips.add(c); selClip = c; msg = ""; ver++
        }
    }
    fun addTrack(name: String) {
        History.push()
        val n = e.tracks.count { it.type == 2 } + 1
        val t = Track(e.nextTrackId++, "$name $n", 2)
        e.tracks.add(t); selTrack = t.id; ver++
    }
    fun split() {
        val c = selClip ?: return
        val len = e.clipSteps(c)
        val p = e.songStep
        if (p <= c.start || p >= c.start + len) { msg = "İmleç parçanın içinde olmalı (çubuğa dokun)."; return }
        History.push()
        val firstLen = p - c.start
        val f = c.file
        val rest: Clip
        if (f != null) {
            val firstSamples = (firstLen * spsD).toInt()
            rest = Clip(c.track, p, 0, 0, f, c.offS + firstSamples, c.lenS - firstSamples)
            c.lenS = firstSamples
        } else {
            rest = Clip(c.track, p, len - firstLen, (c.phase + firstLen) % max(1, e.steps))
            c.lenSteps = firstLen
        }
        e.clips.add(rest); selClip = rest; msg = ""; ver++
    }
    fun copyClip() {
        val c = selClip ?: return
        History.push()
        val len = e.clipSteps(c)
        val n = Clip(c.track, c.start + len, c.lenSteps, (c.phase + len) % max(1, e.steps), c.file, c.offS, c.lenS)
        e.clips.add(n); selClip = n; ver++
    }
    fun deleteClip() {
        val c = selClip ?: return
        History.push(); e.clips.remove(c); selClip = null; ver++
    }
    fun merge() {
        val c = selClip ?: return
        val len = e.clipSteps(c)
        val next = e.clips.firstOrNull { it !== c && it.track == c.track && it.start == c.start + len }
        var ok = false
        if (next != null) {
            if (c.file != null) {
                ok = next.file == c.file && next.offS == c.offS + c.lenS
                if (ok) { History.push(); c.lenS += next.lenS }
            } else {
                ok = next.file == null && next.phase == (c.phase + len) % max(1, e.steps)
                if (ok) { History.push(); c.lenSteps += next.lenSteps }
            }
            if (ok) e.clips.remove(next)
        }
        msg = if (ok) "" else "Bu parça bitişik bir parçayla birleştirilemez."
        ver++
    }
    fun trim(head: Boolean) {
        val c = selClip ?: return
        History.push()
        if (c.file != null) {
            val beat = (4 * spsD).toInt()
            if (c.lenS > beat * 2) {
                if (head) { c.offS += beat; c.lenS -= beat; c.start += 4 } else c.lenS -= beat
            }
        } else {
            c.lenSteps = max(16, c.lenSteps + if (head) 16 else -16)
        }
        ver++
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val rel = withContext(Dispatchers.IO) { SampleStore.importFrom(ctx, uri) }
                if (rel != null) addAudio(rel) else msg = "İçe aktarılamadı. 16-bit WAV dosyası seç."
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // ---- Transport
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = { seekTo(if (e.loopOn) e.loopStart else 0) }) { Text("⏮") }
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable {
                        if (playing) e.playing = false
                        else { e.songMode = true; e.songStep = pos; e.playing = true }
                    },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 24.sp, color = Color.White) }
            Column(Modifier.weight(1f)) {
                val sec = pos * 60.0 / e.bpm / 4.0
                Text("Bar ${pos / 16 + 1}.${(pos % 16) / 4 + 1}", fontWeight = FontWeight.Bold)
                Text(String.format("%d:%04.1f", (sec / 60).toInt(), sec % 60), fontSize = 12.sp, color = Color(0xFF9CA3AF))
            }
            OutlinedButton(onClick = { if (e.bpm > 40) e.bpm -= 5; ver++ }, contentPadding = PaddingValues(8.dp)) { Text("−") }
            Text("${e.bpm}", fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { if (e.bpm < 220) e.bpm += 5; ver++ }, contentPadding = PaddingValues(8.dp)) { Text("+") }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = e.metronome, onClick = { e.metronome = !e.metronome; ver++ }, label = { Text("Metronom") })
            FilterChip(selected = e.loopOn, onClick = { e.loopOn = !e.loopOn; ver++ }, label = { Text("Döngü") })
            AssistChip(onClick = {
                e.loopStart = (pos / 4) * 4
                if (e.loopEnd <= e.loopStart) e.loopEnd = e.loopStart + 16
                ver++
            }, label = { Text("[ Başlangıç") })
            AssistChip(onClick = { e.loopEnd = max(e.loopStart + 4, (pos / 4) * 4); ver++ }, label = { Text("Bitiş ]") })
            AssistChip(onClick = { if (History.undo()) { selClip = null; ver++ } }, label = { Text("↶ Geri al") })
            AssistChip(onClick = { if (History.redo()) { selClip = null; ver++ } }, label = { Text("↷ İleri al") })
        }

        // ---- Zaman çizelgesi
        Spacer(Modifier.height(8.dp))
        val nVis = visTracks.size
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.width(84.dp)) {
                Spacer(Modifier.height(RULER))
                visTracks.forEach { tr ->
                    Column(
                        Modifier.fillMaxWidth().height(LANE).clickable { selTrack = tr.id; ver++ }
                            .background(if (selTrack == tr.id) Color(0xFF232C52) else Color.Transparent),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(tr.name, fontSize = 11.sp, maxLines = 1, color = typeColors[tr.type], modifier = Modifier.padding(start = 4.dp))
                        Row(Modifier.padding(start = 4.dp, top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                Modifier.size(26.dp).clip(RoundedCornerShape(6.dp))
                                    .background(if (tr.mute) Color(0xFFEF4444) else Color(0xFF232C52))
                                    .clickable { tr.mute = !tr.mute; e.refreshSolo(); ver++ },
                                contentAlignment = Alignment.Center
                            ) { Text("M", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            Box(
                                Modifier.size(26.dp).clip(RoundedCornerShape(6.dp))
                                    .background(if (tr.solo) Color(0xFFF59E0B) else Color(0xFF232C52))
                                    .clickable { tr.solo = !tr.solo; e.refreshSolo(); ver++ },
                                contentAlignment = Alignment.Center
                            ) { Text("S", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
            Box(
                Modifier.weight(1f).height(RULER + LANE * nVis)
                    .pointerInput(listOf(vis, f0)) {
                        detectTapGestures(onTap = { off ->
                            val cw = size.width / vis.toFloat()
                            val step = f0 + (off.x / cw).toInt().coerceIn(0, vis - 1)
                            val rulerPx = RULER.toPx()
                            val lanePx = LANE.toPx()
                            if (off.y < rulerPx) {
                                seekTo(step)
                            } else {
                                val lane = ((off.y - rulerPx) / lanePx).toInt()
                                val vt = e.tracks.filter { !it.hidden }
                                if (lane in vt.indices) {
                                    val tr = vt[lane]
                                    selTrack = tr.id
                                    val c = e.clips.lastOrNull { it.track == tr.id && step >= it.start && step < it.start + e.clipSteps(it) }
                                    selClip = c
                                    if (c == null) seekTo(step)
                                    ver++
                                }
                            }
                        })
                    }
                    .pointerInput(listOf(vis, f0)) {
                        var dragClip: Clip? = null
                        var startS = 0
                        var accX = 0f
                        var scrub = false
                        detectDragGestures(
                            onDragStart = { off ->
                                val cw = size.width / vis.toFloat()
                                val rulerPx = RULER.toPx()
                                val lanePx = LANE.toPx()
                                accX = 0f; dragClip = null; scrub = false
                                if (off.y < rulerPx) {
                                    scrub = true
                                    seekTo(f0 + (off.x / cw).toInt().coerceIn(0, vis - 1))
                                } else {
                                    val step = f0 + (off.x / cw).toInt().coerceIn(0, vis - 1)
                                    val lane = ((off.y - rulerPx) / lanePx).toInt()
                                    val vt = e.tracks.filter { !it.hidden }
                                    if (lane in vt.indices) {
                                        val tr = vt[lane]
                                        val c = e.clips.lastOrNull { it.track == tr.id && step >= it.start && step < it.start + e.clipSteps(it) }
                                        if (c != null) {
                                            History.push()
                                            dragClip = c; startS = c.start; selClip = c; selTrack = tr.id
                                        }
                                    }
                                }
                            },
                            onDrag = { change, amt ->
                                change.consume()
                                val cw = size.width / vis.toFloat()
                                if (scrub) {
                                    seekTo(f0 + (change.position.x / cw).toInt().coerceIn(0, vis - 1))
                                } else {
                                    val c = dragClip
                                    if (c != null) {
                                        accX += amt.x
                                        val ns = max(0, startS + (accX / cw).roundToInt())
                                        c.start = (ns / 4) * 4
                                        ver++
                                    }
                                }
                            },
                            onDragEnd = { dragClip = null; scrub = false },
                            onDragCancel = { dragClip = null; scrub = false }
                        )
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    @Suppress("UNUSED_VARIABLE") val sub = ver
                    val p0 = pos
                    val rulerPx = RULER.toPx()
                    val lanePx = LANE.toPx()
                    val cw = size.width / vis.toFloat()
                    val vt = e.tracks.filter { !it.hidden }
                    drawRect(Color(0xFF0F1530), Offset.Zero, Size(size.width, rulerPx))
                    for (i in vt.indices) {
                        drawRect(
                            if (i % 2 == 0) Color(0xFF161D3A) else Color(0xFF121833),
                            Offset(0f, rulerPx + i * lanePx), Size(size.width, lanePx)
                        )
                    }
                    for (c in 0..vis) {
                        val idx = f0 + c
                        if (idx % 4 != 0) continue
                        val bar = idx % 16 == 0
                        drawLine(
                            Color.White.copy(alpha = if (bar) 0.3f else 0.08f),
                            Offset(c * cw, if (bar) 0f else rulerPx), Offset(c * cw, size.height), if (bar) 2f else 1f
                        )
                    }
                    drawIntoCanvas { cv ->
                        paint.textSize = 10.sp.toPx()
                        paint.color = 0xFF9CA3AF.toInt()
                        for (c in 0..vis) {
                            val idx = f0 + c
                            if (idx % 16 == 0) cv.nativeCanvas.drawText("${idx / 16 + 1}", c * cw + 3f, rulerPx - 8f, paint)
                        }
                    }
                    if (e.loopOn && e.loopEnd > e.loopStart) {
                        val l = max(0f, (e.loopStart - f0) * cw)
                        val r = min(size.width, (e.loopEnd - f0) * cw)
                        if (r > l) drawRect(Color(0x33F59E0B), Offset(l, 0f), Size(r - l, size.height))
                    }
                    vt.forEachIndexed { lane, tr ->
                        val col = typeColors[tr.type]
                        for (c in e.clips) {
                            if (c.track != tr.id) continue
                            val len = e.clipSteps(c)
                            val x0 = (c.start - f0) * cw
                            val w = len * cw
                            if (x0 + w < 0f || x0 > size.width) continue
                            val top = rulerPx + lane * lanePx + 3f
                            val h = lanePx - 6f
                            val sel = c === selClip
                            drawRoundRect(col.copy(alpha = 0.3f), Offset(x0, top), Size(w, h), CornerRadius(8f, 8f))
                            val f = c.file
                            if (f != null) {
                                val s = SampleStore.peek(f)
                                if (s != null) {
                                    var x = max(0f, x0)
                                    val x1 = min(size.width, x0 + w)
                                    val mid = top + h / 2
                                    while (x < x1) {
                                        val frac = (x - x0) / w
                                        val idx = ((c.offS + (frac * c.lenS).toInt()) / 512).coerceIn(0, s.peaks.size - 1)
                                        val half = s.peaks[idx] * h * 0.45f
                                        drawLine(col, Offset(x, mid - half), Offset(x, mid + half), 2f)
                                        x += 3f
                                    }
                                }
                            }
                            drawRoundRect(
                                if (sel) Color.White else col, Offset(x0, top), Size(w, h), CornerRadius(8f, 8f),
                                style = Stroke(width = if (sel) 4f else 2f)
                            )
                            val label = if (f != null) f.substringAfterLast('/').removeSuffix(".wav").take(14) else tr.name
                            drawIntoCanvas { cv ->
                                paint.textSize = 10.sp.toPx()
                                paint.color = 0xFFFFFFFF.toInt()
                                cv.nativeCanvas.drawText(label, max(x0, 0f) + 6f, top + 16f, paint)
                            }
                        }
                    }
                    val px = (p0 - f0) * cw
                    if (px >= 0f && px <= size.width) drawLine(Color.White, Offset(px, 0f), Offset(px, size.height), 3f)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (vis > 16) vis /= 2 }) { Text("Yakınlaş") }
            OutlinedButton(onClick = { if (vis < 512) vis *= 2 }) { Text("Uzaklaş") }
        }
        if (maxFirst > 0) {
            Slider(value = f0.toFloat(), valueRange = 0f..maxFirst.toFloat(), onValueChange = { first = it.roundToInt() })
        }
        Text(
            "Çubuğu taşımak için cetvele dokun/sürükle. Parçaya dokun: seç, sürükle: taşı.",
            fontSize = 11.sp, color = Color(0xFF9CA3AF)
        )
        if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)

        // ---- Seçili parça
        val sc = selClip
        if (sc != null && e.clips.contains(sc)) {
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
                Text("Seçili parça", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { split() }, label = { Text("Böl") })
                    AssistChip(onClick = { copyClip() }, label = { Text("Kopyala") })
                    AssistChip(onClick = { merge() }, label = { Text("Birleştir") })
                    AssistChip(onClick = { deleteClip() }, label = { Text("Sil") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (sc.file != null) {
                        AssistChip(onClick = { trim(true) }, label = { Text("Başı kırp") })
                        AssistChip(onClick = { trim(false) }, label = { Text("Sonu kırp") })
                    } else {
                        AssistChip(onClick = { trim(false) }, label = { Text("−1 bar") })
                        AssistChip(onClick = { trim(true) }, label = { Text("+1 bar") })
                    }
                }
            }
        }

        // ---- Seçili kanal
        val st = trackOf(selTrack)
        if (st != null) {
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
                Text("Kanal: ${st.name}", fontWeight = FontWeight.Bold, color = typeColors[st.type])
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ses", fontSize = 12.sp, modifier = Modifier.width(40.dp))
                    Slider(value = st.vol, onValueChange = { st.vol = it; ver++ }, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (st.type == 2) showAdd = true else addPatternClip(st) }) {
                        Text(if (st.type == 2) "Ses ekle" else "Parça ekle")
                    }
                    OutlinedButton(onClick = {
                        st.hidden = true
                        selTrack = e.tracks.firstOrNull { !it.hidden }?.id ?: st.id
                        ver++
                    }) { Text("Gizle") }
                    if (st.type == 2) {
                        OutlinedButton(onClick = {
                            History.push()
                            e.clips.removeIf { it.track == st.id }
                            e.tracks.remove(st)
                            selClip = null
                            selTrack = e.tracks.firstOrNull()?.id ?: 0
                            e.refreshSolo(); ver++
                        }) { Text("Kanalı sil") }
                    }
                }
                Text(
                    if (st.type == 0) "Beat Maker ritmini bu kanal çalar." else if (st.type == 1) "Piano Roll melodisini bu kanal çalar." else "Kayıt veya WAV dosyası ekle.",
                    fontSize = 11.sp, color = Color(0xFF9CA3AF)
                )
            }
        }

        // ---- Kanal ekle / gizli kanallar
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { addTrack("Vokal") }) { Text("+ Vokal kanalı") }
            Button(onClick = { addTrack("Ses") }) { Text("+ Ses kanalı") }
            e.tracks.filter { it.hidden }.forEach { t ->
                AssistChip(onClick = { t.hidden = false; ver++ }, label = { Text("Göster: ${t.name}") })
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showAdd) {
        val recs = Recorder.list(ctx).map { "recordings/${it.name}" }
        val imported = (File(ctx.filesDir, "audio").listFiles()?.filter { it.extension == "wav" } ?: emptyList()).map { "audio/${it.name}" }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Ses ekle") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()).heightIn(max = 320.dp)) {
                    if (recs.isEmpty() && imported.isEmpty()) Text("Henüz kayıt veya dosya yok. Kayıt sekmesinden kayıt al ya da cihazdan WAV seç.")
                    recs.forEach { r ->
                        TextButton(onClick = { showAdd = false; addAudio(r) }) { Text("🎤 " + r.substringAfter('/').removeSuffix(".wav")) }
                    }
                    imported.forEach { r ->
                        TextButton(onClick = { showAdd = false; addAudio(r) }) { Text("📁 " + r.substringAfter('/').removeSuffix(".wav")) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showAdd = false
                    importLauncher.launch(arrayOf("audio/*", "application/octet-stream"))
                }) { Text("Cihazdan WAV seç") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Kapat") } }
        )
    }
}
