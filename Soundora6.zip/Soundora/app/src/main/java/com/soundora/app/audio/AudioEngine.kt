package com.soundora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh

class Note(var start: Int, var len: Int, var pitch: Int)

/** type: 0 Davul (Beat Maker), 1 Melodi (Piano Roll), 2 Ses (kayıt / dosya) */
class Track(
    val id: Int, var name: String, val type: Int,
    var vol: Float = 0.9f, var mute: Boolean = false, var solo: Boolean = false, var hidden: Boolean = false
) {
    val fx = FxChain()
    @Volatile var pan = 0f
    @Volatile var route = 0
    @Volatile var level = 0f
}

/** Davul/Melodi parçası: start, lenSteps, phase. Ses parçası: start, file, offS, lenS (örnek sayısı). */
class Clip(
    var track: Int, var start: Int, var lenSteps: Int, var phase: Int = 0,
    var file: String? = null, var offS: Int = 0, var lenS: Int = 0
)

private class Held(val v: Voice, var left: Int)

object AudioEngine {
    const val SR = 44100
    const val ROWS = 7
    const val MAX_STEPS = 64
    const val KINDS = 11
    val rowNames = listOf("Kick", "Snare", "Clap", "Hi-Hat", "Açık Hat", "Tom", "Rim")
    val kitNames = listOf("Standart", "808 Trap", "Lo-fi", "Elektronik")
    val kindNames = listOf("Piyano", "Lead Synth", "Bas Gitar", "Akustik", "Elektro", "E.Piyano", "Org", "Strings", "Pad", "Pluck", "Synth Bas")

    val pattern = Array(ROWS) { BooleanArray(MAX_STEPS) }
    val rowVol = FloatArray(ROWS) { 0.8f }
    val rowMute = BooleanArray(ROWS)
    val rowSolo = BooleanArray(ROWS)
    val melody = CopyOnWriteArrayList<Note>()
    val instVol = FloatArray(KINDS) { 0.8f }
    val adsr = Array(KINDS) { defaultAdsr(it) }
    val tracks = CopyOnWriteArrayList<Track>()
    val clips = CopyOnWriteArrayList<Clip>()
    val masterFx = FxChain()
    val masterFxR = FxChain()
    val grpVol = FloatArray(4) { 0.9f }
    val grpMute = BooleanArray(4)
    private val liveSt = ShortArray(512)
    val bands = FloatArray(8)

    @Volatile var baseDir: File? = null
    @Volatile var bpm = 100
    @Volatile var playing = false
    @Volatile var songMode = false
    @Volatile var currentStep = -1
    @Volatile var songStep = 0
    @Volatile var seekRequest = -1
    @Volatile var masterVol = 0.8f
    @Volatile var steps = 16
    @Volatile var swing = 0f
    @Volatile var kit = 0
    @Volatile var melodyKind = 0
    @Volatile var pitchSemi = 0f
    @Volatile var metronome = false
    @Volatile var loopOn = false
    @Volatile var loopStart = 0
    @Volatile var loopEnd = 16
    @Volatile var nextTrackId = 3
    @Volatile var soloActive = false
    @Volatile var autoMaster = false
    @Volatile var bufferMode = 1
    @Volatile var rollRoot = 0
    @Volatile var rollScale = 0
    @Volatile var rollLock = false
    @Volatile private var exporting = false
    @Volatile private var exportAck = false

    private val voices = CopyOnWriteArrayList<Voice>()
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    // ses iş parçacığı durumu
    private var acc = 0.0
    private var step = 0
    private var wasPlaying = false
    private var lastSong = false
    private val held = ArrayList<Held>()
    private val clipVoices = ArrayList<ClipVoice>()
    private val bandF = Array(8) { Biquad() }
    private val bandEnv = FloatArray(8)

    init {
        resetProject()
        val fr = doubleArrayOf(60.0, 120.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0)
        for (b in 0 until 8) bandF[b].set(5, fr[b], 1.4, 0.0)
        masterFx.on[0] = true; masterFx.p[0][0] = 1.5f; masterFx.p[0][1] = 0f; masterFx.p[0][2] = 2f
        masterFx.on[3] = true; masterFx.p[3][0] = -14f; masterFx.p[3][1] = 3f; masterFx.p[3][2] = 3f
        masterFx.refresh()
        masterFxR.on[0] = true; masterFxR.p[0][0] = 1.5f; masterFxR.p[0][1] = 0f; masterFxR.p[0][2] = 2f
        masterFxR.on[3] = true; masterFxR.p[3][0] = -14f; masterFxR.p[3][1] = 3f; masterFxR.p[3][2] = 3f
        masterFxR.refresh()
    }

    fun defaultAdsr(kind: Int): FloatArray = when (kind) {
        0 -> floatArrayOf(0.005f, 0.3f, 1f, 0.18f)
        1 -> floatArrayOf(0.01f, 0.2f, 0.7f, 0.2f)
        2 -> floatArrayOf(0.005f, 0.3f, 1f, 0.2f)
        3, 4 -> floatArrayOf(0.002f, 0.5f, 1f, 0.3f)
        5 -> floatArrayOf(0.005f, 0.3f, 1f, 0.25f)
        6 -> floatArrayOf(0.01f, 0.05f, 1f, 0.08f)
        7 -> floatArrayOf(0.35f, 0.3f, 0.9f, 0.6f)
        8 -> floatArrayOf(0.6f, 0.5f, 0.9f, 0.9f)
        9 -> floatArrayOf(0.002f, 0.3f, 1f, 0.2f)
        else -> floatArrayOf(0.005f, 0.2f, 0.8f, 0.12f)
    }

    /** Yeni boş proje durumu */
    fun resetProject() {
        playing = false
        for (r in 0 until ROWS) {
            for (s in 0 until MAX_STEPS) pattern[r][s] = false
            rowVol[r] = 0.8f; rowMute[r] = false; rowSolo[r] = false
        }
        melody.clear()
        for (k in 0 until KINDS) { instVol[k] = 0.8f; adsr[k] = defaultAdsr(k) }
        bpm = 100; steps = 16; swing = 0f; kit = 0; melodyKind = 0
        metronome = false; loopOn = false; loopStart = 0; loopEnd = 16; songStep = 0; seekRequest = -1
        autoMaster = false; rollRoot = 0; rollScale = 0; rollLock = false
        for (g in 0 until 4) { grpVol[g] = 0.9f; grpMute[g] = false }
        masterVol = 0.8f
        tracks.clear(); clips.clear()
        tracks.add(Track(1, "Davul", 0))
        tracks.add(Track(2, "Melodi", 1))
        clips.add(Clip(1, 0, 64))
        clips.add(Clip(2, 0, 64))
        nextTrackId = 3
        refreshSolo()
    }

    fun refreshSolo() { soloActive = tracks.any { it.solo } }

    fun gainOf(t: Track?): Float {
        if (t == null) return 1f
        if (t.mute) return 0f
        if (soloActive && !t.solo) return 0f
        return t.vol
    }

    fun trackById(id: Int): Track? = tracks.firstOrNull { it.id == id }

    fun clipSteps(c: Clip): Int =
        if (c.file != null) max(1, ceil(c.lenS / (SR * 60.0 / bpm / 4.0)).toInt()) else c.lenSteps

    fun start() {
        if (running) return
        val minB = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val want = when (bufferMode) { 0 -> 2048; 2 -> 16384; else -> 4096 }
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SR)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setBufferSizeInBytes(max(minB, want))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        thread = Thread({ loop(t) }, "soundora-audio").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun stop() {
        running = false
        thread?.join()
        track?.let { it.stop(); it.release() }
        track = null
        voices.clear()
        held.clear(); clipVoices.clear()
        wasPlaying = false
        playing = false
        currentStep = -1
    }

    fun restart() { stop(); start() }

    private fun loop(t: AudioTrack) {
        val chunk = ShortArray(256)
        t.play()
        while (running) {
            if (exporting) {
                exportAck = true
                try { Thread.sleep(5) } catch (ex: InterruptedException) { }
                continue
            }
            exportAck = false
            renderChunk(chunk, true, liveSt)
            t.write(liveSt, 0, liveSt.size)
        }
    }

    private fun cleanup() {
        for (h in held) h.v.release()
        held.clear()
        for (c in clipVoices) c.finished = true
        clipVoices.clear()
    }

    private fun renderChunk(chunk: ShortArray, live: Boolean, st: ShortArray?) {
        val p = playing
        val song = songMode
        if (!p && wasPlaying) { currentStep = -1; cleanup() }
        if (p && wasPlaying && song != lastSong) cleanup()
        if (p && (!wasPlaying || song != lastSong)) {
            acc = 0.0
            step = if (song) max(0, songStep) else 0
            if (song) startOverlapping(step)
            if (live && !wasPlaying) Meter.reset()
        }
        if (p && song && seekRequest >= 0) {
            step = seekRequest
            seekRequest = -1
            acc = 0.0
            cleanup()
            startOverlapping(step)
        }
        wasPlaying = p
        lastSong = song

        val sps = SR * 60.0 / bpm / 4.0
        val snap = voices.toTypedArray()
        val trs = tracks.toTypedArray()
        val nb = trs.size
        val busSum = FloatArray(nb)
        val gL = FloatArray(nb)
        val gR = FloatArray(nb)
        val pk = FloatArray(nb)
        for (k in 0 until nb) {
            val pn = trs[k].pan.coerceIn(-1f, 1f)
            gL[k] = if (pn > 0f) 1f - pn else 1f
            gR[k] = if (pn < 0f) 1f + pn else 1f
        }
        val grL = FloatArray(4)
        val grR = FloatArray(4)
        val grG = FloatArray(4) { if (grpMute[it]) 0f else grpVol[it] }
        val idx = IntArray(snap.size) { i ->
            val b = snap[i].bus
            var r = -1
            for (k in 0 until nb) if (trs[k].id == b) { r = k; break }
            r
        }
        for (i in chunk.indices) {
            if (p) {
                if (acc <= 0.0) {
                    if (song) {
                        if (loopOn && loopEnd > loopStart && step >= loopEnd) {
                            step = loopStart
                            cleanup()
                            startOverlapping(step)
                        }
                        triggerSong(step)
                        songStep = step
                        currentStep = step % max(1, steps)
                    } else {
                        if (step >= steps) step = 0
                        triggerPattern(step)
                        currentStep = step
                    }
                    val sw = swing.toDouble()
                    val gap = if (step % 2 == 0) sps * (1.0 + sw) else sps * (1.0 - sw)
                    step = if (song) step + 1 else (step + 1) % max(1, steps)
                    acc += gap
                }
                acc -= 1.0
            }
            var dry = 0f
            for (k in 0 until nb) busSum[k] = 0f
            for (g in 0 until 4) { grL[g] = 0f; grR[g] = 0f }
            for (k in snap.indices) {
                val v = snap[k]
                if (v.finished) continue
                val s = v.render()
                val bi = idx[k]
                if (bi < 0) dry += s else busSum[bi] += s
            }
            var mixL = dry
            var mixR = dry
            for (k in 0 until nb) {
                val tr = trs[k]
                val x = if (tr.fx.active) tr.fx.process(busSum[k]) else busSum[k]
                val ax = abs(x)
                if (ax > pk[k]) pk[k] = ax
                val l = x * gL[k]
                val r = x * gR[k]
                val rt = tr.route
                if (rt in 1..4) { grL[rt - 1] += l; grR[rt - 1] += r } else { mixL += l; mixR += r }
            }
            for (g in 0 until 4) { mixL += grL[g] * grG[g]; mixR += grR[g] * grG[g] }
            mixL *= masterVol
            mixR *= masterVol
            if (autoMaster) {
                mixL = tanh(masterFx.process(mixL) * 1.1f)
                mixR = tanh(masterFxR.process(mixR) * 1.1f)
            }
            val oL = mixL.coerceIn(-1f, 1f)
            val oR = mixR.coerceIn(-1f, 1f)
            val om = (oL + oR) * 0.5f
            chunk[i] = (om * 32767f).toInt().toShort()
            if (st != null) {
                st[2 * i] = (oL * 32767f).toInt().toShort()
                st[2 * i + 1] = (oR * 32767f).toInt().toShort()
            }
            if (live) {
                Meter.feed(mixL, mixR)
                val xd = om.toDouble()
                for (b in 0 until 8) {
                    val a = abs(bandF[b].proc(xd)).toFloat()
                    bandEnv[b] += (if (a > bandEnv[b]) 0.2f else 0.0015f) * (a - bandEnv[b])
                }
            }
        }
        if (live) {
            for (b in 0 until 8) bands[b] = bandEnv[b]
            for (k in 0 until nb) trs[k].level = max(pk[k], trs[k].level * 0.85f)
        }
        voices.removeIf { it.finished }
        clipVoices.removeIf { it.finished }
    }

    private fun advanceHeld() {
        val it = held.iterator()
        while (it.hasNext()) {
            val h = it.next()
            h.left--
            if (h.left <= 0) { h.v.release(); it.remove() }
        }
    }

    private fun click(st: Int) {
        if (metronome && st % 4 == 0) addVoice(ClickVoice(st % 16 == 0), -1)
    }

    private fun playDrums(ps: Int, tr: Track?) {
        val g = gainOf(tr)
        if (g <= 0f) return
        val bus = tr?.id ?: -1
        val anySolo = rowSolo.any { s -> s }
        for (r in 0 until ROWS) {
            if (pattern[r][ps] && !rowMute[r] && (!anySolo || rowSolo[r])) addVoice(DrumVoice(r, rowVol[r] * g, kit), bus)
        }
    }

    private fun playMelody(ps: Int, tr: Track?) {
        val g = gainOf(tr)
        if (g <= 0f) return
        val bus = tr?.id ?: -1
        for (n in melody) {
            if (n.start == ps) {
                val v = NoteVoice(melodyKind, n.pitch, pitchSemi.toDouble(), g.toDouble())
                addVoice(v, bus)
                held.add(Held(v, n.len))
            }
        }
    }

    private fun triggerPattern(st: Int) {
        advanceHeld()
        click(st)
        playDrums(st, tracks.firstOrNull { it.type == 0 })
        playMelody(st, tracks.firstOrNull { it.type == 1 })
    }

    private fun triggerSong(st: Int) {
        advanceHeld()
        click(st)
        val n = max(1, steps)
        for (c in clips) {
            val tr = trackById(c.track) ?: continue
            if (c.file != null) {
                if (c.start == st) startClip(c, 0)
            } else if (st >= c.start && st < c.start + c.lenSteps) {
                val ps = (((st - c.start + c.phase) % n) + n) % n
                if (tr.type == 0) playDrums(ps, tr)
                else if (tr.type == 1) playMelody(ps, tr)
            }
        }
    }

    private fun startClip(c: Clip, offset: Int) {
        val f = c.file ?: return
        val tr = trackById(c.track) ?: return
        val s = SampleStore.get(f) ?: return
        val startPos = c.offS + offset
        val end = c.offS + c.lenS
        if (startPos >= end) return
        val v = ClipVoice(s.data, startPos, end, tr)
        addVoice(v, tr.id)
        clipVoices.add(v)
    }

    private fun startOverlapping(pos: Int) {
        val sps = SR * 60.0 / bpm / 4.0
        for (c in clips) {
            if (c.file == null) continue
            val len = clipSteps(c)
            if (c.start < pos && pos < c.start + len) startClip(c, ((pos - c.start) * sps).toInt())
        }
    }

    private fun addVoice(v: Voice, bus: Int) {
        v.bus = bus
        if (voices.size > 64) voices.firstOrNull { it !is ClipVoice }?.finished = true
        voices.add(v)
    }

    fun playVoice(v: Voice) = addVoice(v, -1)

    fun hitDrum(row: Int) = addVoice(DrumVoice(row, rowVol[row], kit), -1)

    fun noteOn(kind: Int, midi: Int): Voice {
        val v = NoteVoice(kind, midi, pitchSemi.toDouble())
        addVoice(v, -1)
        return v
    }

    fun previewHold(kind: Int, midi: Int, ms: Long) {
        val v = noteOn(kind, midi)
        main.postDelayed({ v.release() }, ms)
    }

    fun preview(kind: Int, midi: Int) = previewHold(kind, midi, 300)

    /** Projeyi çevrimdışı çalar ve ana çıkışı döndürür (44.1 kHz mono). Arka plan iş parçacığında çağır. */
    fun renderSong(onProgress: (Float) -> Unit): ShortArray? = renderOffline(false, onProgress)

    /** Aynı çıktı, ancak sol/sağ ayrı (iç içe, stereo) */
    fun renderSongStereo(onProgress: (Float) -> Unit): ShortArray? = renderOffline(true, onProgress)

    private fun renderOffline(stereo: Boolean, onProgress: (Float) -> Unit): ShortArray? {
        exporting = true
        val savedLoop = loopOn
        val savedMetro = metronome
        var waited = 0
        while (!exportAck && running && waited < 200) { Thread.sleep(10); waited++ }
        try {
            playing = false
            voices.clear(); held.clear(); clipVoices.clear()
            wasPlaying = false
            loopOn = false; metronome = false
            songMode = true; songStep = 0; seekRequest = -1
            val endSteps = max(16, clips.maxOfOrNull { it.start + clipSteps(it) } ?: 0)
            val sps = SR * 60.0 / bpm / 4.0
            val total = (endSteps * sps).toLong() + SR * 2L
            if (total > SR * 1800L) return null
            val frames = total.toInt()
            val out = ShortArray(frames * (if (stereo) 2 else 1))
            val chunk = ShortArray(256)
            val offSt = ShortArray(512)
            playing = true
            var pos = 0
            while (pos < frames) {
                renderChunk(chunk, false, if (stereo) offSt else null)
                val n = min(256, frames - pos)
                if (stereo) System.arraycopy(offSt, 0, out, pos * 2, n * 2) else System.arraycopy(chunk, 0, out, pos, n)
                pos += n
                if ((pos and 0x3FFF) < 256) onProgress(pos / frames.toFloat())
            }
            return out
        } finally {
            loopOn = savedLoop; metronome = savedMetro
            playing = false
            voices.clear(); held.clear(); clipVoices.clear()
            wasPlaying = false
            acc = 0.0
            songStep = 0
            exporting = false
        }
    }
}
