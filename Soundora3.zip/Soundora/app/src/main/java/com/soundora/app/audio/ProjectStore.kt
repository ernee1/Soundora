package com.soundora.app.audio

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ProjectStore {
    class Info(val id: String, val name: String, val modified: Long)

    var currentId: String = ""
    var currentName: String = "Proje 1"

    private fun dir(ctx: Context): File = File(ctx.filesDir, "projects").apply { mkdirs() }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("soundora", Context.MODE_PRIVATE)

    // ---------- Düzenleme (tracks + clips) ----------
    fun arrangementJson(): JSONObject {
        val e = AudioEngine
        val a = JSONObject()
        val ts = JSONArray()
        for (t in e.tracks) {
            ts.put(
                JSONObject().put("id", t.id).put("name", t.name).put("type", t.type)
                    .put("vol", t.vol.toDouble()).put("mute", t.mute).put("solo", t.solo).put("hidden", t.hidden)
            )
        }
        val cs = JSONArray()
        for (c in e.clips) {
            cs.put(
                JSONObject().put("track", c.track).put("start", c.start).put("len", c.lenSteps)
                    .put("phase", c.phase).put("file", c.file ?: "").put("offS", c.offS).put("lenS", c.lenS)
            )
        }
        a.put("tracks", ts).put("clips", cs)
        a.put("loopOn", e.loopOn).put("loopStart", e.loopStart).put("loopEnd", e.loopEnd)
        a.put("metronome", e.metronome)
        return a
    }

    fun applyArrangement(a: JSONObject) {
        val e = AudioEngine
        e.tracks.clear()
        e.clips.clear()
        val ts = a.optJSONArray("tracks")
        if (ts != null) for (i in 0 until ts.length()) {
            val t = ts.getJSONObject(i)
            e.tracks.add(
                Track(
                    t.getInt("id"), t.getString("name"), t.getInt("type"),
                    t.optDouble("vol", 0.9).toFloat(), t.optBoolean("mute"), t.optBoolean("solo"), t.optBoolean("hidden")
                )
            )
        }
        val cs = a.optJSONArray("clips")
        if (cs != null) for (i in 0 until cs.length()) {
            val c = cs.getJSONObject(i)
            val f = c.optString("file", "")
            e.clips.add(
                Clip(
                    c.getInt("track"), c.getInt("start"), c.optInt("len"), c.optInt("phase"),
                    if (f.isEmpty()) null else f, c.optInt("offS"), c.optInt("lenS")
                )
            )
        }
        e.nextTrackId = (e.tracks.maxOfOrNull { it.id } ?: 0) + 1
        e.loopOn = a.optBoolean("loopOn")
        e.loopStart = a.optInt("loopStart")
        e.loopEnd = a.optInt("loopEnd", 16)
        e.metronome = a.optBoolean("metronome")
        e.refreshSolo()
    }

    // ---------- Proje ----------
    fun toJson(): JSONObject {
        val e = AudioEngine
        val o = JSONObject()
        o.put("name", currentName)
        o.put("modified", System.currentTimeMillis())
        o.put("pat", PatternStore.encode())
        o.put("melodyKind", e.melodyKind)
        o.put("rowVol", JSONArray(e.rowVol.map { it.toDouble() }))
        o.put("rowMute", JSONArray(e.rowMute.toList()))
        o.put("rowSolo", JSONArray(e.rowSolo.toList()))
        o.put("instVol", JSONArray(e.instVol.map { it.toDouble() }))
        val ad = JSONArray()
        for (a in e.adsr) ad.put(JSONArray(a.map { it.toDouble() }))
        o.put("adsr", ad)
        o.put("arr", arrangementJson())
        return o
    }

    fun fromJson(o: JSONObject) {
        val e = AudioEngine
        e.resetProject()
        PatternStore.decode(o.optString("pat"))
        e.melodyKind = o.optInt("melodyKind", 0)
        val rv = o.optJSONArray("rowVol")
        if (rv != null) for (i in 0 until minOf(rv.length(), AudioEngine.ROWS)) e.rowVol[i] = rv.optDouble(i, 0.8).toFloat()
        val rm = o.optJSONArray("rowMute")
        if (rm != null) for (i in 0 until minOf(rm.length(), AudioEngine.ROWS)) e.rowMute[i] = rm.optBoolean(i)
        val rs = o.optJSONArray("rowSolo")
        if (rs != null) for (i in 0 until minOf(rs.length(), AudioEngine.ROWS)) e.rowSolo[i] = rs.optBoolean(i)
        val iv = o.optJSONArray("instVol")
        if (iv != null) for (i in 0 until minOf(iv.length(), AudioEngine.KINDS)) e.instVol[i] = iv.optDouble(i, 0.8).toFloat()
        val ad = o.optJSONArray("adsr")
        if (ad != null) for (i in 0 until minOf(ad.length(), AudioEngine.KINDS)) {
            val row = ad.getJSONArray(i)
            if (row.length() == 4) e.adsr[i] = floatArrayOf(
                row.getDouble(0).toFloat(), row.getDouble(1).toFloat(), row.getDouble(2).toFloat(), row.getDouble(3).toFloat()
            )
        }
        val arr = o.optJSONObject("arr")
        if (arr != null) applyArrangement(arr)
    }

    fun save(ctx: Context) {
        if (currentId.isEmpty()) return
        try {
            val d = dir(ctx)
            val tmp = File(d, "$currentId.tmp")
            tmp.writeText(toJson().toString())
            tmp.renameTo(File(d, "$currentId.json"))
        } catch (ex: Exception) {
            // kaydetme hatası kullanıcıyı durdurmasın
        }
    }

    fun list(ctx: Context): List<Info> {
        val files = dir(ctx).listFiles { f -> f.extension == "json" } ?: return emptyList()
        val out = ArrayList<Info>()
        for (f in files) {
            try {
                val o = JSONObject(f.readText())
                out.add(Info(f.nameWithoutExtension, o.optString("name", "Proje"), o.optLong("modified", f.lastModified())))
            } catch (ex: Exception) {
            }
        }
        return out.sortedByDescending { it.modified }
    }

    fun openId(ctx: Context, id: String): Boolean {
        return try {
            val o = JSONObject(File(dir(ctx), "$id.json").readText())
            fromJson(o)
            currentId = id
            currentName = o.optString("name", "Proje")
            prefs(ctx).edit().putString("last_project", id).apply()
            History.clear()
            Thread {
                for (c in AudioEngine.clips.toList()) c.file?.let { SampleStore.get(it) }
            }.start()
            true
        } catch (ex: Exception) {
            false
        }
    }

    fun create(ctx: Context, name: String) {
        AudioEngine.resetProject()
        currentId = "p${System.currentTimeMillis()}"
        currentName = name
        History.clear()
        save(ctx)
        prefs(ctx).edit().putString("last_project", currentId).apply()
    }

    fun init(ctx: Context) {
        val last = prefs(ctx).getString("last_project", null)
        var ok = false
        if (last != null) ok = openId(ctx, last)
        if (!ok) {
            val l = list(ctx)
            ok = l.isNotEmpty() && openId(ctx, l[0].id)
        }
        if (!ok) create(ctx, "Proje 1")
    }

    fun duplicate(ctx: Context, id: String, newName: String) {
        val o = JSONObject(File(dir(ctx), "$id.json").readText())
        o.put("name", newName)
        o.put("modified", System.currentTimeMillis())
        File(dir(ctx), "p${System.currentTimeMillis()}.json").writeText(o.toString())
    }

    fun delete(ctx: Context, id: String) {
        File(dir(ctx), "$id.json").delete()
    }

    fun rename(ctx: Context, id: String, name: String) {
        if (id == currentId) {
            currentName = name
            save(ctx)
        } else {
            val f = File(dir(ctx), "$id.json")
            val o = JSONObject(f.readText())
            o.put("name", name)
            f.writeText(o.toString())
        }
    }

    // ---------- Yedekleme ----------
    fun backupZip(ctx: Context): File {
        save(ctx)
        val out = File(ctx.cacheDir, "Soundora_yedek.zip")
        ZipOutputStream(FileOutputStream(out)).use { zos ->
            for (sub in listOf("projects", "recordings", "audio")) {
                File(ctx.filesDir, sub).listFiles()?.forEach { f ->
                    if (f.isFile) {
                        zos.putNextEntry(ZipEntry("$sub/${f.name}"))
                        f.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
        }
        return out
    }

    fun restoreZip(ctx: Context, uri: Uri): Int {
        var n = 0
        val root = ctx.filesDir.canonicalPath + File.separator
        val ins = ctx.contentResolver.openInputStream(uri) ?: return 0
        ZipInputStream(ins).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val dest = File(ctx.filesDir, entry.name)
                val top = entry.name.substringBefore('/')
                if (!entry.isDirectory && top in setOf("projects", "recordings", "audio") &&
                    dest.canonicalPath.startsWith(root)
                ) {
                    dest.parentFile?.mkdirs()
                    FileOutputStream(dest).use { zis.copyTo(it) }
                    n++
                }
                entry = zis.nextEntry
            }
        }
        return n
    }
}

/** Geri al / ileri al (kanal ve parça düzenlemesi için) */
object History {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()

    private fun snapshot(): String = ProjectStore.arrangementJson().toString()

    fun push() {
        undoStack.addLast(snapshot())
        if (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
    }

    fun clear() { undoStack.clear(); redoStack.clear() }

    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        redoStack.addLast(snapshot())
        ProjectStore.applyArrangement(JSONObject(undoStack.removeLast()))
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        undoStack.addLast(snapshot())
        ProjectStore.applyArrangement(JSONObject(redoStack.removeLast()))
        return true
    }
}
