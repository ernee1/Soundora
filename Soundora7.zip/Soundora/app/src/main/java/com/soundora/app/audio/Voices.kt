package com.soundora.app.audio

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

abstract class Voice {
    @Volatile var finished = false
    @Volatile var bus = -1
    abstract fun render(): Float
    open fun release() {}
}

/** 0 Kick, 1 Snare, 2 Clap, 3 Hi-Hat, 4 Açık Hat, 5 Tom, 6 Rim. kit: 0 Standart, 1 808, 2 Lo-fi, 3 Elektronik */
class DrumVoice(private val type: Int, private val gain: Float, kit: Int) : Voice() {
    private var n = 0
    private var phase = 0.0
    private var prev = 0.0
    private var lp = 0.0
    private val sr = AudioEngine.SR.toDouble()
    private val pf = when (kit) { 1 -> 0.8; 2 -> 0.95; 3 -> 1.3; else -> 1.0 }
    private val dm = when (kit) { 1 -> 0.55; 2 -> 1.2; 3 -> 1.5; else -> 1.0 }
    private val dark = when (kit) { 2 -> 0.75; else -> 0.0 }
    private val hdm = max(dm, 1.0)

    override fun render(): Float {
        val t = n / sr
        n++
        val nz = Random.nextDouble() * 2.0 - 1.0
        val s: Double = when (type) {
            0 -> {
                val f = (45.0 + 120.0 * exp(-t * 28.0)) * pf
                phase += 2 * PI * f / sr
                if (t > 0.45 / dm) finished = true
                sin(phase) * exp(-t * 8.0 * dm) * 1.1
            }
            1 -> {
                phase += 2 * PI * 185.0 * pf / sr
                if (t > 0.3 / dm) finished = true
                sin(phase) * exp(-t * 20.0 * dm) * 0.5 + nz * exp(-t * 18.0 * dm) * 0.6
            }
            2 -> {
                val env = if (t < 0.036) exp(-(t % 0.012) * 300.0) else exp(-(t - 0.036) * 25.0 * dm)
                if (t > 0.3) finished = true
                nz * env * 0.7
            }
            3 -> {
                val hp = nz - prev; prev = nz
                if (t > 0.07) finished = true
                hp * exp(-t * 70.0 * hdm) * 0.5
            }
            4 -> {
                val hp = nz - prev; prev = nz
                if (t > 0.35) finished = true
                hp * exp(-t * 10.0 * hdm) * 0.45
            }
            5 -> {
                val f = (100.0 + 80.0 * exp(-t * 15.0)) * pf
                phase += 2 * PI * f / sr
                if (t > 0.5 / dm) finished = true
                sin(phase) * exp(-t * 7.0 * dm) * 0.9
            }
            else -> {
                phase += 2 * PI * 800.0 * pf / sr
                if (t > 0.08) finished = true
                sin(phase) * exp(-t * 90.0) * 0.6 + nz * exp(-t * 120.0) * 0.3
            }
        }
        var out = s * gain
        if (dark > 0.0) { lp += (1.0 - dark) * (out - lp); out = lp }
        return out.toFloat()
    }
}

/**
 * kind: 0 Piyano, 1 Lead Synth, 2 Bas Gitar, 3 Akustik, 4 Elektro,
 * 5 E.Piyano, 6 Org, 7 Strings, 8 Pad, 9 Pluck, 10 Synth Bas
 */
class NoteVoice(private val kind: Int, midi: Int, pitchSemi: Double, extra: Double = 1.0) : Voice() {
    private val sr = AudioEngine.SR.toDouble()
    private val freq = 440.0 * 2.0.pow((midi - 69 + pitchSemi) / 12.0)
    private val ad = AudioEngine.adsr[kind].copyOf()
    private val vol = AudioEngine.instVol[kind].toDouble() * extra
    private var n = 0
    private var phase = 0.0
    private var ph2 = 0.0
    private var ph3 = 0.0
    private var lp = 0.0
    private var released = false
    private var rel = 1.0
    private val ks: FloatArray?
    private var ksI = 0
    private val ksDamp = if (kind == 9) 0.985f else 0.996f

    init {
        ks = if (kind == 3 || kind == 4 || kind == 9) {
            val len = max(2, (sr / freq).toInt())
            FloatArray(len) { Random.nextFloat() * 2f - 1f }
        } else null
    }

    override fun release() { released = true }

    private fun wrap(x: Double): Double = if (x >= 1.0) x - 1.0 else x

    override fun render(): Float {
        val t = n / sr
        n++
        if (released) {
            rel -= 1.0 / (max(0.01, ad[3].toDouble()) * sr)
            if (rel <= 0.0) { finished = true; return 0f }
        }
        if (t > 40.0) finished = true
        val a = max(0.001, ad[0].toDouble())
        val d = max(0.01, ad[1].toDouble())
        val sus = ad[2].toDouble()
        val env = if (t < a) t / a else if (t < a + d) 1.0 - (1.0 - sus) * ((t - a) / d) else sus
        val w = 2 * PI * freq / sr
        val s: Double = when (kind) {
            0 -> {
                phase += w
                if (t > 6.0) finished = true
                (sin(phase) + 0.5 * sin(2 * phase) + 0.25 * sin(3 * phase) + 0.12 * sin(4 * phase)) * exp(-t * 2.2) * 0.35
            }
            1 -> {
                phase = wrap(phase + freq / sr)
                ph2 = wrap(ph2 + freq * 1.007 / sr)
                val x = (2 * phase - 1) + (2 * ph2 - 1)
                lp += 0.35 * (x - lp)
                lp * 0.28
            }
            2 -> {
                phase += w
                if (t > 4.0) finished = true
                (sin(phase) + 0.4 * sin(2 * phase)) * exp(-t * 1.5) * 0.6
            }
            3, 4, 9 -> {
                val buf = ks!!
                val x = buf[ksI]
                val nx = buf[(ksI + 1) % buf.size]
                buf[ksI] = ksDamp * 0.5f * (x + nx)
                ksI = (ksI + 1) % buf.size
                if (t > 4.0) finished = true
                val xd = x.toDouble()
                if (kind == 4) tanh(xd * 3.0) * 0.4 else if (kind == 9) xd * 0.7 else xd * 0.6
            }
            5 -> {
                phase += w
                if (t > 6.0) finished = true
                sin(phase + 2.0 * exp(-t * 5.0) * sin(phase)) * exp(-t * 1.2) * 0.4
            }
            6 -> {
                phase += w
                (sin(phase) + 0.8 * sin(2 * phase) + 0.6 * sin(3 * phase) + 0.4 * sin(4 * phase) + 0.5 * sin(phase * 0.5)) * 0.2
            }
            7 -> {
                phase = wrap(phase + freq / sr)
                ph2 = wrap(ph2 + freq * 1.005 / sr)
                ph3 = wrap(ph3 + freq * 0.995 / sr)
                val x = (2 * phase - 1) + (2 * ph2 - 1) + (2 * ph3 - 1)
                lp += 0.12 * (x - lp)
                lp * 0.25
            }
            8 -> {
                phase += w
                ph2 += w * 1.004
                (sin(phase) + sin(ph2) + 0.4 * sin(2 * phase) + 0.3 * sin(2 * ph2)) * 0.18
            }
            10 -> {
                phase = wrap(phase + freq / sr)
                ph2 += w * 0.5
                val saw = 2 * phase - 1
                lp += 0.08 * (saw - lp)
                (lp * 0.7 + sin(ph2) * 0.5) * 0.6
            }
            else -> 0.0
        }
        return (s * env * rel * vol).toFloat()
    }
}

/** Ses dosyası parçası (kanal sesi canlı okunur) */
class ClipVoice(
    private val data: ShortArray, startPos: Int, private val end: Int, private val track: Track
) : Voice() {
    private var pos = startPos
    override fun render(): Float {
        if (pos >= end || pos >= data.size) { finished = true; return 0f }
        val g = AudioEngine.gainOf(track)
        val v = data[pos] / 32768f
        pos++
        return v * g
    }
}

/** Metronom tıkı */
class ClickVoice(private val accent: Boolean) : Voice() {
    private var n = 0
    private var phase = 0.0
    override fun render(): Float {
        val t = n / AudioEngine.SR.toDouble()
        n++
        if (t > 0.04) { finished = true; return 0f }
        phase += 2 * PI * (if (accent) 1500.0 else 1000.0) / AudioEngine.SR
        return (sin(phase) * exp(-t * 80.0) * 0.5).toFloat()
    }
}

/** Kütüphane efekt sesleri: 0 Riser, 1 Impact, 2 Laser, 3 Düşen süpürme */
class FxVoice(private val kind: Int) : Voice() {
    private var n = 0
    private var phase = 0.0
    private var lp = 0.0
    private val sr = AudioEngine.SR.toDouble()
    override fun render(): Float {
        val t = n / sr
        n++
        val nz = Random.nextDouble() * 2.0 - 1.0
        val s: Double = when (kind) {
            0 -> {
                if (t > 3.0) finished = true
                val k = t / 3.0
                lp += (0.02 + 0.5 * k * k) * (nz - lp)
                lp * (0.1 + 0.9 * k) * 1.5
            }
            1 -> {
                if (t > 2.0) finished = true
                phase += 2 * PI * (40.0 + 80.0 * exp(-t * 10.0)) / sr
                sin(phase) * exp(-t * 3.0) + nz * exp(-t * 8.0) * 0.4
            }
            2 -> {
                if (t > 0.6) finished = true
                phase += 2 * PI * (2000.0 * exp(-t * 6.0) + 150.0) / sr
                sin(phase) * exp(-t * 3.5) * 0.6
            }
            else -> {
                if (t > 3.0) finished = true
                val k = 1.0 - t / 3.0
                lp += (0.02 + 0.5 * k * k) * (nz - lp)
                lp * (0.1 + 0.9 * k) * 1.5
            }
        }
        return (s * 0.8).toFloat()
    }
}
