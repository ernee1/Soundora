package com.soundora.app.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Fft
import com.soundora.app.audio.Meter
import com.soundora.app.audio.dbOf
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

private const val BINS = 96
private const val F_LO = 30.0
private const val F_HI = 16000.0

private fun binFreq(i: Double): Double = F_LO * (F_HI / F_LO).pow(i / BINS)

@Composable
fun MeterScreen() {
    val e = AudioEngine
    var tick by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(e.playing) }
    var peakHz by remember { mutableIntStateOf(0) }
    val spec = remember { FloatArray(BINS) { -90f } }
    val zone = remember { FloatArray(3) { -90f } }
    val buf = remember { FloatArray(Fft.N) }
    val mags = remember { FloatArray(Fft.N / 2) }
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }

    LaunchedEffect(Unit) {
        val hz = AudioEngine.SR.toDouble() / Fft.N
        val norm = Fft.N / 4.0
        while (true) {
            Meter.copyRing(buf)
            Fft.magnitudes(buf, mags)
            for (i in 0 until BINS) {
                val k0 = binFreq(i.toDouble()) / hz
                val k1 = binFreq(i + 1.0) / hz
                val a = floor(k0).toInt().coerceIn(1, mags.size - 1)
                val b = max(ceil(k1).toInt(), a + 1).coerceIn(a + 1, mags.size)
                var m = 0f
                for (k in a until b) if (mags[k] > m) m = mags[k]
                val db = (20.0 * log10(m / norm + 1e-6)).toFloat().coerceIn(-90f, 0f)
                spec[i] = max(db, spec[i] - 3f)
            }
            val sums = DoubleArray(3)
            val cnt = IntArray(3)
            var best = 0f
            var bestK = 0
            for (k in 1 until mags.size) {
                val f = k * hz
                val z = if (f < 250.0) 0 else if (f < 4000.0) 1 else 2
                val v = mags[k] / norm
                sums[z] += v * v
                cnt[z]++
                if (mags[k] > best) { best = mags[k]; bestK = k }
            }
            for (z in 0 until 3) {
                val rms = if (cnt[z] > 0) sqrt(sums[z] / cnt[z]) else 0.0
                zone[z] = (20.0 * log10(rms * 8.0 + 1e-6)).toFloat().coerceIn(-90f, 0f)
            }
            peakHz = if (20.0 * log10(best / norm + 1e-6) > -60.0) (bestK * hz).toInt() else 0
            playing = e.playing
            tick++
            delay(50)
        }
    }
    @Suppress("UNUSED_VARIABLE") val subscribe = tick

    val mom = Meter.momentary
    val sht = Meter.shortTerm
    val integ = Meter.integrated()
    val zoneNames = listOf("Bass (<250 Hz)", "Mid (250 Hz–4 kHz)", "Treble (>4 kHz)")
    val zoneCols = listOf(Color(0xFFEC4899), Purple, Color(0xFF22D3EE))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Ölçüm ve Spectrum", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable { e.playing = !e.playing },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 20.sp, color = Color.White) }
            Text("Master çıkışı gerçek zamanlı analiz edilir. Çalmayı başlat.", fontSize = 11.sp, color = Color(0xFF9CA3AF), modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(8.dp))
        if (Meter.isClipping()) {
            Text("⚠ KIRPILMA (clipping) algılandı! Master veya kanal sesini düşür.", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
        }

        // ---- Spectrum
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
            Row {
                Text("Spectrum Analyzer", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (peakHz > 0) "Baskın: $peakHz Hz" else "Baskın: —", fontSize = 12.sp, color = Color(0xFF9CA3AF))
            }
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 6.dp)) {
                @Suppress("UNUSED_VARIABLE") val sub = tick
                val w = size.width
                val h = size.height - 16.dp.toPx()
                val bw = w / BINS
                for (i in 0 until BINS) {
                    val fc = binFreq(i + 0.5)
                    val col = if (fc < 250.0) zoneCols[0] else if (fc < 4000.0) zoneCols[1] else zoneCols[2]
                    val bh = ((spec[i] + 90f) / 90f).coerceIn(0f, 1f) * h
                    drawRect(col, Offset(i * bw + 0.5f, h - bh), Size(bw - 1f, bh))
                }
                drawIntoCanvas { cv ->
                    paint.textSize = 10.sp.toPx()
                    paint.color = 0xFF9CA3AF.toInt()
                    for ((f, label) in listOf(50.0 to "50", 100.0 to "100", 500.0 to "500", 1000.0 to "1k", 5000.0 to "5k", 10000.0 to "10k Hz")) {
                        val x = (ln(f / F_LO) / ln(F_HI / F_LO)).toFloat() * w
                        cv.nativeCanvas.drawText(label, x, size.height - 2f, paint)
                        drawLine(Color.White.copy(alpha = 0.12f), Offset(x, 0f), Offset(x, h), 1f)
                    }
                }
            }
            Text("dBFS: üst = 0 dB, alt = −90 dB", fontSize = 10.sp, color = Color(0xFF6B7280))
        }

        // ---- Bass / Mid / Treble
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
            Text("Frekans bölgeleri", fontWeight = FontWeight.Bold)
            for (z in 0 until 3) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(zoneNames[z], fontSize = 11.sp, modifier = Modifier.width(122.dp))
                    Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF232C52))) {
                        Box(Modifier.fillMaxWidth(((zone[z] + 70f) / 70f).coerceIn(0f, 1f)).fillMaxHeight().background(zoneCols[z]))
                    }
                    Text(String.format("%.0f dB", zone[z]), fontSize = 11.sp, modifier = Modifier.width(52.dp))
                }
            }
        }

        // ---- Loudness
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
            Row {
                Text("Loudness Meter", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { Meter.reset() }) { Text("Sıfırla") }
            }
            val ok = integ > -16.0 && integ < -12.0
            Text(String.format("Anlık (M): %.1f LUFS", mom))
            Text(String.format("Kısa süreli (S): %.1f LUFS", sht))
            Text(
                String.format("Bütünleşik (I): %.1f LUFS", integ),
                color = if (integ <= -69.0) Color(0xFF9CA3AF) else if (ok) Color(0xFF22C55E) else Color(0xFFF59E0B)
            )
            Text("Yayın hedefi yaklaşık −14 LUFS (yeşil: −16…−12). Ölçüm yaklaşıktır (K-ağırlıklı, BS.1770 benzeri).", fontSize = 10.sp, color = Color(0xFF6B7280))
            Spacer(Modifier.height(6.dp))
            Text(String.format("Peak L: %.1f dBFS   R: %.1f dBFS", dbOf(Meter.peakL), dbOf(Meter.peakR)))
            Text(String.format("Maks. peak: %.1f dBFS", dbOf(Meter.maxPeak)))
            Text(String.format("RMS: %.1f dB", Meter.rmsDb))
            Text(String.format("Master ses seviyesi: %.1f dB", 20 * log10(e.masterVol.coerceAtLeast(0.001f))))
        }
        Spacer(Modifier.height(16.dp))
    }
}
