package com.soundora.app.ui

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.ClickVoice
import com.soundora.app.audio.Generator
import com.soundora.app.audio.MusicTheory
import com.soundora.app.audio.Note
import com.soundora.app.audio.Player

private class Melody(val name: String, val notes: List<Int>)
private val melodies = listOf(
    Melody("Twinkle Twinkle (geleneksel)", listOf(60, 60, 67, 67, 69, 69, 67, 65, 65, 64, 64, 62, 62, 60)),
    Melody("Neşeye Övgü (Beethoven)", listOf(64, 64, 65, 67, 67, 65, 64, 62, 60, 60, 62, 64, 64, 62, 62)),
    Melody("Für Elise girişi (Beethoven)", listOf(76, 75, 76, 75, 76, 71, 74, 72, 69))
)

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (open) "▲" else "▼")
        }
        if (open) content()
    }
}

@Composable
private fun Info(t: String) { Text(t, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp)) }

@Composable
fun LearnScreen() {
    val e = AudioEngine
    val h = remember { Handler(Looper.getMainLooper()) }
    val names = MusicTheory.noteNames
    var bpmDemo by remember { mutableIntStateOf(90) }
    var scRoot by remember { mutableIntStateOf(0) }
    var scIdx by remember { mutableIntStateOf(1) }
    var chRoot by remember { mutableIntStateOf(0) }
    var chIdx by remember { mutableIntStateOf(0) }
    var keyRoot by remember { mutableIntStateOf(0) }
    var minor by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    // piyano dersi
    var lesson by remember { mutableIntStateOf(0) }
    var pos by remember { mutableIntStateOf(0) }
    var lessonMsg by remember { mutableStateOf("") }
    val lessons = listOf(
        "C Majör gamı" to listOf(60, 62, 64, 65, 67, 69, 71, 72),
        "Do-Re-Mi-Fa-Sol" to listOf(60, 62, 64, 65, 67),
        "Twinkle Twinkle (ilk cümle)" to listOf(60, 60, 67, 67, 69, 69, 67)
    )
    val whites = listOf(60, 62, 64, 65, 67, 69, 71, 72)
    val whiteNames = listOf("Do", "Re", "Mi", "Fa", "Sol", "La", "Si", "Do")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Müzik Öğren", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Başlıkları açmak için dokun. Çal tuşları gerçek sesi çıkarır.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Purple)

        Section("BPM nedir?") {
            Info("BPM (dakikadaki vuruş sayısı) müziğin hızıdır. 60 BPM saniyede 1 vuruş, 120 BPM saniyede 2 vuruştur. Pop genelde 100-120, hip-hop 80-95, elektronik 120-130, trap 130-150 BPM çalışır.")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$bpmDemo BPM", Modifier.width(80.dp), fontWeight = FontWeight.Bold)
                Slider(value = bpmDemo.toFloat(), onValueChange = { bpmDemo = it.toInt() }, valueRange = 50f..180f, modifier = Modifier.weight(1f))
            }
            Button(onClick = {
                for (i in 0 until 8) h.postDelayed({ AudioEngine.playVoice(ClickVoice(i % 4 == 0)) }, i * 60000L / bpmDemo)
            }) { Text("▶ 8 vuruş dinle") }
        }

        Section("Nota isimleri") {
            Info("Müzikte 12 nota vardır: Do (C), Do# (C#), Re (D), Re# (D#), Mi (E), Fa (F), Fa# (F#), Sol (G), Sol# (G#), La (A), La# (A#), Si (B). Sonra tekrar Do gelir; bu mesafeye oktav denir.")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                names.forEachIndexed { i, n -> AssistChip(onClick = { e.previewHold(0, 60 + i, 600) }, label = { Text(n) }) }
            }
        }

        Section("Gam kütüphanesi") {
            Info("Gam, birbiriyle uyumlu notaların dizisidir. Majör neşeli, minör hüzünlü duyulur. Piano Roll'da Scale Lock ile sadece gam içindeki notaları çalabilirsin.")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                names.forEachIndexed { i, n -> FilterChip(selected = scRoot == i, onClick = { scRoot = i }, label = { Text(n) }) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MusicTheory.scales.forEachIndexed { i, s -> FilterChip(selected = scIdx == i, onClick = { scIdx = i }, label = { Text(s.first) }) }
            }
            val sc = MusicTheory.scales[scIdx].second
            val midis = sc.map { 60 + scRoot + it } + listOf(72 + scRoot)
            Text(midis.joinToString(" ") { names[it % 12] }, fontWeight = FontWeight.Bold)
            Button(onClick = { Player.noteSeq(0, midis) }) { Text("▶ Çal") }
        }

        Section("Akor kütüphanesi") {
            Info("Akor, aynı anda çalınan 3 veya daha fazla nottur. Majör akor parlak, minör akor kederli, 7'li akorlar daha zengin duyulur.")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                names.forEachIndexed { i, n -> FilterChip(selected = chRoot == i, onClick = { chRoot = i }, label = { Text(n) }) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MusicTheory.chords.forEachIndexed { i, c -> FilterChip(selected = chIdx == i, onClick = { chIdx = i }, label = { Text(c.first) }) }
            }
            val notes = MusicTheory.chords[chIdx].second.map { 60 + chRoot + it }
            Text(names[chRoot] + " " + MusicTheory.chords[chIdx].first + ": " + notes.joinToString(" ") { names[it % 12] }, fontWeight = FontWeight.Bold)
            Button(onClick = { Player.chord(0, notes) }) { Text("▶ Çal") }
        }

        Section("Akor önerileri") {
            Info("Bir tonun akorları birbiriyle uyumludur. Ton seç, akorlara dokunup dinle. Popüler ilerlemeleri Piano Roll'a yazabilirsin.")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                names.forEachIndexed { i, n -> FilterChip(selected = keyRoot == i, onClick = { keyRoot = i }, label = { Text(n) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = !minor, onClick = { minor = false }, label = { Text("Majör") })
                FilterChip(selected = minor, onClick = { minor = true }, label = { Text("Minör") })
            }
            val dia = MusicTheory.diatonic(minor)
            fun cName(d: Int): String {
                val off = dia[d].second[0]
                return names[(off + keyRoot) % 12] + dia[d].first.removePrefix(names[off % 12])
            }
            fun cNotes(d: Int): List<Int> = dia[d].second.map { 60 + keyRoot + it }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (d in 0 until 7) AssistChip(onClick = { Player.chord(0, cNotes(d)) }, label = { Text(cName(d)) })
            }
            MusicTheory.progressions.forEach { p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.first + "  " + p.second.joinToString(" ") { cName(it) }, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { Player.chordSeq(0, p.second.map { cNotes(it) }) }) { Text("▶") }
                    TextButton(onClick = {
                        Generator.progressionToRoll(keyRoot, minor, p.second, 0)
                        msg = "İlerleme Piano Roll'a yazıldı (Studio > Roll)."
                    }) { Text("Roll'a yaz") }
                }
            }
        }

        Section("Ritim örnekleri (davul)") {
            Info("Her türün kendine has ritmi vardır. 'Dinle' ritmi Beat Maker'a yazar ve çalar (mevcut ritmin değişir). Beat sekmesinden düzenleyebilirsin.")
            Generator.genres.forEach { g ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${g.name}  (${(g.bpmLo + g.bpmHi) / 2} BPM)", Modifier.weight(1f))
                    TextButton(onClick = {
                        Generator.setRows(g.rows); e.bpm = (g.bpmLo + g.bpmHi) / 2; e.kit = g.kit
                        e.songMode = false; e.playing = true
                    }) { Text("▶ Dinle") }
                }
            }
            OutlinedButton(onClick = { e.playing = false }) { Text("■ Durdur") }
        }

        Section("Hazır melodi örnekleri") {
            Info("Tanınmış kısa melodiler (telifsiz). Çal ya da Piano Roll'a yaz, sonra kendine göre değiştir.")
            melodies.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.name, Modifier.weight(1f), fontSize = 13.sp)
                    TextButton(onClick = { Player.noteSeq(0, m.notes, 320) }) { Text("▶") }
                    TextButton(onClick = {
                        e.melody.clear()
                        m.notes.forEachIndexed { i, n -> e.melody.add(Note(i * 2, 2, n)) }
                        e.steps = if (m.notes.size * 2 <= 32) 32 else 64
                        e.melodyKind = 0
                        msg = "Melodi Piano Roll'a yazıldı."
                    }) { Text("Roll'a yaz") }
                }
            }
        }

        Section("Sanal piyano dersi") {
            Info("Mor renkli tuşa bas. Doğru basarsan sıradaki nota işaretlenir.")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                lessons.forEachIndexed { i, l ->
                    FilterChip(selected = lesson == i, onClick = { lesson = i; pos = 0; lessonMsg = "" }, label = { Text(l.first) })
                }
            }
            val seq = lessons[lesson].second
            val next = if (pos < seq.size) seq[pos] else -1
            Text("Sıradaki nota: " + (if (next >= 0) whiteNames[whites.indexOf(next)] else "—") + "   (${pos}/${seq.size})", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                whites.forEachIndexed { i, m ->
                    val isNext = m == next
                    Box(
                        Modifier.weight(1f).height(120.dp)
                            .background(if (isNext) Purple else Color.White, RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                            .clickable {
                                e.previewHold(0, m, 500)
                                if (m == next) {
                                    pos++
                                    lessonMsg = if (pos >= seq.size) "Aferin! Ders bitti 🎉 (başa dönmek için dersi seç)" else ""
                                } else if (next >= 0) lessonMsg = "Bu ${whiteNames[i]}. Mor tuşa bas."
                            },
                        contentAlignment = Alignment.BottomCenter
                    ) { Text(whiteNames[i], color = if (isNext) Color.White else Color.Black, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp)) }
                }
            }
            if (lessonMsg.isNotEmpty()) Text(lessonMsg, color = Purple, fontSize = 13.sp)
            OutlinedButton(onClick = { pos = 0; lessonMsg = "" }) { Text("Baştan başla") }
        }

        Section("Beat nasıl yapılır? / Vokal kaydı / Düzenleme") {
            Info("1) Studio > Beat: kareleri aç/kapat. Kick (bas davul) 1. ve 3. vuruşa, Snare 2. ve 4. vuruşa, Hi-Hat her yarım vuruşa konur.")
            Info("2) Studio > Roll: akor veya melodi ekle; Scale Lock ile yanlış nota çalmazsın.")
            Info("3) Studio > Kayıt: mikrofon iznini ver, kulaklık takarsan geri besleme olmaz. Kaydı Timeline'a ekle.")
            Info("4) Studio > Timeline: parçaları taşı, böl, kopyala; kanal efektlerini seç; Projeler'den dışa aktar.")
        }
        Spacer(Modifier.height(16.dp))
    }
}
