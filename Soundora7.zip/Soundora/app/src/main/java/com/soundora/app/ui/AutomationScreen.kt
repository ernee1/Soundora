package com.soundora.app.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.AutoDefs
import com.soundora.app.audio.AutoLane
import com.soundora.app.audio.AutoPoint
import com.soundora.app.audio.History
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun AutomationScreen() {
    val e = AudioEngine
    var ver by remember { mutableIntStateOf(0) }
    var selTrack by remember { mutableIntStateOf(e.tracks.firstOrNull()?.id ?: 0) }
    var laneIdx by remember { mutableIntStateOf(0) }
    var vis by remember { mutableIntStateOf(64) }
    var first by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<AutoPoint?>(null) }
    var pos by remember { mutableIntStateOf(e.songStep) }
    var playing by remember { mutableStateOf(e.playing && e.songMode) }
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }

    LaunchedEffect(Unit) {
        while (true) {
            playing = e.playing && e.songMode
            if (playing) {
                pos = e.songStep
                if (pos < first || pos >= first + vis) first = pos
            }
            delay(40)
        }
    }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver

    val tr = e.trackById(selTrack) ?: e.tracks.firstOrNull()
    val lane: AutoLane? = tr?.auto?.get(laneIdx)
    val endMax = e.clips.maxOfOrNull { it.start + e.clipSteps(it) } ?: 0
    val songLen = (((endMax + 15) / 16) * 16 + 64).coerceAtLeast(128)
    val maxFirst = (songLen - vis).coerceAtLeast(0)
    val f0 = first.coerceIn(0, maxFirst)

    fun nearest(ln: AutoLane, x: Float, y: Float, cw: Float, rulerPx: Float, plotH: Float, rad: Float): AutoPoint? {
        var best: AutoPoint? = null
        var bd = rad * rad
        for (p in ln.pts) {
            val dx = (p.t - f0) * cw - x
            val dy = rulerPx + (1f - p.v) * plotH - y
            val d = dx * dx + dy * dy
            if (d <= bd) { bd = d; best = p }
        }
        return best
    }
    fun seekTo(step: Int) {
        val s = max(0, step)
        e.songStep = s
        pos = s
        if (e.playing && e.songMode) e.seekRequest = s
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Otomasyon", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Zamana göre ses, pan, reverb, delay ve filter değişimi. Boş yere dokun: nokta ekle. Noktayı sürükle: taşı. Şarkı modunda (Timeline ▶ veya buradaki ▶) uygulanır.",
            fontSize = 11.sp, color = Color(0xFF9CA3AF)
        )
        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { seekTo(if (e.loopOn) e.loopStart else 0) }) { Text("⏮") }
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable {
                        if (playing) e.playing = false
                        else { e.songMode = true; e.songStep = pos; e.playing = true }
                    },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 20.sp, color = Color.White) }
            Text("Bar ${pos / 16 + 1}.${(pos % 16) / 4 + 1}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { if (History.undo()) { sel = null; ver++ } }) { Text("↶") }
            OutlinedButton(onClick = { if (History.redo()) { sel = null; ver++ } }) { Text("↷") }
        }

        Spacer(Modifier.height(6.dp))
        Text("Kanal", fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            e.tracks.toList().forEach { t ->
                FilterChip(selected = t.id == tr?.id, onClick = { selTrack = t.id; sel = null }, label = { Text(t.name) })
            }
        }
        Text("Parametre", fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AutoDefs.names.forEachIndexed { i, n ->
                val has = tr?.auto?.get(i)?.pts?.isNotEmpty() == true
                FilterChip(selected = laneIdx == i, onClick = { laneIdx = i; sel = null }, label = { Text(if (has) "$n •" else n) })
            }
        }

        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(12.dp))
                .pointerInput(listOf(vis, f0, selTrack, laneIdx)) {
                    detectTapGestures(onTap = { off ->
                        val cw = size.width / vis.toFloat()
                        val rulerPx = 20.dp.toPx()
                        val plotH = size.height - rulerPx
                        val ln = lane
                        if (off.y < rulerPx) {
                            seekTo(f0 + (off.x / cw).toInt().coerceIn(0, vis - 1))
                        } else if (ln != null) {
                            val hit = nearest(ln, off.x, off.y, cw, rulerPx, plotH, 24.dp.toPx())
                            if (hit != null) {
                                sel = hit
                            } else {
                                History.push()
                                val np = AutoPoint(
                                    (f0 + off.x / cw).roundToInt().toFloat().coerceAtLeast(0f),
                                    (1f - (off.y - rulerPx) / plotH).coerceIn(0f, 1f)
                                )
                                ln.set(ln.pts + np)
                                sel = np
                            }
                            ver++
                        }
                    })
                }
                .pointerInput(listOf(vis, f0, selTrack, laneIdx)) {
                    var dragP: AutoPoint? = null
                    detectDragGestures(
                        onDragStart = { off ->
                            val cw = size.width / vis.toFloat()
                            val rulerPx = 20.dp.toPx()
                            val plotH = size.height - rulerPx
                            val ln = lane
                            dragP = if (ln != null && off.y >= rulerPx) nearest(ln, off.x, off.y, cw, rulerPx, plotH, 30.dp.toPx()) else null
                            if (dragP != null) { History.push(); sel = dragP }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val p = dragP
                            val ln = lane
                            if (p != null && ln != null) {
                                val cw = size.width / vis.toFloat()
                                val rulerPx = 20.dp.toPx()
                                val plotH = size.height - rulerPx
                                p.t = (f0 + change.position.x / cw).roundToInt().toFloat().coerceAtLeast(0f)
                                p.v = (1f - (change.position.y - rulerPx) / plotH).coerceIn(0f, 1f)
                                ln.set(ln.pts)
                                ver++
                            }
                        },
                        onDragEnd = { dragP = null },
                        onDragCancel = { dragP = null }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val sub = ver
                val p0 = pos
                val rulerPx = 20.dp.toPx()
                val plotH = size.height - rulerPx
                val cw = size.width / vis.toFloat()
                drawRect(Color(0xFF0F1530), Offset.Zero, Size(size.width, rulerPx))
                drawRect(Color(0xFF161D3A), Offset(0f, rulerPx), Size(size.width, plotH))
                for (c in 0..vis) {
                    val idx = f0 + c
                    if (idx % 4 != 0) continue
                    val bar = idx % 16 == 0
                    drawLine(
                        Color.White.copy(alpha = if (bar) 0.3f else 0.08f),
                        Offset(c * cw, if (bar) 0f else rulerPx), Offset(c * cw, size.height), if (bar) 2f else 1f
                    )
                }
                for (g in 0..4) {
                    val y = rulerPx + plotH * g / 4f
                    drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, y), Offset(size.width, y), 1f)
                }
                drawIntoCanvas { cv ->
                    paint.textSize = 10.sp.toPx()
                    paint.color = 0xFF9CA3AF.toInt()
                    for (c in 0..vis) {
                        val idx = f0 + c
                        if (idx % 16 == 0) cv.nativeCanvas.drawText("${idx / 16 + 1}", c * cw + 3f, rulerPx - 6f, paint)
                    }
                    cv.nativeCanvas.drawText(AutoDefs.label(laneIdx, 1f), 6f, rulerPx + 14.sp.toPx(), paint)
                    cv.nativeCanvas.drawText(AutoDefs.label(laneIdx, 0f), 6f, size.height - 6f, paint)
                }
                val ln = lane
                if (ln != null && ln.pts.isNotEmpty()) {
                    val pts = ln.pts
                    val col = if (ln.enabled) Color(0xFF22D3EE) else Color(0xFF6B7280)
                    var px = 0f
                    var py = rulerPx + (1f - pts[0].v) * plotH
                    for (p in pts) {
                        val x = (p.t - f0) * cw
                        val y = rulerPx + (1f - p.v) * plotH
                        drawLine(col, Offset(px, py), Offset(x, y), 4f)
                        px = x
                        py = y
                    }
                    drawLine(col, Offset(px, py), Offset(size.width, py), 4f)
                    for (p in pts) {
                        val c = Offset((p.t - f0) * cw, rulerPx + (1f - p.v) * plotH)
                        drawCircle(col, 7.dp.toPx(), c)
                        if (p === sel) drawCircle(Color.White, 10.dp.toPx(), c, style = Stroke(width = 3f))
                    }
                }
                val x = (p0 - f0) * cw
                if (x >= 0f && x <= size.width) drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 3f)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (vis > 16) vis /= 2 }) { Text("Yakınlaş") }
            OutlinedButton(onClick = { if (vis < 512) vis *= 2 }) { Text("Uzaklaş") }
        }
        if (maxFirst > 0) {
            Slider(value = f0.toFloat(), valueRange = 0f..maxFirst.toFloat(), onValueChange = { first = it.roundToInt() })
        }

        val ln = lane
        if (ln != null) {
            Spacer(Modifier.height(6.dp))
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${tr?.name ?: ""} • ${AutoDefs.names[laneIdx]}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("Açık", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Switch(checked = ln.enabled, onCheckedChange = { ln.enabled = it; ver++ })
                }
                val sp = sel
                if (sp != null && ln.pts.contains(sp)) {
                    Text(
                        "Seçili nokta: bar ${(sp.t / 16).toInt() + 1}.${((sp.t % 16) / 4).toInt() + 1} • ${AutoDefs.label(laneIdx, sp.v)}",
                        fontSize = 12.sp
                    )
                    Slider(value = sp.v, onValueChange = { sp.v = it; ln.set(ln.pts); ver++ })
                } else {
                    Text("Henüz nokta seçilmedi (${ln.pts.size} nokta).", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {
                        val s = sel
                        if (s != null) { History.push(); ln.set(ln.pts - s); sel = null; ver++ }
                    }, label = { Text("Noktayı sil") })
                    AssistChip(onClick = {
                        History.push(); ln.set(emptyList()); sel = null; ver++
                    }, label = { Text("Eğriyi temizle") })
                    AssistChip(onClick = {
                        History.push()
                        val hi = if (laneIdx == 0) AutoDefs.normal(0, 1f) else 1f
                        val t0 = pos.toFloat()
                        ln.set(ln.pts + listOf(AutoPoint(t0, 0f), AutoPoint(t0 + 16f, hi)))
                        ver++
                    }, label = { Text("Rampa ↑ (1 bar)") })
                    AssistChip(onClick = {
                        History.push()
                        val hi = if (laneIdx == 0) AutoDefs.normal(0, 1f) else 1f
                        val t0 = pos.toFloat()
                        ln.set(ln.pts + listOf(AutoPoint(t0, hi), AutoPoint(t0 + 16f, 0f)))
                        ver++
                    }, label = { Text("Rampa ↓ (1 bar)") })
                }
                Text(
                    "İmleci taşımak için cetvele (üst şerit) dokun. Ses: 1.00 = kanal sesi aynen. Filter ve Reverb/Delay otomasyonu efekt kapalı olsa bile çalışır.",
                    fontSize = 10.sp, color = Color(0xFF6B7280)
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
