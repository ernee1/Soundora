package com.soundora.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Generator
import com.soundora.app.audio.MusicTheory
import com.soundora.app.audio.Player
import kotlinx.coroutines.delay
import kotlin.math.sqrt

@Composable
private fun Card2(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text(title, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun Visualizer() {
    val bands = remember { mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f) }
    LaunchedEffect(Unit) {
        while (true) {
            for (i in 0 until 8) bands[i] = AudioEngine.bands[i]
            delay(33)
        }
    }
    Canvas(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFF0B0B12), RoundedCornerShape(12.dp))) {
        val n = 8
        val gap = 8f
        val w = (size.width - gap * (n + 1)) / n
        for (i in 0 until n) {
            val lvl = sqrt(bands[i].toDouble()).coerceAtMost(1.0).toFloat()
            val h = (lvl * size.height * 1.4f).coerceIn(4f, size.height - 8f)
            val x = gap + i * (w + gap)
            drawRoundRect(
                Brush.verticalGradient(listOf(Purple, Blue), startY = size.height - h, endY = size.height),
                Offset(x, size.height - h - 4f), Size(w, h), CornerRadius(10f, 10f)
            )
        }
    }
}

@Composable
fun ToolsScreen() {
    val e = AudioEngine
    var msg by remember { mutableStateOf("") }
    var density by remember { mutableFloatStateOf(0.6f) }
    var genre by remember { mutableIntStateOf(0) }
    var root by remember { mutableIntStateOf(0) }
    var qual by remember { mutableIntStateOf(0) }
    var best by remember { mutableStateOf<List<Triple<Int, Int, Int>>>(emptyList()) }
    var am by remember { mutableStateOf(e.autoMaster) }
    val names = MusicTheory.noteNames

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Akıllı Araçlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Bunlar yapay zekâ değil, müzik kurallarıyla çalışan araçlardır; internet gerekmez.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Purple)

        Card2("Visualizer (çalan müziğe göre)") {
            Visualizer()
            Text("Beat sekmesinden ▶ ile çal, çubuklar sesin bas/tiz dağılımına göre hareket eder.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }

        Card2("Random Beat") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Yoğunluk", fontSize = 12.sp, modifier = Modifier.width(70.dp))
                Slider(value = density, onValueChange = { density = it }, valueRange = 0.2f..1.5f, modifier = Modifier.weight(1f))
            }
            Button(onClick = { Generator.setRows(Generator.randomRows(density)); msg = "Rastgele ritim Beat Maker'a yazıldı." }) { Text("Rastgele ritim üret") }
        }

        Card2("Beat Generator (türe göre)") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Generator.genres.forEachIndexed { i, g -> FilterChip(selected = genre == i, onClick = { genre = i }, label = { Text(g.name) }) }
            }
            val g = Generator.genres[genre]
            Text("Tempo ${g.bpmLo}-${g.bpmHi} BPM, kit: ${AudioEngine.kitNames[g.kit]}", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    Generator.applyTemplate(g)
                    msg = "${g.name} şablonu uygulandı: tempo, ritim ve akorlar (Roll). Mevcut ritim/melodi değişti."
                }) { Text("Şablonu uygula") }
                OutlinedButton(onClick = { Generator.setRows(Generator.variation(g)); msg = "${g.name} için ritim varyasyonu üretildi." }) { Text("Varyasyon") }
            }
        }

        Card2("Chord Assistant") {
            Text("Ana nota", fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                names.forEachIndexed { i, n -> FilterChip(selected = root == i, onClick = { root = i }, label = { Text(n) }) }
            }
            Text("Akor türü", fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MusicTheory.chords.forEachIndexed { i, c -> FilterChip(selected = qual == i, onClick = { qual = i }, label = { Text(c.first) }) }
            }
            val notes = MusicTheory.chords[qual].second.map { 60 + root + it }
            Text(names[root] + " " + MusicTheory.chords[qual].first + ": " + notes.joinToString(" ") { MusicTheory.noteName(it) }, fontWeight = FontWeight.Bold)
            Button(onClick = { Player.chord(e.melodyKind, notes) }) { Text("▶ Çal") }

            val minorKey = qual == 1 || qual == 7
            val dia = MusicTheory.diatonic(minorKey)
            fun chordName(d: Int): String {
                val off = dia[d].second[0]
                val suffix = dia[d].first.removePrefix(names[off % 12])
                return names[(off + root) % 12] + suffix
            }
            fun chordNotes(d: Int): List<Int> = dia[d].second.map { 60 + root + it }
            Text("Bu akora uygun sıradaki akorlar (${names[root]} ${if (minorKey) "minör" else "majör"} tonunda):", fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (MusicTheory.nextDegrees[0] ?: emptyList()).forEach { d ->
                    AssistChip(onClick = { Player.chord(e.melodyKind, chordNotes(d)) }, label = { Text("▶ " + chordName(d)) })
                }
            }
            Text("Tonun tüm akorları:", fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (d in 0 until 7) AssistChip(onClick = { Player.chord(e.melodyKind, chordNotes(d)) }, label = { Text(chordName(d)) })
            }
            Text("Hazır akor ilerlemeleri:", fontSize = 12.sp)
            MusicTheory.progressions.forEach { p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.first + "  (" + p.second.joinToString(" ") { chordName(it) } + ")", fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { Player.chordSeq(e.melodyKind, p.second.map { chordNotes(it) }) }) { Text("▶") }
                    TextButton(onClick = {
                        Generator.progressionToRoll(root, minorKey, p.second, e.melodyKind)
                        msg = "İlerleme Piano Roll'a yazıldı (Roll sekmesi)."
                    }) { Text("Roll'a yaz") }
                }
            }
        }

        Card2("Scale Assistant") {
            Text("Piano Roll'daki melodine en uygun gamları bulur.", fontSize = 12.sp)
            Button(onClick = {
                best = MusicTheory.bestScales()
                msg = if (best.isEmpty()) "Önce Roll sekmesinde nota ekle." else ""
            }) { Text("Melodiye uygun gam öner") }
            best.forEach { (r, si, pct) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${names[r]} ${MusicTheory.scales[si].first}  —  %$pct uyum", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        e.rollRoot = r; e.rollScale = si
                        msg = "Roll'da gam: ${names[r]} ${MusicTheory.scales[si].first}. Scale Lock'u Roll'dan açabilirsin."
                    }) { Text("Uygula") }
                }
            }
        }

        Card2("Auto Mastering") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Çıkışa denge + sıkıştırma + limiter uygula", fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = am, onCheckedChange = { am = it; e.autoMaster = it })
            }
            Text("Çalarken ve dışa aktarırken geçerli. Dışa aktarmada ayrıca ses seviyesi normalize edilebilir.", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }
        Spacer(Modifier.height(16.dp))
    }
}
