package com.soundora.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Clip
import com.soundora.app.audio.Generator
import com.soundora.app.audio.History
import com.soundora.app.audio.Note
import com.soundora.app.audio.ProjectStore
import com.soundora.app.audio.Recorder
import com.soundora.app.audio.SampleStore
import com.soundora.app.audio.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.random.Random

@Composable
private fun EmSection(title: String, hint: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(20.dp)).padding(14.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (hint != null) Text(hint, fontSize = 12.sp, color = Color(0xFF9CA3AF))
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun EmKey(midi: () -> Int, kind: () -> Int, label: String, modifier: Modifier) {
    var down by remember { mutableStateOf(false) }
    Box(
        modifier.padding(1.dp)
            .background(if (down) Color(0xFFC4B5FD) else Color.White, RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    down = true
                    val v = AudioEngine.noteOn(kind(), midi())
                    try { tryAwaitRelease() } finally { v.release(); down = false }
                })
            },
        contentAlignment = Alignment.BottomCenter
    ) { Text(label, color = Color.Black, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)) }
}

private val melodySounds = listOf(0 to "Piyano", 5 to "Elektrik Piyano", 6 to "Org", 7 to "Yaylılar", 8 to "Pad", 1 to "Synth", 9 to "Gitar teli")

private fun lineMelody(minor: Boolean, kind: Int) {
    val e = AudioEngine
    val rnd = Random(System.nanoTime())
    val scale = if (minor) listOf(0, 3, 5, 7, 10) else listOf(0, 2, 4, 7, 9)
    val ladder = IntArray(10) { 60 + 12 * (it / 5) + scale[it % 5] }
    e.melody.clear()
    e.steps = 32
    e.melodyKind = kind
    var idx = 3
    val moves = listOf(-2, -1, 0, 1, 2)
    var s = 0
    while (s < 32) {
        if (s == 0 || rnd.nextFloat() < 0.75f) {
            idx = (idx + moves[rnd.nextInt(5)]).coerceIn(0, 9)
            e.melody.add(Note(s, 2, ladder[idx]))
        }
        s += 2
    }
    e.rollRoot = 0
    e.rollScale = if (minor) 2 else 1
}

@Composable
fun EasyMakeScreen() {
    val e = AudioEngine
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(e.playing) }
    var msg by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var recSecs by remember { mutableIntStateOf(0) }
    var lastRec by remember { mutableStateOf<File?>(null) }
    var showExport by remember { mutableStateOf(false) }
    var oct by remember { mutableIntStateOf(4) }
    var projName by remember { mutableStateOf(ProjectStore.currentName) }
    @Suppress("UNUSED_VARIABLE") val subscribe = ver
    val recState = rememberUpdatedState(recording)

    LaunchedEffect(Unit) { while (true) { playing = e.playing; delay(200) } }
    LaunchedEffect(recording) { recSecs = 0; while (recording) { delay(1000); recSecs++ } }
    SideEffect { view.keepScreenOn = recording }
    DisposableEffect(Unit) { onDispose { if (recState.value) Recorder.stop(); view.keepScreenOn = false } }

    fun ensureClips() {
        for (type in 0..1) {
            val t = e.tracks.firstOrNull { it.type == type } ?: continue
            if (e.clips.none { it.track == t.id }) e.clips.add(Clip(t.id, 0, 64))
        }
        val endAudio = e.clips.filter { it.file != null }.maxOfOrNull { it.start + e.clipSteps(it) } ?: 0
        val len = max(64, ((endAudio + 15) / 16) * 16)
        val ids = e.tracks.filter { it.type == 0 || it.type == 1 }.map { it.id }
        for (c in e.clips) if (c.file == null && ids.contains(c.track)) c.lenSteps = len
        e.loopOn = true
        e.loopStart = 0
        e.loopEnd = len
    }
    fun startPlay() {
        ensureClips()
        e.songMode = true
        e.songStep = 0
        e.playing = true
        playing = true
    }
    fun stopPlay() { e.playing = false; playing = false }
    fun changed() { ver++; if (!e.playing) startPlay() }

    fun startRec() {
        Recorder.start(ctx) { }
        recording = true
        msg = ""
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else msg = "Kayıt için mikrofon izni gerekli."
    }
    fun toggleRec() {
        if (recording) {
            Recorder.stop()
            recording = false
            lastRec = Recorder.list(ctx).firstOrNull()
            msg = "Kayıt bitti. İstersen müziğine ekleyebilirsin."
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRec()
        } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun addRecording(f: File) {
        val rel = "recordings/${f.name}"
        scope.launch {
            val s = withContext(Dispatchers.IO) { SampleStore.get(rel) }
            if (s == null) { msg = "Kayıt okunamadı."; return@launch }
            History.push()
            val tr = e.tracks.firstOrNull { it.type == 2 } ?: Track(e.nextTrackId++, "Ses 1", 2).also { e.tracks.add(it) }
            e.clips.add(Clip(tr.id, 0, 0, 0, rel, 0, s.data.size))
            ensureClips()
            ver++
            msg = "Kaydın müziğine eklendi ✓ (en baştan çalar)."
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Müzik Yap", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Aşağıdan adım adım ilerle. Her değişiklik anında duyulur.", fontSize = 12.sp, color = Color(0xFF9CA3AF))
        Spacer(Modifier.height(6.dp))

        // ---- Çal / Durdur + hız
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(96.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable { if (playing) stopPlay() else startPlay() },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 44.sp, color = Color.White) }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(if (playing) "Çalıyor — durdurmak için dokun" else "Dinlemek için ▶ düğmesine dokun", fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { if (e.bpm > 40) e.bpm -= 5; ver++ }) { Text("−", fontSize = 20.sp) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 10.dp)) {
                        Text("${e.bpm}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Hız (BPM)", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                    }
                    OutlinedButton(onClick = { if (e.bpm < 220) e.bpm += 5; ver++ }) { Text("+", fontSize = 20.sp) }
                }
            }
        }
        Text("BPM = dakikadaki vuruş sayısı. Büyük sayı = hızlı müzik.", fontSize = 11.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(start = 6.dp))

        EmSection("1) Hazır müzik şablonu seç", "Ritim + melodi birlikte gelir. Seçince müzik hemen çalmaya başlar.") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Generator.genres.forEach { g -> AssistChip(onClick = { Generator.applyTemplate(g); changed() }, label = { Text(g.name) }) }
            }
        }
        EmSection("2) İstersen ritmi değiştir", "Sadece davul ritmi değişir.") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Generator.genres.forEach { g ->
                    AssistChip(onClick = { e.bpm = (g.bpmLo + g.bpmHi) / 2; e.kit = g.kit; Generator.setRows(g.rows); changed() }, label = { Text(g.name) })
                }
                AssistChip(onClick = { Generator.setRows(Generator.randomRows(0.6f)); changed() }, label = { Text("🎲 Rastgele") })
            }
        }
        EmSection("3) İstersen melodiyi değiştir", "Sadece melodi/akorlar değişir.") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { Generator.progressionToRoll(0, false, listOf(0, 4, 5, 3), 0); changed() }, label = { Text("Neşeli akorlar") })
                AssistChip(onClick = { Generator.progressionToRoll(0, true, listOf(0, 5, 2, 6), 5); changed() }, label = { Text("Duygusal akorlar") })
                AssistChip(onClick = { Generator.progressionToRoll(0, false, listOf(0, 5, 3, 4), 8); changed() }, label = { Text("Sakin pad") })
                AssistChip(onClick = { Generator.progressionToRoll(0, true, listOf(0, 0, 5, 6), 1); changed() }, label = { Text("Dans synth") })
                AssistChip(onClick = { lineMelody(false, 9); changed() }, label = { Text("Neşeli melodi") })
                AssistChip(onClick = { lineMelody(true, 5); changed() }, label = { Text("Hüzünlü melodi") })
                AssistChip(onClick = { e.melody.clear(); changed() }, label = { Text("Melodisiz") })
            }
        }
        EmSection("4) Melodinin sesini seç") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                melodySounds.forEach { (k, n) ->
                    FilterChip(selected = e.melodyKind == k, onClick = { e.melodyKind = k; ver++; AudioEngine.previewHold(k, 60, 600) }, label = { Text(n) })
                }
            }
        }
        EmSection("5) Davul sesleri", "Dokun: ekle veya çıkar.") {
            val defs = mapOf(0 to "x...x...x...x...", 1 to "....x.......x...", 3 to "x.x.x.x.x.x.x.x.", 2 to "....x.......x...")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "Davul (Kick)", 1 to "Trampet (Snare)", 3 to "Hi-Hat", 2 to "El çırpma").forEach { (r, name) ->
                    val on = e.pattern[r].any { it }
                    FilterChip(selected = on, onClick = {
                        if (on) {
                            for (s in 0 until AudioEngine.MAX_STEPS) e.pattern[r][s] = false
                        } else {
                            val d = defs[r] ?: "................"
                            for (s in 0 until AudioEngine.MAX_STEPS) e.pattern[r][s] = d[s % 16] == 'x'
                            e.hitDrum(r)
                        }
                        changed()
                    }, label = { Text(name) })
                }
            }
        }
        EmSection("6) Piyano çal", "Tuşlara dokun. Basılı tutarsan ses devam eder. Ses: yukarıdaki seçim.") {
            val whites = listOf(0, 2, 4, 5, 7, 9, 11, 12)
            val names = listOf("Do", "Re", "Mi", "Fa", "Sol", "La", "Si", "Do")
            Row(Modifier.fillMaxWidth().height(150.dp)) {
                whites.forEachIndexed { i, semi ->
                    EmKey({ 12 * (oct + 1) + semi }, { e.melodyKind }, names[i], Modifier.weight(1f).fillMaxHeight())
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { if (oct > 2) oct-- }) { Text("Oktav ▼ (kalın)") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { if (oct < 6) oct++ }) { Text("Oktav ▲ (ince)") }
            }
        }
        EmSection("7) Ses kaydet", "Tek dokunuşla kaydet, sonra müziğine ekle.") {
            Button(
                onClick = { toggleRec() },
                colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFFEF4444) else Purple)
            ) { Text(if (recording) "■ Kaydı durdur (${recSecs} sn)" else "● Kayda başla", fontSize = 16.sp) }
            val lr = lastRec
            if (lr != null && !recording) {
                Text("Son kayıt: ${lr.nameWithoutExtension}", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                Button(onClick = { addRecording(lr) }) { Text("Müziğime ekle") }
            }
        }
        EmSection("8) Kaydet ve paylaş") {
            OutlinedTextField(
                value = projName, onValueChange = { projName = it }, singleLine = true,
                label = { Text("Proje adı") }, modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    try {
                        val n = projName.trim().ifEmpty { "Adsız proje" }
                        if (n != ProjectStore.currentName) ProjectStore.rename(ctx, ProjectStore.currentId, n)
                        ensureClips()
                        ProjectStore.save(ctx)
                        msg = "Proje kaydedildi ✓ ($n)"
                    } catch (ex: Exception) { msg = "Kaydedilemedi." }
                }) { Text("💾 Projeyi kaydet") }
                OutlinedButton(onClick = { ensureClips(); showExport = !showExport }) { Text("📤 Dışa aktar") }
            }
            if (showExport) {
                Text("WAV = yüksek kaliteli ses dosyası. Hazır olunca telefona kaydedebilir veya paylaşabilirsin.", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                ExportCard()
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Color(0xFF22C55E), modifier = Modifier.padding(6.dp))
        Spacer(Modifier.height(16.dp))
    }
}
