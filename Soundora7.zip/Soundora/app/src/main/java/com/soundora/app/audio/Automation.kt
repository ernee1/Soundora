package com.soundora.app.audio

import org.json.JSONArray
import kotlin.math.pow

/** Otomasyon noktası: t = şarkı adımı (1 adım = 1/16 nota), v = 0..1 (normalize). */
class AutoPoint(var t: Float, var v: Float)

class AutoLane {
    @Volatile var pts: List<AutoPoint> = emptyList()
    @Volatile var enabled = true
    val active: Boolean get() = enabled && pts.isNotEmpty()

    fun eval(t: Float): Float {
        val p = pts
        if (p.isEmpty()) return 0f
        if (t <= p[0].t) return p[0].v
        val last = p[p.size - 1]
        if (t >= last.t) return last.v
        for (i in 0 until p.size - 1) {
            val a = p[i]
            val b = p[i + 1]
            if (t >= a.t && t <= b.t) {
                val d = b.t - a.t
                return if (d <= 0f) b.v else a.v + (b.v - a.v) * (t - a.t) / d
            }
        }
        return last.v
    }

    fun set(list: List<AutoPoint>) { pts = list.sortedBy { it.t } }

    fun toJson(): JSONArray {
        val a = JSONArray()
        for (p in pts) a.put(JSONArray().put(p.t.toDouble()).put(p.v.toDouble()))
        return a
    }

    fun fromJson(a: JSONArray) {
        val l = ArrayList<AutoPoint>()
        for (i in 0 until a.length()) {
            val q = a.optJSONArray(i) ?: continue
            if (q.length() >= 2) l.add(AutoPoint(q.optDouble(0, 0.0).toFloat(), q.optDouble(1, 0.0).toFloat().coerceIn(0f, 1f)))
        }
        set(l)
    }
}

/** 0 Ses (çarpan), 1 Pan, 2 Reverb karışımı, 3 Delay karışımı, 4 Filter kesim frekansı */
object AutoDefs {
    const val COUNT = 5
    val names = listOf("Ses", "Pan", "Reverb", "Delay", "Filter")
    private val mins = floatArrayOf(0f, -1f, 0f, 0f, 100f)
    private val maxs = floatArrayOf(1.5f, 1f, 1f, 1f, 12000f)

    fun actual(lane: Int, n: Float): Float {
        val x = n.coerceIn(0f, 1f)
        return if (lane == 4) (mins[4] * (maxs[4] / mins[4]).toDouble().pow(x.toDouble())).toFloat()
        else mins[lane] + (maxs[lane] - mins[lane]) * x
    }

    fun normal(lane: Int, a: Float): Float {
        val v = a.coerceIn(mins[lane], maxs[lane])
        return if (lane == 4) (kotlin.math.ln(v / mins[4]) / kotlin.math.ln(maxs[4] / mins[4])).toFloat()
        else (v - mins[lane]) / (maxs[lane] - mins[lane])
    }

    fun label(lane: Int, n: Float): String {
        val a = actual(lane, n)
        return when (lane) {
            0 -> "Ses ×" + String.format("%.2f", a)
            1 -> if (kotlin.math.abs(a) < 0.02f) "Pan C" else if (a < 0) "Pan L" + (-a * 100).toInt() else "Pan R" + (a * 100).toInt()
            2 -> "Reverb %" + (a * 100).toInt()
            3 -> "Delay %" + (a * 100).toInt()
            else -> "Filter " + a.toInt() + " Hz"
        }
    }
}
