package com.soundora.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.TunerEngine
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.roundToInt

private class TInst(val name: String, val notes: List<Int>, val fMin: Double, val fMax: Double, val chromatic: Boolean = false)

private val tInsts = listOf(
    TInst("Gitar", listOf(40, 45, 50, 55, 59, 64), 70.0, 700.0),
    TInst("Bas Gitar", listOf(28, 33, 38, 43), 30.0, 260.0),
    TInst("Ukulele", listOf(67, 60, 64, 69), 200.0, 520.0),
    TInst("Keman", listOf(55, 62, 69, 76), 170.0, 1000.0),
    TInst("Kromatik", emptyList(), 30.0, 1200.0, true)
)
private val letters = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
private val solfege = listOf("Do", "Do♯", "Re", "Re♯", "Mi", "Fa", "Fa♯", "Sol", "Sol♯", "La", "La♯", "Si")
private fun midiFreq(m: Int): Double = 440.0 * 2.0.pow((m - 69) / 12.0)

@Composable
fun TunerScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    var idx by remember { mutableIntStateOf(0) }
    var perm by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    var micError by remember { mutableStateOf(false) }
    var freq by remember { mutableDoubleStateOf(-1.0) }
    var pinned by remember { mutableIntStateOf(-1) }
    var lastValid by remember { mutableLongStateOf(0L) }
    val engine = remember { TunerEngine() }
    val hist = remember { ArrayList<Double>() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val inst = tInsts[idx]

    DisposableEffect(perm) {
        if (perm) {
            engine.fMin = tInsts[idx].fMin
            engine.fMax = tInsts[idx].fMax
            val ok = engine.start { f, _ ->
                val now = SystemClock.uptimeMillis()
                if (f > 0) {
                    hist.add(f)
                    if (hist.size > 5) hist.removeAt(0)
                    lastValid = now
                    freq = hist.sorted()[hist.size / 2]
                } else if (now - lastValid > 700) {
                    hist.clear()
                    freq = -1.0
                }
            }
            micError = !ok
        }
        view.keepScreenOn = true
        onDispose { engine.stop(); view.keepScreenOn = false }
    }
    LaunchedEffect(idx) {
        engine.fMin = tInsts[idx].fMin
        engine.fMax = tInsts[idx].fMax
        pinned = -1
        hist.clear()
        freq = -1.0
    }

    var noteMidi = -1
    var cents = 0.0
    if (freq > 0) {
        if (inst.chromatic) {
            val m = 69 + 12 * log2(freq / 440.0)
            noteMidi = m.roundToInt()
            cents = (m - noteMidi) * 100
        } else {
            val cands = if (pinned >= 0) listOf(pinned) else inst.notes
            var best = cands[0]
            var bc = 1e9
            for (n in cands) {
                val c = 1200 * log2(freq / midiFreq(n))
                if (abs(c) < abs(bc)) { bc = c; best = n }
            }
            noteMidi = best
            cents = bc
        }
    }
    val green = Color(0xFF22C55E)
    val yellow = Color(0xFFFACC15)
    val red = Color(0xFFEF4444)
    val grey = Color(0xFF6B7280)
    val has = noteMidi >= 0
    val col = if (!has) grey else if (abs(cents) <= 5.0) green else if (abs(cents) <= 15.0) yellow else red
    val target = if (has) (cents.coerceIn(-50.0, 50.0) / 50.0).toFloat() else 0f
    val needle by animateFloatAsState(targetValue = target, label = "needle")
    val hearMidi = if (pinned >= 0) pinned else if (has && !inst.chromatic) noteMidi else -1

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Akort Cihazı", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Enstrümanını seç ve bir teli çal. Ne yapman gerektiği ekranda yazar.",
            fontSize = 12.sp, color = Color(0xFF9CA3AF), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tInsts.forEachIndexed { i, t -> FilterChip(selected = idx == i, onClick = { idx = i }, label = { Text(t.name) }) }
        }
        Spacer(Modifier.height(10.dp))

        if (!perm) {
            Column(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("🎤", fontSize = 40.sp)
                Text("Akort için mikrofon izni gerekiyor.", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("Ses sadece telefonda analiz edilir, kaydedilmez.", fontSize = 12.sp, color = Color(0xFF9CA3AF), textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Mikrofon iznini ver") }
            }
        } else {
            if (micError) {
                Text("Mikrofon başlatılamadı. Başka bir uygulama kullanıyor olabilir.", color = red, fontSize = 12.sp)
            }
            if (!inst.chromatic) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    inst.notes.forEach { n ->
                        val sel = pinned == n || (pinned < 0 && noteMidi == n)
                        Box(
                            Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Purple else Color(0xFF232C52))
                                .clickable { pinned = if (pinned == n) -1 else n },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(letters[n % 12], fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                                Text(solfege[n % 12], fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }
                Text(
                    "Otomatik: hangi teli çalarsan onu bulur. Bir tele dokunursan sadece o tel için akort edersin.",
                    fontSize = 11.sp, color = Color(0xFF9CA3AF), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(10.dp))

            // ---- Büyük nota göstergesi
            Box(
                Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(28.dp))
                    .background(col.copy(alpha = 0.15f)).border(3.dp, col, RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!has) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("—", fontSize = 90.sp, color = grey, fontWeight = FontWeight.Bold)
                        Text("Bir tel çal…", color = grey)
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(letters[((noteMidi % 12) + 12) % 12], fontSize = 100.sp, color = col, fontWeight = FontWeight.Bold)
                        Text(
                            solfege[((noteMidi % 12) + 12) % 12] + "  •  " + String.format("%.1f Hz", freq),
                            fontSize = 14.sp, color = Color(0xFF9CA3AF)
                        )
                        if (abs(cents) <= 5.0) Text("✓", fontSize = 30.sp, color = green, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ---- Akort göstergesi
            Spacer(Modifier.height(14.dp))
            Canvas(Modifier.fillMaxWidth().height(70.dp)) {
                val w = size.width
                val h = size.height
                val cx = w / 2
                drawRoundRect(Color(0xFF232C52), Offset(0f, h * 0.35f), Size(w, h * 0.3f), CornerRadius(16f, 16f))
                val gz = w * 0.5f * (5f / 50f)
                drawRect(green.copy(alpha = 0.55f), Offset(cx - gz, h * 0.3f), Size(2 * gz, h * 0.4f))
                for (i in -5..5) {
                    val x = cx + i * (w / 2) / 5f
                    drawLine(Color.White.copy(alpha = 0.35f), Offset(x, h * 0.2f), Offset(x, h * 0.8f), if (i == 0) 4f else 2f)
                }
                if (has) {
                    val x = cx + needle * (w / 2)
                    drawLine(col, Offset(x, 0f), Offset(x, h), 9f)
                    drawCircle(col, 13f, Offset(x, h / 2))
                }
            }
            Row(Modifier.fillMaxWidth()) {
                Text("◀ Pes", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                Spacer(Modifier.weight(1f))
                Text("Doğru", fontSize = 12.sp, color = green)
                Spacer(Modifier.weight(1f))
                Text("Tiz ▶", fontSize = 12.sp, color = Color(0xFF9CA3AF))
            }

            Spacer(Modifier.height(10.dp))
            val msg = if (!has) "Mikrofona yaklaş ve bir tel çal."
            else if (abs(cents) <= 5.0) "Tam akort! Harika 🎉"
            else if (cents < 0) "Biraz PES. Teli hafifçe sık (ses tizleşsin)."
            else "Biraz TİZ. Teli hafifçe gevşet (ses alçalsın)."
            Text(msg, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = col, textAlign = TextAlign.Center)
            if (has) {
                Text(
                    String.format("%+.0f cent", cents) + "  (cent = yarım sesin yüzde biri; 0'a yaklaştıkça akort doğrudur)",
                    fontSize = 11.sp, color = Color(0xFF9CA3AF), textAlign = TextAlign.Center
                )
            }
            if (hearMidi >= 0) {
                TextButton(onClick = { AudioEngine.previewHold(0, hearMidi, 1500) }) { Text("▶ Doğru sesi dinle") }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
