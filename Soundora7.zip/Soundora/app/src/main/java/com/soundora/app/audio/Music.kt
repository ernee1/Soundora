package com.soundora.app.audio

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object MusicTheory {
    val noteNames = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    /** Piano Roll ile aynı sırada olmalı */
    val scales: List<Pair<String, List<Int>>> = listOf(
        "Kromatik" to (0..11).toList(),
        "Majör" to listOf(0, 2, 4, 5, 7, 9, 11),
        "Minör" to listOf(0, 2, 3, 5, 7, 8, 10),
        "Pent. Minör" to listOf(0, 3, 5, 7, 10),
        "Pent. Majör" to listOf(0, 2, 4, 7, 9),
        "Blues" to listOf(0, 3, 5, 6, 7, 10),
        "Dorian" to listOf(0, 2, 3, 5, 7, 9, 10)
    )
    val chords: List<Pair<String, List<Int>>> = listOf(
        "Majör" to listOf(0, 4, 7), "Minör" to listOf(0, 3, 7), "Dim" to listOf(0, 3, 6),
        "Aug" to listOf(0, 4, 8), "Sus2" to listOf(0, 2, 7), "Sus4" to listOf(0, 5, 7),
        "Maj7" to listOf(0, 4, 7, 11), "Min7" to listOf(0, 3, 7, 10), "Dom7" to listOf(0, 4, 7, 10)
    )

    fun noteName(midi: Int): String = noteNames[((midi % 12) + 12) % 12] + (midi / 12 - 1)

    /** Melodiye en uygun gamlar: (ana nota, gam indeksi, uyum %) */
    fun bestScales(): List<Triple<Int, Int, Int>> {
        val notes = AudioEngine.melody.toList()
        if (notes.isEmpty()) return emptyList()
        var total = 0
        for (n in notes) total += n.len
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (root in 0 until 12) for (si in 1 until scales.size) {
            val set = scales[si].second
            var fit = 0
            for (n in notes) if (set.contains(((n.pitch - root) % 12 + 12) % 12)) fit += n.len
            out.add(Triple(root, si, fit * 100 / max(1, total)))
        }
        return out.sortedWith(compareBy({ -it.third }, { scales[it.second].second.size })).take(5)
    }

    /** Gamın 7 üçlü akoru: ad ve ana nota'ya göre yarım ses ofsetleri */
    fun diatonic(minor: Boolean): List<Pair<String, List<Int>>> {
        val s = if (minor) scales[2].second else scales[1].second
        val res = ArrayList<Pair<String, List<Int>>>()
        for (d in 0 until 7) {
            val r = s[d]
            val t = s[(d + 2) % 7] + if (d + 2 >= 7) 12 else 0
            val f = s[(d + 4) % 7] + if (d + 4 >= 7) 12 else 0
            val q = if (t - r == 4 && f - r == 7) "" else if (t - r == 3 && f - r == 7) "m" else if (t - r == 3 && f - r == 6) "dim" else "aug"
            res.add(Pair(noteNames[r % 12] + q, listOf(r, t, f)))
        }
        return res
    }

    val nextDegrees: Map<Int, List<Int>> = mapOf(
        0 to listOf(3, 4, 5), 1 to listOf(4), 2 to listOf(5, 3), 3 to listOf(4, 0),
        4 to listOf(0, 5), 5 to listOf(3, 1), 6 to listOf(0)
    )
    val progressions: List<Pair<String, List<Int>>> = listOf(
        "I–V–vi–IV" to listOf(0, 4, 5, 3), "vi–IV–I–V" to listOf(5, 3, 0, 4),
        "I–vi–IV–V" to listOf(0, 5, 3, 4), "I–IV–V–I" to listOf(0, 3, 4, 0), "ii–V–I–I" to listOf(1, 4, 0, 0)
    )
}

object Player {
    private val h = Handler(Looper.getMainLooper())

    fun chord(kind: Int, midis: List<Int>, ms: Long = 900) {
        for (m in midis) AudioEngine.previewHold(kind, m, ms)
    }

    fun chordSeq(kind: Int, chords: List<List<Int>>, gap: Long = 1000) {
        chords.forEachIndexed { i, c -> h.postDelayed({ chord(kind, c, (gap * 9) / 10) }, i * gap) }
    }

    fun noteSeq(kind: Int, notes: List<Int>, gap: Long = 280) {
        notes.forEachIndexed { i, n -> h.postDelayed({ AudioEngine.previewHold(kind, n, gap) }, i * gap) }
    }
}

object Generator {
    class Genre(
        val name: String, val bpmLo: Int, val bpmHi: Int, val kit: Int, val rows: List<String>,
        val minor: Boolean, val prog: List<Int>, val kind: Int
    )

    private const val E = "................"
    /** satırlar: Kick, Snare, Clap, Hi-Hat, Açık Hat, Tom, Rim */
    val genres = listOf(
        Genre("Pop", 100, 120, 0, listOf("x...x...x...x...", "....x.......x...", E, "x.x.x.x.x.x.x.x.", E, E, E), false, listOf(0, 4, 5, 3), 0),
        Genre("Rock", 110, 140, 0, listOf("x.......x.x.....", "....x.......x...", E, "x.x.x.x.x.x.x.x.", E, E, E), false, listOf(0, 3, 4, 3), 4),
        Genre("Rap", 85, 100, 0, listOf("x.......x..x....", "....x.......x...", E, "x.x.x.x.x.x.x.xx", E, E, E), true, listOf(0, 5, 2, 6), 0),
        Genre("Hip-hop", 80, 95, 0, listOf("x.....x...x.....", "....x.......x...", E, "x.x.x.x.x.x.x.x.", E, E, E), true, listOf(0, 5, 2, 6), 5),
        Genre("Lo-fi", 70, 85, 2, listOf("x.....x...x..x..", "....x.......x...", E, "x.x.x.x.x.x.x.x.", E, E, ".......x.......x"), true, listOf(1, 4, 0, 5), 5),
        Genre("Elektronik", 120, 130, 3, listOf("x...x...x...x...", E, "....x.......x...", "..x...x...x...x.", "..x...x...x...x.", E, E), true, listOf(0, 0, 5, 6), 1),
        Genre("Trap", 130, 150, 1, listOf("x.......x.x.....", "........x.......", "........x.......", "x.xxx.x.xxx.x.xx", "......x.......x.", E, E), true, listOf(0, 5, 3, 4), 8),
        Genre("Akustik", 80, 110, 0, listOf("x.......x.......", "....x.......x...", E, "x.x.x.x.x.x.x.x.", E, ".............x.x", E), false, listOf(0, 5, 3, 4), 3)
    )

    fun setRows(rows: List<String>) {
        val e = AudioEngine
        for (r in 0 until AudioEngine.ROWS) for (s in 0 until AudioEngine.MAX_STEPS) e.pattern[r][s] = rows[r][s % 16] == 'x'
    }

    fun variation(g: Genre): List<String> {
        val rnd = Random(System.nanoTime())
        val rows = g.rows.map { it.toCharArray() }
        for (s in 0 until 16) {
            if (rows[3][s] == '.' && rows[4][s] == '.' && rnd.nextFloat() < 0.12f) rows[3][s] = 'x'
            if (rows[3][s] == 'x' && s != 0 && rnd.nextFloat() < 0.08f) rows[3][s] = '.'
        }
        if (rnd.nextFloat() < 0.5f) {
            val extra = listOf(6, 10, 11, 14)[rnd.nextInt(4)]
            if (rows[1][extra] == '.') rows[0][extra] = 'x'
        }
        if (rnd.nextFloat() < 0.3f) rows[1][15] = 'x'
        return rows.map { String(it) }
    }

    fun randomRows(density: Float): List<String> {
        val rnd = Random(System.nanoTime())
        val prob = floatArrayOf(0.25f, 0.12f, 0.08f, 0.5f, 0.08f, 0.07f, 0.06f)
        return List(AudioEngine.ROWS) { r ->
            val sb = StringBuilder()
            for (s in 0 until 16) {
                var on = rnd.nextFloat() < prob[r] * density * 2f
                if (r == 0 && s == 0) on = true
                if (r == 1 && (s == 4 || s == 12)) on = rnd.nextFloat() < 0.8f + 0.0f * density || on
                sb.append(if (on) 'x' else '.')
            }
            sb.toString()
        }
    }

    /** Akor ilerlemesini Piano Roll'a yazar (her akor 1 bar) */
    fun progressionToRoll(keyRoot: Int, minor: Boolean, degrees: List<Int>, kind: Int) {
        val e = AudioEngine
        val dia = MusicTheory.diatonic(minor)
        e.melody.clear()
        e.steps = 64
        e.melodyKind = kind
        val base = 48 + keyRoot
        degrees.forEachIndexed { i, d ->
            for (off in dia[d].second) e.melody.add(Note(i * 16, 14, base + off))
        }
        e.rollRoot = keyRoot
        e.rollScale = if (minor) 2 else 1
    }

    fun applyTemplate(g: Genre) {
        val e = AudioEngine
        e.bpm = (g.bpmLo + g.bpmHi) / 2
        e.kit = g.kit
        setRows(g.rows)
        progressionToRoll(0, g.minor, g.prog, g.kind)
    }
}

object Render {
    /** Bir sesi tek seferlik WAV verisine çevirir (kütüphane -> projeye ekleme). releaseAt<0: bırakma yok */
    fun voiceToPcm(make: () -> Voice, releaseAt: Double, maxSec: Double): ShortArray {
        val v = make()
        val maxN = (maxSec * AudioEngine.SR).toInt()
        val out = FloatArray(maxN)
        val relN = if (releaseAt < 0) -1 else (releaseAt * AudioEngine.SR).toInt()
        var i = 0
        var peak = 0f
        while (i < maxN && !v.finished) {
            if (i == relN) v.release()
            val s = v.render()
            out[i] = s
            peak = max(peak, abs(s))
            i++
        }
        val norm = if (peak > 0.001f) 0.9f / peak else 1f
        val n = i
        return ShortArray(n) { (out[it] * norm * 32767f).toInt().coerceIn(-32767, 32767).toShort() }
    }

    fun writeWav(file: File, pcm: ShortArray, sr: Int, bits: Int) {
        val bytesPer = if (bits == 8) 1 else 2
        val dataLen = pcm.size * bytesPer
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + dataLen)
        h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
        h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(sr); h.putInt(sr * bytesPer); h.putShort(bytesPer.toShort()); h.putShort((bytesPer * 8).toShort())
        h.put("data".toByteArray()); h.putInt(dataLen)
        FileOutputStream(file).use { o ->
            o.write(h.array())
            val block = 8192
            var pos = 0
            while (pos < pcm.size) {
                val n = min(block, pcm.size - pos)
                val b = ByteArray(n * bytesPer)
                for (k in 0 until n) {
                    val s = pcm[pos + k].toInt()
                    if (bytesPer == 2) {
                        b[2 * k] = (s and 0xff).toByte()
                        b[2 * k + 1] = ((s shr 8) and 0xff).toByte()
                    } else {
                        b[k] = (((s shr 8) + 128) and 0xff).toByte()
                    }
                }
                o.write(b)
                pos += n
            }
        }
    }
}

object Exporter {
    fun normalize(pcm: ShortArray): ShortArray {
        var peak = 0
        for (s in pcm) peak = max(peak, abs(s.toInt()))
        if (peak < 100) return pcm
        val g = 0.89 * 32767.0 / peak
        return ShortArray(pcm.size) { (pcm[it] * g).toInt().coerceIn(-32767, 32767).toShort() }
    }

    fun resample(pcm: ShortArray, from: Int, to: Int): ShortArray {
        if (from == to) return pcm
        val ratio = from.toDouble() / to
        val n = (pcm.size / ratio).toInt()
        return ShortArray(n) { i ->
            val x = i * ratio
            val i0 = x.toInt()
            val i1 = min(i0 + 1, pcm.size - 1)
            val fr = x - i0
            (pcm[i0] * (1 - fr) + pcm[i1] * fr).toInt().toShort()
        }
    }

    /** AAC (M4A) — Android'in yerleşik kodlayıcısı. MP3 kodlayıcısı Android'de yoktur. */
    fun m4a(pcm: ShortArray, rate: Int, kbps: Int, out: File): Boolean {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxStarted = false
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1)
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, kbps * 1000)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec = c
            c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            c.start()
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            var trackIdx = -1
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = c.getInputBuffer(ii)!!
                        ib.clear()
                        val n = min(pcm.size - pos, ib.capacity() / 2)
                        val pts = pos.toLong() * 1_000_000L / rate
                        if (n <= 0) {
                            c.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            ib.order(ByteOrder.nativeOrder())
                            ib.asShortBuffer().put(pcm, pos, n)
                            c.queueInputBuffer(ii, 0, n * 2, pts, 0)
                            pos += n
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    trackIdx = m.addTrack(c.outputFormat)
                    m.start()
                    muxStarted = true
                } else if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && muxStarted) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        m.writeSampleData(trackIdx, ob, info)
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            return true
        } catch (ex: Exception) {
            return false
        } finally {
            try { codec?.stop() } catch (ex: Exception) { }
            try { codec?.release() } catch (ex: Exception) { }
            try { if (muxStarted) muxer?.stop() } catch (ex: Exception) { }
            try { muxer?.release() } catch (ex: Exception) { }
        }
    }

    private fun vlq(v: Long, o: ByteArrayOutputStream) {
        val bytes = ArrayList<Int>()
        bytes.add((v and 0x7F).toInt())
        var x = v shr 7
        while (x > 0) { bytes.add(((x and 0x7F) or 0x80).toInt()); x = x shr 7 }
        for (i in bytes.indices.reversed()) o.write(bytes[i])
    }

    /** Standart MIDI dosyası (format 0): davul kanal 10, melodi kanal 1 */
    fun midi(out: File) {
        val e = AudioEngine
        class Ev(val tick: Long, val order: Int, val status: Int, val d1: Int, val d2: Int)
        val evs = ArrayList<Ev>()
        val n = max(1, e.steps)
        val drumNote = intArrayOf(36, 38, 39, 42, 46, 45, 37)
        for (c in e.clips) {
            val tr = e.trackById(c.track) ?: continue
            if (c.file != null) continue
            for (s in c.start until c.start + c.lenSteps) {
                val ps = (((s - c.start + c.phase) % n) + n) % n
                if (tr.type == 0) {
                    for (r in 0 until AudioEngine.ROWS) {
                        if (e.pattern[r][ps] && !e.rowMute[r]) {
                            val vel = (e.rowVol[r] * 127).toInt().coerceIn(1, 127)
                            evs.add(Ev(s * 120L, 1, 0x99, drumNote[r], vel))
                            evs.add(Ev(s * 120L + 60, 0, 0x89, drumNote[r], 0))
                        }
                    }
                } else if (tr.type == 1) {
                    for (nt in e.melody) {
                        if (nt.start == ps) {
                            evs.add(Ev(s * 120L, 1, 0x90, nt.pitch.coerceIn(0, 127), 100))
                            evs.add(Ev((s + nt.len) * 120L, 0, 0x80, nt.pitch.coerceIn(0, 127), 0))
                        }
                    }
                }
            }
        }
        val sorted = evs.sortedWith(compareBy({ it.tick }, { it.order }))
        val tk = ByteArrayOutputStream()
        val tempo = 60_000_000 / max(1, e.bpm)
        tk.write(byteArrayOf(0x00, 0xFF.toByte(), 0x51, 0x03, ((tempo shr 16) and 0xFF).toByte(), ((tempo shr 8) and 0xFF).toByte(), (tempo and 0xFF).toByte()))
        val program = intArrayOf(0, 80, 33, 25, 27, 4, 16, 48, 88, 45, 38)
        tk.write(byteArrayOf(0x00, 0xC0.toByte(), program[e.melodyKind.coerceIn(0, 10)].toByte()))
        var last = 0L
        for (ev in sorted) {
            vlq(ev.tick - last, tk)
            last = ev.tick
            tk.write(ev.status); tk.write(ev.d1); tk.write(ev.d2)
        }
        tk.write(byteArrayOf(0x00, 0xFF.toByte(), 0x2F, 0x00))
        val body = tk.toByteArray()
        val head = ByteBuffer.allocate(14 + 8).order(ByteOrder.BIG_ENDIAN)
        head.put("MThd".toByteArray()); head.putInt(6); head.putShort(0); head.putShort(1); head.putShort(480)
        head.put("MTrk".toByteArray()); head.putInt(body.size)
        FileOutputStream(out).use { o -> o.write(head.array()); o.write(body) }
    }
}
