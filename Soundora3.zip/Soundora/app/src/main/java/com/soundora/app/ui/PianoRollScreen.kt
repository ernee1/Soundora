package com.soundora.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soundora.app.audio.AudioEngine
import com.soundora.app.audio.Note
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.roundToInt

private val noteNames = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private val blackSemis = setOf(1, 3, 6, 8, 10)
private val scales: List<Pair<String, List<Int>>> = listOf(
    "Kromatik" to (0..11).toList(),
    "Majör" to listOf(0, 2, 4, 5, 7, 9, 11),
    "Minör" to listOf(0, 2, 3, 5, 7, 8, 10),
    "Pent. Minör" to listOf(0, 3, 5, 7, 10),
    "Pent. Majör" to listOf(0, 2, 4, 7, 9),
    "Blues" to listOf(0, 3, 5, 6, 7, 10),
    "Dorian" to listOf(0, 2, 3, 5, 7, 9, 10)
)

@Composable
fun PianoRollScreen() {
    val e = AudioEngine
    var ver by remember { mutableIntStateOf(0) }
    var step by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(e.playing) }
    var baseOct by remember { mutableIntStateOf(4) }
    var snap by remember { mutableIntStateOf(1) }
    var defLen by remember { mutableIntStateOf(2) }
    var vis by remember { mutableIntStateOf(16) }
    var first by remember { mutableIntStateOf(0) }
    var root by remember { mutableIntStateOf(0) }
    var scaleIdx by remember { mutableIntStateOf(0) }
    var lock by remember { mutableStateOf(false) }
    var kindSel by remember { mutableIntStateOf(e.melodyKind) }

    LaunchedEffect(Unit) { while (true) { step = e.currentStep; playing = e.playing; delay(30) } }

    @Suppress("UNUSED_VARIABLE") val subscribe = ver
    val steps = e.steps
    val visC = min(vis, steps)
    val maxFirst = (steps - visC).coerceAtLeast(0)
    val f0 = first.coerceIn(0, maxFirst)
    val baseMidi = 12 * (baseOct + 1)
    val intervals = scales[scaleIdx].second

    fun allowed(p: Int): Boolean = intervals.contains(((p - root) % 12 + 12) % 12)

    val keys = listOf(visC, f0, baseOct, snap, defLen, lock, root, scaleIdx)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Piano Roll", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ritimle birlikte çalar. Boş hücreye dokun: nota ekle. Notaya dokun: sil. Sürükle: taşı. Sağ kenarı sürükle: uzunluk.",
            color = Color(0xFF9CA3AF), fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue)))
                    .clickable { if (!playing) e.songMode = false; playing = !playing; e.songMode = false; e.playing = playing },
                contentAlignment = Alignment.Center
            ) { Text(if (playing) "■" else "▶", fontSize = 20.sp, color = Color.White) }
            Text("${e.bpm} BPM  •  $steps adım", fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { e.melody.clear(); ver++ }) { Text("Temizle") }
        }

        Spacer(Modifier.height(8.dp))
        Text("Enstrüman", fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AudioEngine.kindNames.forEachIndexed { k, n ->
                FilterChip(selected = kindSel == k, onClick = { kindSel = k; e.melodyKind = k }, label = { Text(n) })
            }
        }
        Text("Gam (Ana nota / Tür)", fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            noteNames.forEachIndexed { i, n -> FilterChip(selected = root == i, onClick = { root = i }, label = { Text(n) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            scales.forEachIndexed { i, s -> FilterChip(selected = scaleIdx == i, onClick = { scaleIdx = i }, label = { Text(s.first) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Scale Lock", fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Switch(checked = lock, onCheckedChange = { lock = it })
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Izgara", fontSize = 12.sp)
            listOf(1 to "1/16", 2 to "1/8", 4 to "1/4").forEach { (v, n) ->
                FilterChip(selected = snap == v, onClick = { snap = v }, label = { Text(n) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Uzunluk", fontSize = 12.sp)
            listOf(1, 2, 4, 8).forEach { v ->
                FilterChip(selected = defLen == v, onClick = { defLen = v }, label = { Text("$v") })
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (baseOct > 1) baseOct-- }) { Text("Oktav −") }
            OutlinedButton(onClick = { if (baseOct < 7) baseOct++ }) { Text("Oktav +") }
            OutlinedButton(onClick = { if (vis > 4) vis = vis / 2 }) { Text("Yakınlaş") }
            OutlinedButton(onClick = { if (vis < 64) vis = vis * 2 }) { Text("Uzaklaş") }
            OutlinedButton(onClick = {
                for (n in e.melody) {
                    n.start = ((n.start + snap / 2) / snap) * snap
                    n.len = maxOf(snap, ((n.len + snap / 2) / snap) * snap)
                }
                ver++
            }) { Text("Quantize") }
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.width(40.dp)) {
                for (i in 0 until 12) {
                    val semi = 11 - i
                    val inScale = allowed(baseMidi + semi)
                    Box(
                        Modifier.fillMaxWidth().height(26.dp)
                            .background(if (blackSemis.contains(semi)) Color(0xFF0B0B12) else Color(0xFFE5E7EB)),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "${noteNames[semi]}$baseOct", fontSize = 9.sp, modifier = Modifier.padding(start = 3.dp),
                            color = if (inScale && scaleIdx != 0) Purple else if (blackSemis.contains(semi)) Color.White else Color.Black
                        )
                    }
                }
            }
            Box(
                Modifier.weight(1f).height(312.dp)
                    .pointerInput(keys) {
                        detectTapGestures(onTap = { off ->
                            val cw = size.width / visC.toFloat()
                            val rh = size.height / 12f
                            val col = f0 + (off.x / cw).toInt().coerceIn(0, visC - 1)
                            val row = (off.y / rh).toInt().coerceIn(0, 11)
                            val pitch = baseMidi + (11 - row)
                            val hit = e.melody.firstOrNull { it.pitch == pitch && col >= it.start && col < it.start + it.len }
                            if (hit != null) {
                                e.melody.remove(hit); ver++
                            } else if (!lock || allowed(pitch)) {
                                val st = col - col % snap
                                if (st < steps) {
                                    val len = maxOf(snap, defLen).coerceAtMost(steps - st)
                                    e.melody.add(Note(st, len, pitch))
                                    e.preview(kindSel, pitch)
                                    ver++
                                }
                            }
                        })
                    }
                    .pointerInput(keys) {
                        var target: Note? = null
                        var mode = 0
                        var startS = 0
                        var startL = 0
                        var startP = 0
                        var accX = 0f
                        var accY = 0f
                        detectDragGestures(
                            onDragStart = { off ->
                                val cw = size.width / visC.toFloat()
                                val rh = size.height / 12f
                                accX = 0f; accY = 0f; target = null
                                val col = f0 + (off.x / cw).toInt().coerceIn(0, visC - 1)
                                val row = (off.y / rh).toInt().coerceIn(0, 11)
                                val pitch = baseMidi + (11 - row)
                                val n = e.melody.firstOrNull { it.pitch == pitch && col >= it.start && col < it.start + it.len }
                                if (n != null) {
                                    target = n
                                    startS = n.start; startL = n.len; startP = n.pitch
                                    val endX = (n.start + n.len - f0) * cw
                                    mode = if (off.x > endX - cw * 0.45f) 1 else 0
                                }
                            },
                            onDrag = { change, amt ->
                                change.consume()
                                val n = target
                                if (n != null) {
                                    val cw = size.width / visC.toFloat()
                                    val rh = size.height / 12f
                                    accX += amt.x; accY += amt.y
                                    val dc = (accX / cw).roundToInt()
                                    if (mode == 1) {
                                        val l = ((startL + dc) / snap) * snap
                                        n.len = l.coerceIn(snap, maxOf(snap, steps - n.start))
                                    } else {
                                        val ns = (startS + dc).coerceIn(0, maxOf(0, steps - n.len))
                                        n.start = ns - ns % snap
                                        val dr = (accY / rh).roundToInt()
                                        val np = (startP - dr).coerceIn(baseMidi, baseMidi + 11)
                                        if (!lock || allowed(np)) n.pitch = np
                                    }
                                    ver++
                                }
                            },
                            onDragEnd = { target = null },
                            onDragCancel = { target = null }
                        )
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    @Suppress("UNUSED_VARIABLE") val sub = ver
                    val cw = size.width / visC.toFloat()
                    val rh = size.height / 12f
                    for (i in 0 until 12) {
                        val semi = 11 - i
                        val ok = allowed(baseMidi + semi)
                        val base = if (blackSemis.contains(semi)) Color(0xFF151B33) else Color(0xFF1E2748)
                        val col = if (scaleIdx != 0 && !ok) Color(0xFF0A0E1F) else base
                        drawRect(col, Offset(0f, i * rh), Size(size.width, rh))
                        if (((baseMidi + semi - root) % 12 + 12) % 12 == 0) {
                            drawRect(Purple.copy(alpha = 0.18f), Offset(0f, i * rh), Size(size.width, rh))
                        }
                    }
                    for (c in 0..visC) {
                        val idx = f0 + c
                        val w = if (idx % 16 == 0) 3f else if (idx % 4 == 0) 2f else 1f
                        drawLine(Color.White.copy(alpha = if (idx % 4 == 0) 0.25f else 0.08f), Offset(c * cw, 0f), Offset(c * cw, size.height), w)
                    }
                    for (n in e.melody.toList()) {
                        val col = n.start - f0
                        val rowSemi = n.pitch - baseMidi
                        if (rowSemi !in 0..11 || col + n.len <= 0 || col >= visC) continue
                        val i = 11 - rowSemi
                        drawRoundRect(
                            Purple, Offset(col * cw + 1f, i * rh + 1f),
                            Size(n.len * cw - 2f, rh - 2f), CornerRadius(6f, 6f)
                        )
                        drawRect(Color.White.copy(alpha = 0.6f), Offset((col + n.len) * cw - 6f, i * rh + 4f), Size(3f, rh - 8f))
                    }
                    if (step >= f0 && step < f0 + visC) {
                        drawRect(Color.White.copy(alpha = 0.22f), Offset((step - f0) * cw, 0f), Size(cw, size.height))
                    }
                }
            }
        }
        if (maxFirst > 0) {
            Text("Kaydır", fontSize = 11.sp, color = Color(0xFF9CA3AF))
            Slider(value = f0.toFloat(), valueRange = 0f..maxFirst.toFloat(), onValueChange = { first = it.roundToInt() })
        }
        Spacer(Modifier.height(16.dp))
    }
}
