package com.soundora.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.soundora.app.audio.Headphones
import kotlinx.coroutines.delay
import java.io.File

/** Ses kayıt merkezi: Kaydet, Kayıtlarım; Gelişmiş modda ayrıca Overdub ve Kanallar. */
@Composable
fun RecordScreen() {
    val ctx = LocalContext.current
    val adv = AppPrefs.advanced
    var section by rememberSaveable { mutableStateOf(0) }
    var edit by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(Unit) {
        Headphones.register(ctx)
        while (true) { Headphones.refresh(ctx); delay(800) }
    }
    val names = if (adv) listOf("Kaydet", "Kayıtlarım", "Overdub", "Kanallar") else listOf("Kaydet", "Kayıtlarım")
    val sec = if (section >= names.size) 0 else section

    Column(Modifier.fillMaxSize()) {
        if (edit == null) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                names.forEachIndexed { i, n -> FilterChip(selected = sec == i, onClick = { section = i }, label = { Text(n) }) }
            }
        }
        Box(Modifier.weight(1f)) {
            val f = edit
            if (f != null) RecEditorPanel(f) { edit = null }
            else when (sec) {
                0 -> RecordMainPanel { edit = it }
                1 -> MyRecordingsPanel { edit = it }
                2 -> OverdubPanel()
                else -> ChannelsPanel()
            }
        }
    }
}
