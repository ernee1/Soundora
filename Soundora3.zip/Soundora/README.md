# Soundora (Aşama 4)
Yeni: Studio (çok kanallı zaman çizelgesi), proje yönetimi, yedekleme.
Studio: Davul + Melodi + Vokal/Ses kanalları, WAV kayıt/dosya parçaları (dalga formu), taşı/böl/kopyala/birleştir/sil/kırp,
M/S, kanal sesi, gizle, metronom, döngü alanı, geri al/ileri al, imleç.
Projeler: yeni/aç/ad/kopya/sil, otomatik kayıt, yedekle (zip paylaş), yedekten yükle.
Henüz yok: efektler, kayıt kırpma ekranı, ses kütüphanesi, öğrenme, dışa aktarma, ayarlar.
