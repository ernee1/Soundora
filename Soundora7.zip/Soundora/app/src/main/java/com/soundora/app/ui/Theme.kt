package com.soundora.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object ThemeState { var dark by mutableStateOf(true) }

val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)
val Navy: Color get() = if (ThemeState.dark) Color(0xFF0B1020) else Color(0xFFF1F3FA)
val Panel: Color get() = if (ThemeState.dark) Color(0xFF141B33) else Color(0xFFFFFFFF)
val RowColors = listOf(
    Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF22D3EE),
    Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFF8B5CF6)
)

@Composable
fun SoundoraTheme(content: @Composable () -> Unit) {
    val scheme = if (ThemeState.dark) {
        darkColorScheme(
            primary = Purple, secondary = Blue, background = Navy, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    } else {
        lightColorScheme(
            primary = Purple, secondary = Blue, background = Navy, surface = Panel,
            onBackground = Color(0xFF111827), onSurface = Color(0xFF111827)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
